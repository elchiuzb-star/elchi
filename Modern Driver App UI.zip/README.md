
  # Modern Driver App UI

  This is a code bundle for Modern Driver App UI. The original project is available at https://www.figma.com/design/Qcs1xZUtChl7bO4tzTBteD/Modern-Driver-App-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  