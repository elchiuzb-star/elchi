import { useState, createContext, useContext, useEffect, useRef } from "react";
import { RouterProvider, createBrowserRouter, useNavigate, Outlet, Navigate } from "react-router";
import {
  Home, MapPin, Package, User, ChevronRight, ChevronLeft,
  ToggleLeft, ToggleRight, Star, Plus, Trash2, Pencil, TrendingUp,
  CheckCircle2, Clock, Truck, FileText, AlertCircle, Send, Navigation,
  Shield, Phone, Car, Route, Inbox, LogOut, Bell, Sun, Moon, Monitor,
  Settings, Globe, Info, Vibrate, ArrowRight, RefreshCw, X,
  Camera, Image, ThumbsUp, Flag, Search,
  CreditCard, CheckCheck, Ban, Edit3, Eye, Locate,
  LayoutDashboard, Users, Tag, ShieldCheck, ClipboardList, DollarSign,
  Activity, ChevronDown, PanelLeftClose, PanelLeft, ArrowUpRight,
  CircleDot, UserCheck, UserX, Zap, Filter, Download, ExternalLink,
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";

// ─── Types ────────────────────────────────────────────────────────────────────

type AuthStep  = "splash" | "onboarding" | "role-select" | "phone" | "otp" | "app";
type Role      = "client" | "driver" | "admin";
type AdminSection = "dashboard"|"orders"|"drivers"|"clients"|"regions"|"tariffs"|"disputes"|"staff"|"notifications"|"audit"|"profile";
type ThemeMode = "light" | "dark" | "system";
type Lang      = "uz" | "ru" | "en";

type DriverTab    = "home" | "routes" | "orders" | "profile";
type DriverScreen = DriverTab | "income" | "order-detail" | "documents" | "edit-profile" | "add-route" | "settings";

type ClientTab    = "home" | "orders" | "notifications" | "profile";
type ClientScreen =
  | ClientTab
  | "city-select-from" | "city-select-to"
  | "district-select-from" | "district-select-to"
  | "map-picker-from" | "map-picker-to"
  | "contacts" | "cargo-photo" | "order-review" | "order-success"
  | "c-order-detail" | "bids" | "confirm-delivery" | "rating" | "dispute"
  | "c-settings";

// ─── Translations ─────────────────────────────────────────────────────────────

const T = {
  uz: {
    splashTagline:"Yetkazib berish, oson", onboardingTitle:"Elchi bilan ishlang",
    onboardingDesc:"Shaharlararo yuk tashish platformasi. Yo'nalishlar qo'shing va buyurtmalar qabul qiling.",
    onboardingCta:"Boshlash", roleTitle:"Kirish turi", roleDesc:"Hisob turini tanlang",
    roleDriver:"Haydovchiman", roleDriverDesc:"Buyurtmalar qabul qilish",
    roleClient:"Mijozman", roleClientDesc:"Yuk jo'natish",
    phoneTitle:"Telefon raqam", phoneDesc:"Tasdiqlash kodi yuboriladi",
    phonePlaceholder:"+998 XX XXX XX XX", phoneLabel:"Telefon raqamingiz",
    phoneCta:"Kodni yuborish", phoneError:"Noto'g'ri raqam",
    otpTitle:"Kodni kiriting", otpDesc:"Kodni telefonga yubordik",
    otpResend:"Qayta yuborish", otpResendIn:"Qayta yuborish", otpVerify:"Tasdiqlash",
    otpError:"Kod noto'g'ri yoki muddati o'tgan", back:"Ortga", as:"Sifatida",
    // Client home
    sendParcel:"Yuk jo'natish", chooseExactAddress:"Shahar va manzilni tanlang, haydovchi takliflarini oling",
    pickupPoint:"Olib ketish joyi", dropoffPoint:"Yetkazish joyi", changeBtn:"O'zgartirish",
    selectPickup:"Olib ketish joyini tanlang", selectDropoff:"Yetkazish joyini tanlang",
    activeStat:"Faol", bidsStat:"Takliflar", completedStat:"Bajarilgan",
    viewRoute:"Yo'nalishni ko'rish", cityNotSelected:"Shaharni tanlang",
    // City/district
    chooseCity:"Shaharni tanlang", searchCity:"Shahar qidirish...",
    chooseDistrict:"Tumanni tanlang", searchDistrict:"Tuman qidirish...",
    noDistricts:"Tuman topilmadi", noResults:"Natija topilmadi",
    // Map
    confirmLocation:"Manzilni tasdiqlash", manualAddress:"Manzilni kiriting",
    // Contacts
    contactsTitle:"Aloqa ma'lumotlari", senderPhone:"Jo'natuvchi telefoni *",
    receiverPhone:"Qabul qiluvchi telefoni *", pickupAddress:"Olib ketish manzili *",
    dropoffAddress:"Yetkazish manzili *", commentOptional:"Izoh (ixtiyoriy)",
    commentPlaceholder:"Qo'shimcha ma'lumot...", nextBtn:"Davom etish",
    // Cargo
    cargoPhotoTitle:"Yuk rasmi", uploadPhoto:"Rasm yuklash",
    photoDesc:"Yukingiz rasmini yuklang (max 5 MB)", photoUploaded:"Rasm yuklandi",
    changePhoto:"Rasmni o'zgartirish", skipPhoto:"O'tkazib yuborish",
    // Review
    reviewTitle:"Buyurtmani tekshirish", publishOrder:"Buyurtmani e'lon qilish",
    suggestedPrice:"Tavsiya etilgan narx", editOrder:"Tahrirlash",
    fromLabel:"Qayerdan", toLabel:"Qayerga",
    // Success
    orderPublished:"Buyurtma e'lon qilindi!", orderPublishedDesc:"Haydovchilar sizning buyurtmangizni ko'radi va taklif yuboradi.",
    viewMyOrder:"Buyurtmani ko'rish", backHome:"Bosh sahifaga",
    // Orders list
    myOrders:"Buyurtmalarim", allOrders:"Barchasi", activeOrders:"Faol",
    completedOrders:"Bajarilgan", cancelledOrders:"Bekor qilingan",
    noOrdersYet:"Hali buyurtmalar yo'q", noOrdersDesc:"Birinchi buyurtmangizni yarating",
    createOrder:"Buyurtma yaratish",
    // Order detail
    orderDetail:"Buyurtma tafsiloti", statusTimeline:"Holat",
    assignedDriver:"Biriktirilgan haydovchi", bidsSection:"Takliflar",
    noBidsYet:"Hali takliflar yo'q", waitingBids:"Haydovchilar taklif kutilmoqda...",
    viewBids:"Takliflarni ko'rish", confirmDelivery:"Yetkazishni tasdiqlash",
    cancelOrderBtn:"Buyurtmani bekor qilish", openDisputeBtn:"Shikoyat ochish",
    editOrderBtn:"Buyurtmani tahrirlash",
    // Bids
    driverOffers:"Haydovchi takliflari", selectDriver:"Haydovchini tanlash",
    noBids:"Hali takliflar yo'q",
    confirmDriverTitle:"Haydovchini tasdiqlash", confirmDriverDesc:"Bu haydovchi sizning buyurtmangizni bajaradi.",
    confirmSelectDriver:"Tasdiqlash",
    // Confirm delivery
    confirmDeliveryTitle:"Yetkazishni tasdiqlash", paymentNote:"To'lov turi: Naqd",
    cashNote:"Haydovchiga naqd to'lov amalga oshiriladi", confirmBtn:"Yetkazishni tasdiqlash",
    // Rating
    rateDriverTitle:"Haydovchini baholang", ratingDesc:"Xizmat sifatini baholang",
    yourRating:"Bahoingiz", addComment:"Izoh qoldiring (ixtiyoriy)",
    submitRating:"Baholashni yuborish", ratingSuccess:"Rahmat!",
    ratingLabels:["","Yomon","Qoniqarli","Yaxshi","Zo'r","A'lo!"],
    // Dispute
    disputeTitle:"Shikoyat ochish", disputeReason:"Sabab *", disputeComment:"Izoh",
    disputeReasonPlaceholder:"Muammoni tushuntiring...", submitDispute:"Shikoyat yuborish",
    disputeSuccess:"Shikoyat yuborildi!", disputeSuccessDesc:"Operatorlar tez orada ko'rib chiqadi.",
    disputeErrorEmpty:"Iltimos, sabab kiriting.",
    disputeReasons:"Yuk shikastlangan|Kech yetkazilgan|Haydovchi xulqi|Noto'g'ri manzil|Boshqa",
    // Notifications
    notifications:"Bildirishnomalar", noNotifications:"Bildirishnomalar yo'q",
    noNotifDesc:"Buyurtmalaringiz yangilanishlari bu yerda ko'rinadi",
    markAllRead:"Barchasini o'qildi deb belgilash",
    // Profile
    clientProfile:"Profil", personalData:"Shaxsiy ma'lumotlar",
    fullNameLabel:"To'liq ism", saveProfile:"Saqlash",
    myOrdersLink:"Mening buyurtmalarim", notificationsLink:"Bildirishnomalar",
    // Shared
    home:"Asosiy", orders:"Buyurtmalar", profile:"Profil",
    goodMorning:"Xayrli tong", netIncome:"Sof daromad", activeRoute:"Faol yo'nalish",
    liveLabel:"JONLI", verifiedDriver:"Tasdiqlangan haydovchi", pendingVerification:"Tasdiqlanish kutilmoqda",
    approvedDesc:"Mos yo'nalishlar bo'yicha buyurtmalar paydo bo'ladi.",
    notApprovedDesc:"Profilingizni to'ldiring va barcha hujjatlarni yuklang.",
    completeProfile:"Profilni to'ldirish", uploadDocuments:"Hujjatlarni yuklash",
    availability:"Mavjudlik", visibleToClients:"Mijozlarga ko'rinasiz", currentlyOffline:"Hozir oflayn",
    rating:"Reyting", completed:"Bajarildi", total:"Jami",
    myRoutes:"Mening yo'nalishlarim", addRoute:"Yo'nalish qo'shish",
    noRoutesYet:"Hali yo'nalishlar yo'q", noRoutesDesc:"Mos buyurtmalar olish uchun yo'nalish qo'shing",
    addFirstRoute:"Birinchi yo'nalishni qo'shish", fromCity:"Qayerdan (shahar) *",
    toCity:"Qayerga (shahar) *", fromDistrict:"Qayerdan (tuman, ixtiyoriy)",
    toDistrict:"Qayerga (tuman, ixtiyoriy)", selectCity:"Shaharni tanlang",
    saveRoute:"Yo'nalishni saqlash", editRoute:"Yo'nalishni tahrirlash",
    matchingOrders:"Mos buyurtmalar", myHistory:"Mening tarixim",
    sendBid:"Taklif yuborish", bid:"Taklif", gross:"Yalpi", net:"Sof",
    bidSheetTitle:"Taklif yuborish", bidSheetRoute:"Yo'nalish",
    bidSheetSuggestedPrice:"Tavsiya etilgan narx", bidSheetYourPrice:"Sizning narxingiz",
    bidSheetPricePlaceholder:"Narxni kiriting", bidSheetNote:"Izoh (ixtiyoriy)",
    bidSheetNotePlaceholder:"Qo'shimcha ma'lumot...", bidSheetSubmit:"Taklif yuborish",
    bidSheetCancel:"Bekor qilish", bidSheetSuccess:"Taklif yuborildi!",
    bidSheetSuccessDesc:"Mijoz sizning taklifingizni ko'radi.",
    bidSheetErrorEmpty:"Iltimos, narxni kiriting.", bidSheetErrorZero:"Narx noldan katta bo'lishi kerak.",
    bidSheetNetEst:"Taxminiy sof daromad", bidSheetCommissionNote:"Platforma komissiyasi (10%)",
    statusProgress:"Holat jarayoni", contactDetails:"Aloqa ma'lumotlari",
    sender:"Jo'natuvchi", receiver:"Qabul qiluvchi", comment:"Izoh",
    incomeReport:"Daromad hisoboti", grossAmount:"Yalpi miqdor",
    systemFee:"Platforma komissiyasi (10%)", viewOnMap:"Xaritada ko'rish",
    markDelivered:"Yetkazib berildi deb belgilash",
    accepted:"Qabul qilindi", pickedUp:"Olib ketildi", inTransit:"Yo'lda", delivered:"Yetkazildi",
    income:"Daromad", afterCommission:"Platforma komissiyasidan keyin",
    commission:"Komissiya", earningsChart:"Daromad grafigi", sevenDays:"7 kun",
    sixMonths:"6 oy", recentEarnings:"So'nggi daromadlar",
    youAreOnline:"Siz onlinesiz", youAreOffline:"Siz oflayn holatdasiz",
    vehicle:"Transport vositasi", editProfile:"Profilni tahrirlash",
    documents:"Hujjatlar", settings:"Sozlamalar", logOut:"Chiqish",
    fullName:"To'liq ism", carModel:"Avtomobil modeli", carColor:"Avtomobil rangi",
    plateNumber:"Davlat raqami", saveChanges:"O'zgarishlarni saqlash",
    uploadAllDocs:"Tasdiqlashni yakunlash uchun barcha hujjatlarni yuklang.",
    viewFile:"Faylni ko'rish", replace:"Almashtirish", upload:"Yuklash",
    appearance:"Ko'rinish", theme:"Mavzu", themeDesc:"Afzal ko'rinishni tanlang",
    lightTheme:"Yorug'", darkTheme:"Qorong'u", systemTheme:"Sistema",
    alwaysLight:"Doim yorug'", alwaysDark:"Doim qorong'u", followsDevice:"Qurilmaga bog'liq",
    language:"Til", appLanguage:"Ilova tili", notifications2:"Bildirishnomalar",
    orderUpdates:"Buyurtma yangilanishlari", orderUpdatesDesc:"Holat o'zgarishlari, yangi topshiriqlar",
    bidAlerts:"Taklif ogohlantirishlari", bidAlertsDesc:"Mos buyurtmalarga yangi takliflar",
    promotions:"Aktsiyalar", promotionsDesc:"Platforma yangiliklari va takliflari",
    vibration:"Tebranish", vibrationDesc:"Ogohlantirishlar uchun tebranish",
    account:"Hisob", privacySecurity:"Maxfiylik va xavfsizlik",
    termsOfService:"Foydalanish shartlari", aboutElchi:"Elchi haqida",
    version:"Elchi · v2.4.1 · Versiya 2026.06",
    statusPublished:"E'lon qilingan", statusBidding:"Takliflar bor",
    statusAccepted:"Qabul qilindi", statusInTransit:"Yo'lda",
    statusDelivered:"Yetkazildi", statusConfirmed:"Tasdiqlandi",
    statusCancelled:"Bekor qilindi", statusActive:"Faol",
    statusInactive:"Faol emas", statusApproved:"Tasdiqlangan",
    statusPending:"Kutilmoqda", statusMissing:"Yuklanmagan", statusNew:"Yangi", statusDraft:"Qoralama",
  },
  ru: {
    splashTagline:"Доставка, просто", onboardingTitle:"Работайте с Elchi",
    onboardingDesc:"Платформа для межгородских грузоперевозок. Добавляйте маршруты и принимайте заказы.",
    onboardingCta:"Начать", roleTitle:"Тип входа", roleDesc:"Выберите тип аккаунта",
    roleDriver:"Я водитель", roleDriverDesc:"Принимать заказы",
    roleClient:"Я клиент", roleClientDesc:"Отправить груз",
    phoneTitle:"Номер телефона", phoneDesc:"Вам придёт код подтверждения",
    phonePlaceholder:"+998 XX XXX XX XX", phoneLabel:"Ваш номер телефона",
    phoneCta:"Отправить код", phoneError:"Неверный номер",
    otpTitle:"Введите код", otpDesc:"Мы отправили код на ваш телефон",
    otpResend:"Отправить снова", otpResendIn:"Отправить снова", otpVerify:"Подтвердить",
    otpError:"Неверный или просроченный код", back:"Назад", as:"Как",
    sendParcel:"Отправить груз", chooseExactAddress:"Выберите город и адрес, получите предложения водителей",
    pickupPoint:"Место получения", dropoffPoint:"Место доставки", changeBtn:"Изменить",
    selectPickup:"Выберите место получения", selectDropoff:"Выберите место доставки",
    activeStat:"Активные", bidsStat:"Предложения", completedStat:"Выполнено",
    viewRoute:"Посмотреть маршрут", cityNotSelected:"Выберите город",
    chooseCity:"Выберите город", searchCity:"Поиск города...",
    chooseDistrict:"Выберите район", searchDistrict:"Поиск района...",
    noDistricts:"Районы не найдены", noResults:"Ничего не найдено",
    confirmLocation:"Подтвердить адрес", manualAddress:"Введите адрес",
    contactsTitle:"Контактные данные", senderPhone:"Телефон отправителя *",
    receiverPhone:"Телефон получателя *", pickupAddress:"Адрес получения *",
    dropoffAddress:"Адрес доставки *", commentOptional:"Комментарий (необязательно)",
    commentPlaceholder:"Дополнительная информация...", nextBtn:"Продолжить",
    cargoPhotoTitle:"Фото груза", uploadPhoto:"Загрузить фото",
    photoDesc:"Загрузите фото вашего груза (макс. 5 МБ)", photoUploaded:"Фото загружено",
    changePhoto:"Изменить фото", skipPhoto:"Пропустить",
    reviewTitle:"Проверка заказа", publishOrder:"Опубликовать заказ",
    suggestedPrice:"Рекомендуемая цена", editOrder:"Редактировать",
    fromLabel:"Откуда", toLabel:"Куда",
    orderPublished:"Заказ опубликован!", orderPublishedDesc:"Водители увидят ваш заказ и отправят предложения.",
    viewMyOrder:"Мой заказ", backHome:"На главную",
    myOrders:"Мои заказы", allOrders:"Все", activeOrders:"Активные",
    completedOrders:"Выполненные", cancelledOrders:"Отменённые",
    noOrdersYet:"Заказов пока нет", noOrdersDesc:"Создайте первый заказ", createOrder:"Создать заказ",
    orderDetail:"Детали заказа", statusTimeline:"Статус",
    assignedDriver:"Назначенный водитель", bidsSection:"Предложения",
    noBidsYet:"Предложений пока нет", waitingBids:"Ожидание предложений от водителей...",
    viewBids:"Посмотреть предложения", confirmDelivery:"Подтвердить доставку",
    cancelOrderBtn:"Отменить заказ", openDisputeBtn:"Открыть спор", editOrderBtn:"Редактировать",
    driverOffers:"Предложения водителей", selectDriver:"Выбрать водителя",
    noBids:"Предложений нет",
    confirmDriverTitle:"Подтвердить водителя", confirmDriverDesc:"Этот водитель выполнит ваш заказ.",
    confirmSelectDriver:"Подтвердить",
    confirmDeliveryTitle:"Подтвердить доставку", paymentNote:"Способ оплаты: Наличные",
    cashNote:"Оплата наличными водителю", confirmBtn:"Подтвердить доставку",
    rateDriverTitle:"Оцените водителя", ratingDesc:"Оцените качество обслуживания",
    yourRating:"Ваша оценка", addComment:"Оставьте комментарий (необязательно)",
    submitRating:"Отправить оценку", ratingSuccess:"Спасибо!",
    ratingLabels:["","Плохо","Удовлетворительно","Хорошо","Отлично","Превосходно!"],
    disputeTitle:"Открыть спор", disputeReason:"Причина *", disputeComment:"Комментарий",
    disputeReasonPlaceholder:"Опишите проблему...", submitDispute:"Отправить жалобу",
    disputeSuccess:"Жалоба отправлена!", disputeSuccessDesc:"Операторы рассмотрят её в ближайшее время.",
    disputeErrorEmpty:"Пожалуйста, укажите причину.",
    disputeReasons:"Груз повреждён|Задержка доставки|Поведение водителя|Неверный адрес|Другое",
    notifications:"Уведомления", noNotifications:"Уведомлений нет",
    noNotifDesc:"Здесь будут отображаться обновления по заказам",
    markAllRead:"Отметить все как прочитанные",
    clientProfile:"Профиль", personalData:"Личные данные",
    fullNameLabel:"Полное имя", saveProfile:"Сохранить",
    myOrdersLink:"Мои заказы", notificationsLink:"Уведомления",
    home:"Главная", orders:"Заказы", profile:"Профиль",
    goodMorning:"Доброе утро", netIncome:"Чистый доход", activeRoute:"Активный маршрут",
    liveLabel:"ПРЯМОЙ", verifiedDriver:"Подтверждённый водитель", pendingVerification:"Ожидает подтверждения",
    approvedDesc:"Подходящие заказы появятся по вашим маршрутам.",
    notApprovedDesc:"Заполните профиль и загрузите все документы.",
    completeProfile:"Заполнить профиль", uploadDocuments:"Загрузить документы",
    availability:"Доступность", visibleToClients:"Вы видны клиентам", currentlyOffline:"Вы сейчас офлайн",
    rating:"Рейтинг", completed:"Выполнено", total:"Всего",
    myRoutes:"Мои маршруты", addRoute:"Добавить маршрут",
    noRoutesYet:"Маршрутов пока нет", noRoutesDesc:"Добавьте маршрут для получения заказов",
    addFirstRoute:"Добавить первый маршрут", fromCity:"Откуда (город) *",
    toCity:"Куда (город) *", fromDistrict:"Откуда (район, необязательно)",
    toDistrict:"Куда (район, необязательно)", selectCity:"Выберите город",
    saveRoute:"Сохранить маршрут", editRoute:"Редактировать маршрут",
    matchingOrders:"Подходящие заказы", myHistory:"Моя история",
    sendBid:"Отправить предложение", bid:"Предложение", gross:"Валовый", net:"Чистый",
    bidSheetTitle:"Отправить предложение", bidSheetRoute:"Маршрут",
    bidSheetSuggestedPrice:"Рекомендуемая цена", bidSheetYourPrice:"Ваша цена",
    bidSheetPricePlaceholder:"Введите цену", bidSheetNote:"Комментарий (необязательно)",
    bidSheetNotePlaceholder:"Дополнительная информация...", bidSheetSubmit:"Отправить предложение",
    bidSheetCancel:"Отмена", bidSheetSuccess:"Предложение отправлено!",
    bidSheetSuccessDesc:"Клиент увидит ваше предложение.",
    bidSheetErrorEmpty:"Пожалуйста, введите цену.", bidSheetErrorZero:"Цена должна быть больше нуля.",
    bidSheetNetEst:"Ориентировочный чистый доход", bidSheetCommissionNote:"С учётом комиссии платформы (10%)",
    statusProgress:"Статус выполнения", contactDetails:"Контактные данные",
    sender:"Отправитель", receiver:"Получатель", comment:"Комментарий",
    incomeReport:"Отчёт о доходах", grossAmount:"Валовая сумма",
    systemFee:"Комиссия платформы (10%)", viewOnMap:"Смотреть на карте",
    markDelivered:"Отметить как доставлено",
    accepted:"Принято", pickedUp:"Забрано", inTransit:"В пути", delivered:"Доставлено",
    income:"Доходы", afterCommission:"После комиссии платформы",
    commission:"Комиссия", earningsChart:"График доходов", sevenDays:"7 дней",
    sixMonths:"6 месяцев", recentEarnings:"Последние доходы",
    youAreOnline:"Вы онлайн", youAreOffline:"Вы офлайн",
    vehicle:"Транспортное средство", editProfile:"Редактировать профиль",
    documents:"Документы", settings:"Настройки", logOut:"Выйти",
    fullName:"Полное имя", carModel:"Модель автомобиля", carColor:"Цвет автомобиля",
    plateNumber:"Гос. номер", saveChanges:"Сохранить изменения",
    uploadAllDocs:"Загрузите все документы для завершения проверки.",
    viewFile:"Просмотреть файл", replace:"Заменить", upload:"Загрузить",
    appearance:"Внешний вид", theme:"Тема", themeDesc:"Выберите предпочтительный вид",
    lightTheme:"Светлая", darkTheme:"Тёмная", systemTheme:"Системная",
    alwaysLight:"Всегда светлая", alwaysDark:"Всегда тёмная", followsDevice:"По устройству",
    language:"Язык", appLanguage:"Язык приложения", notifications2:"Уведомления",
    orderUpdates:"Обновления заказов", orderUpdatesDesc:"Изменения статуса, новые задания",
    bidAlerts:"Уведомления о предложениях", bidAlertsDesc:"Новые предложения по подходящим заказам",
    promotions:"Акции", promotionsDesc:"Новости платформы и предложения",
    vibration:"Вибрация", vibrationDesc:"Вибрация при уведомлениях",
    account:"Аккаунт", privacySecurity:"Конфиденциальность и безопасность",
    termsOfService:"Условия использования", aboutElchi:"О Elchi",
    version:"Elchi · v2.4.1 · Сборка 2026.06",
    statusPublished:"Опубликовано", statusBidding:"Есть предложения",
    statusAccepted:"Принято", statusInTransit:"В пути",
    statusDelivered:"Доставлено", statusConfirmed:"Подтверждено",
    statusCancelled:"Отменено", statusActive:"Активен",
    statusInactive:"Неактивен", statusApproved:"Подтверждён",
    statusPending:"На проверке", statusMissing:"Не загружено", statusNew:"Новый", statusDraft:"Черновик",
  },
  en: {
    splashTagline:"Delivery, made easy", onboardingTitle:"Work with Elchi",
    onboardingDesc:"The intercity parcel delivery platform for Uzbekistan. Add routes and start accepting orders.",
    onboardingCta:"Get Started", roleTitle:"Sign In As", roleDesc:"Choose your account type",
    roleDriver:"I'm a Driver", roleDriverDesc:"Accept delivery orders",
    roleClient:"I'm a Client", roleClientDesc:"Send a parcel",
    phoneTitle:"Phone Number", phoneDesc:"We'll send a verification code",
    phonePlaceholder:"+998 XX XXX XX XX", phoneLabel:"Your phone number",
    phoneCta:"Send Code", phoneError:"Invalid phone number",
    otpTitle:"Enter Code", otpDesc:"We sent a code to your phone",
    otpResend:"Resend code", otpResendIn:"Resend in", otpVerify:"Verify",
    otpError:"Invalid or expired code", back:"Back", as:"as",
    sendParcel:"Send Parcel", chooseExactAddress:"Choose city and address, receive driver bids",
    pickupPoint:"Pickup Point", dropoffPoint:"Dropoff Point", changeBtn:"Change",
    selectPickup:"Select pickup location", selectDropoff:"Select dropoff location",
    activeStat:"Active", bidsStat:"Bids", completedStat:"Completed",
    viewRoute:"View Route", cityNotSelected:"Select a city",
    chooseCity:"Choose City", searchCity:"Search city...",
    chooseDistrict:"Choose District", searchDistrict:"Search district...",
    noDistricts:"No districts found", noResults:"No results found",
    confirmLocation:"Confirm Location", manualAddress:"Enter address manually",
    contactsTitle:"Contact Details", senderPhone:"Sender phone *",
    receiverPhone:"Receiver phone *", pickupAddress:"Pickup address *",
    dropoffAddress:"Dropoff address *", commentOptional:"Comment (optional)",
    commentPlaceholder:"Additional info...", nextBtn:"Continue",
    cargoPhotoTitle:"Cargo Photo", uploadPhoto:"Upload Photo",
    photoDesc:"Upload a photo of your parcel (max 5 MB)", photoUploaded:"Photo uploaded",
    changePhoto:"Change photo", skipPhoto:"Skip",
    reviewTitle:"Review Order", publishOrder:"Publish Order",
    suggestedPrice:"Suggested Price", editOrder:"Edit",
    fromLabel:"From", toLabel:"To",
    orderPublished:"Order Published!", orderPublishedDesc:"Drivers will see your order and send offers.",
    viewMyOrder:"View My Order", backHome:"Back to Home",
    myOrders:"My Orders", allOrders:"All", activeOrders:"Active",
    completedOrders:"Completed", cancelledOrders:"Cancelled",
    noOrdersYet:"No orders yet", noOrdersDesc:"Create your first order", createOrder:"Create Order",
    orderDetail:"Order Detail", statusTimeline:"Status",
    assignedDriver:"Assigned Driver", bidsSection:"Bids",
    noBidsYet:"No bids yet", waitingBids:"Waiting for driver bids...",
    viewBids:"View Bids", confirmDelivery:"Confirm Delivery",
    cancelOrderBtn:"Cancel Order", openDisputeBtn:"Open Dispute", editOrderBtn:"Edit Order",
    driverOffers:"Driver Offers", selectDriver:"Select Driver",
    noBids:"No bids yet",
    confirmDriverTitle:"Confirm Driver", confirmDriverDesc:"This driver will handle your delivery.",
    confirmSelectDriver:"Confirm",
    confirmDeliveryTitle:"Confirm Delivery", paymentNote:"Payment: Cash",
    cashNote:"Pay cash directly to the driver", confirmBtn:"Confirm Delivery",
    rateDriverTitle:"Rate Driver", ratingDesc:"Rate the quality of service",
    yourRating:"Your rating", addComment:"Leave a comment (optional)",
    submitRating:"Submit Rating", ratingSuccess:"Thank you!",
    ratingLabels:["","Poor","Fair","Good","Great","Excellent!"],
    disputeTitle:"Open Dispute", disputeReason:"Reason *", disputeComment:"Comment",
    disputeReasonPlaceholder:"Describe the problem...", submitDispute:"Submit Dispute",
    disputeSuccess:"Dispute submitted!", disputeSuccessDesc:"Operators will review it shortly.",
    disputeErrorEmpty:"Please enter a reason.",
    disputeReasons:"Cargo damaged|Late delivery|Driver behavior|Wrong address|Other",
    notifications:"Notifications", noNotifications:"No notifications",
    noNotifDesc:"Order updates will appear here",
    markAllRead:"Mark all as read",
    clientProfile:"Profile", personalData:"Personal Data",
    fullNameLabel:"Full Name", saveProfile:"Save",
    myOrdersLink:"My Orders", notificationsLink:"Notifications",
    home:"Home", orders:"Orders", profile:"Profile",
    goodMorning:"Good morning", netIncome:"Net Income", activeRoute:"Active route",
    liveLabel:"LIVE", verifiedDriver:"Verified Driver", pendingVerification:"Pending Verification",
    approvedDesc:"Route-matched orders will appear when available.",
    notApprovedDesc:"Complete your profile and upload all required documents.",
    completeProfile:"Complete Profile", uploadDocuments:"Upload Documents",
    availability:"Availability", visibleToClients:"You are visible to clients", currentlyOffline:"You are currently offline",
    rating:"Rating", completed:"Completed", total:"Total",
    myRoutes:"My Routes", addRoute:"Add Route",
    noRoutesYet:"No routes added yet", noRoutesDesc:"Add a route to receive matching orders",
    addFirstRoute:"Add First Route", fromCity:"From City *",
    toCity:"To City *", fromDistrict:"From District (optional)",
    toDistrict:"To District (optional)", selectCity:"Select city",
    saveRoute:"Save Route", editRoute:"Edit Route",
    matchingOrders:"Matching Orders", myHistory:"My History",
    sendBid:"Send Bid", bid:"Bid", gross:"Gross", net:"Net",
    bidSheetTitle:"Send Bid", bidSheetRoute:"Route",
    bidSheetSuggestedPrice:"Suggested Price", bidSheetYourPrice:"Your Price",
    bidSheetPricePlaceholder:"Enter your price", bidSheetNote:"Note (optional)",
    bidSheetNotePlaceholder:"Additional info...", bidSheetSubmit:"Send Bid",
    bidSheetCancel:"Cancel", bidSheetSuccess:"Bid Sent!",
    bidSheetSuccessDesc:"The client will see your offer.",
    bidSheetErrorEmpty:"Please enter a price.", bidSheetErrorZero:"Price must be greater than zero.",
    bidSheetNetEst:"Estimated net income", bidSheetCommissionNote:"After platform commission (10%)",
    statusProgress:"Status Progress", contactDetails:"Contact Details",
    sender:"Sender", receiver:"Receiver", comment:"Comment",
    incomeReport:"Income Report", grossAmount:"Gross Amount",
    systemFee:"System Fee (10%)", viewOnMap:"View on Map",
    markDelivered:"Mark as Delivered",
    accepted:"Accepted", pickedUp:"Picked Up", inTransit:"In Transit", delivered:"Delivered",
    income:"Income", afterCommission:"After platform commission",
    commission:"Commission", earningsChart:"Earnings Chart", sevenDays:"7 days",
    sixMonths:"6 months", recentEarnings:"Recent Earnings",
    youAreOnline:"You are online", youAreOffline:"You are offline",
    vehicle:"Vehicle", editProfile:"Edit Profile",
    documents:"Documents", settings:"Settings", logOut:"Log Out",
    fullName:"Full Name", carModel:"Car Model", carColor:"Car Color",
    plateNumber:"Plate Number", saveChanges:"Save Changes",
    uploadAllDocs:"Upload all documents to complete verification.",
    viewFile:"View File", replace:"Replace", upload:"Upload",
    appearance:"Appearance", theme:"Theme", themeDesc:"Choose your preferred appearance",
    lightTheme:"Light", darkTheme:"Dark", systemTheme:"System",
    alwaysLight:"Always light", alwaysDark:"Always dark", followsDevice:"Follows device",
    language:"Language", appLanguage:"App Language", notifications2:"Notifications",
    orderUpdates:"Order Updates", orderUpdatesDesc:"Status changes, new assignments",
    bidAlerts:"Bid Alerts", bidAlertsDesc:"New bids on matching orders",
    promotions:"Promotions", promotionsDesc:"Platform news and offers",
    vibration:"Vibration", vibrationDesc:"Haptic feedback on alerts",
    account:"Account", privacySecurity:"Privacy & Security",
    termsOfService:"Terms of Service", aboutElchi:"About Elchi",
    version:"Elchi · v2.4.1 · Build 2026.06",
    statusPublished:"Published", statusBidding:"Bidding",
    statusAccepted:"Accepted", statusInTransit:"In Transit",
    statusDelivered:"Delivered", statusConfirmed:"Confirmed",
    statusCancelled:"Cancelled", statusActive:"Active",
    statusInactive:"Inactive", statusApproved:"Approved",
    statusPending:"Pending", statusMissing:"Missing", statusNew:"New", statusDraft:"Draft",
  },
} satisfies Record<Lang, Record<string, unknown>>;

type TKey = keyof typeof T.en;

// ─── i18n ─────────────────────────────────────────────────────────────────────

const LangCtx = createContext<{ lang: Lang; t: (k: TKey) => string }>({ lang:"uz", t:(k)=>String(T.uz[k]) });
function useT() { return useContext(LangCtx); }

// ─── App Context (shared across routes) ──────────────────────────────────────

interface AppCtxType {
  role: Role;      setRole:      (r: Role)      => void;
  phone: string;   setPhone:     (p: string)    => void;
  themeMode: ThemeMode; setThemeMode: (m: ThemeMode) => void;
  lang: Lang;      setLang:      (l: Lang)      => void;
  isDark: boolean;
}
const AppCtx = createContext<AppCtxType>({} as AppCtxType);
function useApp() { return useContext(AppCtx); }

// ─── Mock Data ────────────────────────────────────────────────────────────────

const CITIES = [
  { id:1,  uz:"Toshkent",  ru:"Ташкент",   en:"Tashkent",  dist:true,  price:150_000 },
  { id:2,  uz:"Samarqand", ru:"Самарканд", en:"Samarkand", dist:false, price:150_000 },
  { id:3,  uz:"Buxoro",    ru:"Бухара",    en:"Bukhara",   dist:false, price:200_000 },
  { id:4,  uz:"Farg'ona",  ru:"Фергана",   en:"Fergana",   dist:true,  price:180_000 },
  { id:5,  uz:"Namangan",  ru:"Наманган",  en:"Namangan",  dist:false, price:190_000 },
  { id:6,  uz:"Andijon",   ru:"Андижан",   en:"Andijan",   dist:false, price:185_000 },
  { id:7,  uz:"Nukus",     ru:"Нукус",     en:"Nukus",     dist:false, price:280_000 },
  { id:8,  uz:"Termiz",    ru:"Термез",    en:"Termiz",    dist:false, price:250_000 },
  { id:9,  uz:"Qarshi",    ru:"Карши",     en:"Qarshi",    dist:false, price:220_000 },
  { id:10, uz:"Jizzax",    ru:"Джизак",    en:"Jizzakh",   dist:false, price:120_000 },
  { id:11, uz:"Guliston",  ru:"Гулистан",  en:"Guliston",  dist:false, price:130_000 },
  { id:12, uz:"Navoiy",    ru:"Навои",     en:"Navoi",     dist:false, price:210_000 },
];
type CityInfo = typeof CITIES[number];

const DISTRICTS: Record<number, string[]> = {
  1: ["Yunusobod","Chilonzor","Mirzo Ulug'bek","Yakkasaroy","Shayxontohur","Olmazor","Bektemir","Uchtepa","Yashnobod","Sergeli"],
  4: ["Marg'ilon","Quvasoy","Qo'qon","Rishton","O'zbekiston"],
};

interface LocationPoint { city: CityInfo; district?: string; address: string }
interface OrderDraft {
  pickup: LocationPoint | null; dropoff: LocationPoint | null;
  senderPhone: string; receiverPhone: string;
  pickupAddress: string; dropoffAddress: string;
  comment: string; hasPhoto: boolean;
}
const EMPTY_DRAFT: OrderDraft = { pickup:null, dropoff:null, senderPhone:"", receiverPhone:"", pickupAddress:"", dropoffAddress:"", comment:"", hasPhoto:false };

const clientOrders = [
  { id:"ORD-5010", from:"Tashkent", to:"Samarkand", status:"bidding",    price:150_000, pickup:"Yunusobod, Amir Temur 45", dropoff:"Registon ko'chasi 12", date:"Bugun",   bidsCount:3, hasDriver:false },
  { id:"ORD-4988", from:"Tashkent", to:"Fergana",   status:"in_transit", price:200_000, pickup:"Chilonzor",                dropoff:"Marg'ilon avtobekati", date:"Kecha",   bidsCount:1, hasDriver:true, driver:"Bobur Yusupov",    driverRating:4.6, driverCar:"Cobalt · Qora" },
  { id:"ORD-4920", from:"Samarkand",to:"Tashkent",  status:"delivered",  price:160_000, pickup:"Registon 5",              dropoff:"Yunusobod 88",          date:"20-iyun", bidsCount:2, hasDriver:true, driver:"Sherzod Karimov",  driverRating:4.9, driverCar:"Lacetti · Kumush" },
  { id:"ORD-4850", from:"Tashkent", to:"Bukhara",   status:"confirmed",  price:210_000, pickup:"Olmazor 33",              dropoff:"Ark qal'asi yaqini",    date:"15-iyun", bidsCount:1, hasDriver:true },
  { id:"ORD-4700", from:"Tashkent", to:"Namangan",  status:"cancelled",  price:190_000, pickup:"Mirzo Ulug'bek",          dropoff:"Shahar markazi",         date:"10-iyun", bidsCount:0, hasDriver:false },
];

const driverBids = [
  { id:1, name:"Jasur Toshmatov", rating:4.8, car:"Nexia 3 · Oq · 01A777AA",   price:140_000, completedOrders:143 },
  { id:2, name:"Bobur Yusupov",   rating:4.6, car:"Cobalt · Qora · 30B123CC",  price:145_000, completedOrders:89  },
  { id:3, name:"Sherzod Karimov", rating:4.9, car:"Lacetti · Kumush · 10C456BB",price:155_000,completedOrders:201 },
];

const clientNotifs = [
  { id:1, title:"Yangi taklif",     message:"Jasur 140 000 so'm taklif qildi (Toshkent → Samarqand)",  date:"5 daq.",  read:false, orderId:"ORD-5010" },
  { id:2, title:"Yangi taklif",     message:"Bobur 145 000 so'm taklif qildi",                          date:"12 daq.", read:false, orderId:"ORD-5010" },
  { id:3, title:"Yangi taklif",     message:"Sherzod 155 000 so'm taklif qildi",                        date:"20 daq.", read:false, orderId:"ORD-5010" },
  { id:4, title:"Yuk yo'lda",       message:"Toshkent → Farg'ona: haydovchi yukni olib ketdi",          date:"Kecha",   read:true,  orderId:"ORD-4988" },
  { id:5, title:"Yetkazib berildi", message:"Samarqand → Toshkent buyurtmangiz yetkazib berildi",       date:"20-iyun", read:true,  orderId:"ORD-4920" },
];

const driverData = {
  name:"Jasur Toshmatov", phone:"+998 90 123 45 67",
  status:"approved" as "approved"|"pending"|"new",
  available:true, rating:4.8, completedOrders:143, totalOrders:151, disputes:1,
  car:{ model:"Chevrolet Nexia 3", color:"White", plate:"01 A 777 AA" }, netIncome:4_820_000,
};
const routesData = [
  { id:1, from:"Toshkent", fromDistrict:"Yunusobod", to:"Samarqand", toDistrict:"",         status:"active"   },
  { id:2, from:"Toshkent", fromDistrict:"",           to:"Farg'ona",  toDistrict:"Marg'ilon", status:"active"   },
  { id:3, from:"Samarqand",fromDistrict:"",           to:"Buxoro",   toDistrict:"",          status:"inactive" },
];
const driverOrders = [
  { id:"ORD-4821", from:"Toshkent", to:"Samarqand", status:"published", price:150_000, pickup:"Yunusobod",    dropoff:"Registon",   date:"Bugun, 14:30", hasBid:false },
  { id:"ORD-4798", from:"Toshkent", to:"Samarqand", status:"bidding",   price:180_000, pickup:"Mirzo Ulugbek",dropoff:"Markaz",     date:"Bugun, 12:00", hasBid:true, bidPrice:175_000 },
  { id:"ORD-4755", from:"Toshkent", to:"Farg'ona",  status:"published", price:220_000, pickup:"Chilonzor",    dropoff:"Marg'ilon",  date:"Kecha",         hasBid:false },
];
const activeDriverOrder = {
  id:"ORD-4702", from:"Toshkent", to:"Samarqand", status:"in_transit",
  gross:160_000, commission:16_000, net:144_000,
  pickup:"Yunusobod, Amir Temur ko'chasi 45", dropoff:"Registon ko'chasi 12, kv. 3",
  sender:"+998 90 111 22 33", receiver:"+998 93 444 55 66",
  comment:"Mo'rt buyum, ehtiyot bo'ling", date:"24-iyun 2026",
};
const dailyData   = [{day:"Du",amount:320_000},{day:"Se",amount:0},{day:"Ch",amount:480_000},{day:"Pa",amount:160_000},{day:"Ju",amount:144_000},{day:"Sh",amount:620_000},{day:"Ya",amount:290_000}];
const monthlyData = [{month:"Yan",amount:3_200_000},{month:"Fev",amount:2_800_000},{month:"Mar",amount:4_100_000},{month:"Apr",amount:3_600_000},{month:"May",amount:5_200_000},{month:"Iyu",amount:4_820_000}];
const recentEarnings = [
  {id:"ORD-4702",from:"Toshkent",to:"Samarqand",date:"24-iyun",net:144_000},
  {id:"ORD-4688",from:"Toshkent",to:"Samarqand",date:"22-iyun",net:176_000},
  {id:"ORD-4651",from:"Toshkent",to:"Farg'ona", date:"20-iyun",net:198_000},
  {id:"ORD-4630",from:"Samarqand",to:"Toshkent",date:"18-iyun",net:144_000},
];
const driverDocs = [
  {type:"Passport",status:"approved" as const},{type:"Selfie",status:"approved" as const},
  {type:"Driver License",status:"approved" as const},{type:"Car Document",status:"pending" as const},
  {type:"Car Photo",status:"missing" as const},
];

// ─── Shared Helpers ───────────────────────────────────────────────────────────

function fmt(n: number) { return n.toLocaleString("ru-RU") + " so'm"; }

function StatusBadge({ status }: { status: string }) {
  const { t } = useT();
  const map: Record<string,{label:string;cls:string}> = {
    published:  {label:t("statusPublished"),  cls:"bg-blue-500/15 text-blue-400 border-blue-500/20"},
    bidding:    {label:t("statusBidding"),    cls:"bg-amber-500/15 text-amber-400 border-amber-500/20"},
    accepted:   {label:t("statusAccepted"),   cls:"bg-blue-600/15 text-blue-300 border-blue-600/20"},
    in_transit: {label:t("statusInTransit"),  cls:"bg-indigo-500/15 text-indigo-400 border-indigo-500/20"},
    delivered:  {label:t("statusDelivered"),  cls:"bg-green-500/15 text-green-400 border-green-500/20"},
    confirmed:  {label:t("statusConfirmed"),  cls:"bg-green-600/15 text-green-300 border-green-600/20"},
    cancelled:  {label:t("statusCancelled"),  cls:"bg-red-500/15 text-red-400 border-red-500/20"},
    active:     {label:t("statusActive"),     cls:"bg-green-500/15 text-green-400 border-green-500/20"},
    inactive:   {label:t("statusInactive"),   cls:"bg-zinc-500/15 text-zinc-400 border-zinc-500/20"},
    approved:   {label:t("statusApproved"),   cls:"bg-green-500/15 text-green-400 border-green-500/20"},
    pending:    {label:t("statusPending"),    cls:"bg-amber-500/15 text-amber-400 border-amber-500/20"},
    missing:    {label:t("statusMissing"),    cls:"bg-red-500/15 text-red-400 border-red-500/20"},
    new:        {label:t("statusNew"),        cls:"bg-zinc-500/15 text-zinc-400 border-zinc-500/20"},
    draft:      {label:t("statusDraft"),      cls:"bg-zinc-500/15 text-zinc-400 border-zinc-500/20"},
  };
  const d = map[status] ?? {label:status, cls:"bg-zinc-500/15 text-zinc-400 border-zinc-500/20"};
  return <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-medium border font-mono ${d.cls}`}>{d.label}</span>;
}

function BackHeader({ onBack, title, right }: { onBack:()=>void; title:string; right?:React.ReactNode }) {
  return (
    <div className="flex items-center gap-3 p-4 border-b border-border flex-shrink-0">
      <button onClick={onBack} className="p-2 rounded-xl bg-secondary"><ChevronLeft size={18} className="text-foreground"/></button>
      <h1 className="text-base font-semibold text-foreground flex-1">{title}</h1>
      {right}
    </div>
  );
}

function ElchiLogo({ size=40 }: { size?:number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="rounded-2xl bg-primary flex items-center justify-center" style={{width:size,height:size}}>
        <Truck size={size*0.5} className="text-white"/>
      </div>
      <span className="text-2xl font-bold text-foreground tracking-tight">elchi</span>
    </div>
  );
}

function SettingsPanel({ onBack, themeMode, onThemeChange, lang, onLangChange, onLogout, notifKeys }: {
  onBack:()=>void; themeMode:ThemeMode; onThemeChange:(m:ThemeMode)=>void;
  lang:Lang; onLangChange:(l:Lang)=>void; onLogout:()=>void;
  notifKeys: { a:string; ad:string; b:string; bd:string }
}) {
  const { t } = useT();
  const [na,setNa] = useState(true); const [nb,setNb] = useState(true);
  const [np,setNp] = useState(false); const [vib,setVib] = useState(true);
  const themeOpts = [
    {id:"light" as ThemeMode,icon:Sun,     label:t("lightTheme"),  desc:t("alwaysLight")   },
    {id:"dark"  as ThemeMode,icon:Moon,    label:t("darkTheme"),   desc:t("alwaysDark")    },
    {id:"system"as ThemeMode,icon:Monitor, label:t("systemTheme"), desc:t("followsDevice") },
  ];
  const langs = [{id:"uz" as Lang,flag:"🇺🇿",label:"O'zbek"},{id:"ru" as Lang,flag:"🇷🇺",label:"Русский"},{id:"en" as Lang,flag:"🇬🇧",label:"English"}];
  return (
    <div className="flex flex-col h-full">
      <BackHeader onBack={onBack} title={t("settings")}/>
      <div className="flex-1 overflow-y-auto scrollbar-hide p-4 flex flex-col gap-5 pb-8">
        <section>
          <p className="text-[10px] font-semibold text-muted-foreground font-mono uppercase tracking-widest mb-2 px-1">{t("appearance")}</p>
          <div className="rounded-2xl border border-border bg-card p-4">
            <div className="grid grid-cols-3 gap-2">
              {themeOpts.map(({id,icon:Icon,label,desc})=>{
                const act=themeMode===id;
                return (
                  <button key={id} onClick={()=>onThemeChange(id)}
                    className={`flex flex-col items-center gap-1.5 rounded-xl py-3 px-2 border-2 transition-all ${act?"border-primary bg-primary/10":"border-border bg-secondary/50"}`}>
                    <Icon size={20} className={act?"text-primary":"text-muted-foreground"} strokeWidth={act?2.5:1.5}/>
                    <p className={`text-xs font-semibold ${act?"text-primary":"text-foreground"}`}>{label}</p>
                    <p className="text-[9px] text-muted-foreground leading-tight text-center">{desc}</p>
                  </button>
                );
              })}
            </div>
          </div>
        </section>
        <section>
          <p className="text-[10px] font-semibold text-muted-foreground font-mono uppercase tracking-widest mb-2 px-1">{t("language")}</p>
          <div className="rounded-2xl border border-border bg-card p-3 flex gap-2">
            {langs.map(({id,flag,label})=>(
              <button key={id} onClick={()=>onLangChange(id)}
                className={`flex-1 flex flex-col items-center gap-1 py-2.5 rounded-xl border-2 transition-all ${lang===id?"border-primary bg-primary/10":"border-border bg-secondary/50"}`}>
                <span className="text-xl text-[#ffffff]">{flag}</span>
                <span className={`text-[11px] font-semibold ${lang===id?"text-primary":"text-foreground"}`}>{label}</span>
              </button>
            ))}
          </div>
        </section>
        <section>
          <p className="text-[10px] font-semibold text-muted-foreground font-mono uppercase tracking-widest mb-2 px-1">{t("notifications2")}</p>
          <div className="rounded-2xl border border-border bg-card overflow-hidden divide-y divide-border">
            {[
              {label:t(notifKeys.a as TKey),sub:t(notifKeys.ad as TKey),val:na, set:setNa, icon:Package,    cls:"bg-indigo-500/10 text-indigo-400"},
              {label:t(notifKeys.b as TKey),sub:t(notifKeys.bd as TKey),val:nb, set:setNb, icon:Bell,       cls:"bg-amber-500/10 text-amber-400"},
              {label:t("promotions"),       sub:t("promotionsDesc"),    val:np, set:setNp, icon:TrendingUp,  cls:"bg-green-500/10 text-green-400"},
              {label:t("vibration"),        sub:t("vibrationDesc"),     val:vib,set:setVib,icon:Vibrate,     cls:"bg-purple-500/10 text-purple-400"},
            ].map(({label,sub,val,set,icon:Icon,cls})=>(
              <div key={label} className="flex items-center gap-3 px-4 py-3.5">
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${cls}`}><Icon size={15}/></div>
                <div className="flex-1 min-w-0"><p className="text-sm font-medium text-foreground">{label}</p><p className="text-[11px] text-muted-foreground">{sub}</p></div>
                <button onClick={()=>set(!val)}>{val?<ToggleRight size={34} className="text-primary"/>:<ToggleLeft size={34} className="text-muted-foreground"/>}</button>
              </div>
            ))}
          </div>
        </section>
        <section>
          <p className="text-[10px] font-semibold text-muted-foreground font-mono uppercase tracking-widest mb-2 px-1">{t("account")}</p>
          <div className="rounded-2xl border border-border bg-card overflow-hidden divide-y divide-border">
            {[
              {icon:Shield,   label:t("privacySecurity"),cls:"bg-green-500/10 text-green-400"},
              {icon:FileText, label:t("termsOfService"), cls:"bg-sky-500/10 text-sky-400"},
              {icon:Info,     label:t("aboutElchi"),     cls:"bg-zinc-500/10 text-muted-foreground"},
            ].map(({icon:Icon,label,cls})=>(
              <button key={label} className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-secondary/40 transition-colors">
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${cls}`}><Icon size={15}/></div>
                <span className="text-sm font-medium text-foreground flex-1 text-left">{label}</span>
                <ChevronRight size={14} className="text-muted-foreground"/>
              </button>
            ))}
          </div>
        </section>
        <div className="rounded-2xl border border-red-500/20 bg-card overflow-hidden">
          <button onClick={onLogout} className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-red-500/5 transition-colors">
            <div className="w-8 h-8 rounded-xl bg-red-500/10 flex items-center justify-center"><LogOut size={15} className="text-red-400"/></div>
            <span className="text-sm font-medium text-red-400 flex-1 text-left">{t("logOut")}</span>
          </button>
        </div>
        <p className="text-center text-[10px] text-muted-foreground font-mono">{t("version")}</p>
      </div>
    </div>
  );
}

// ─── Auth Screens ─────────────────────────────────────────────────────────────

function SplashScreen({ onDone }: { onDone:()=>void }) {
  const { t } = useT();
  useEffect(()=>{ const id=setTimeout(onDone,2000); return()=>clearTimeout(id); },[onDone]);
  return (
    <div className="flex flex-col items-center justify-center h-full bg-background gap-4">
      <div className="relative">
        <div className="w-20 h-20 rounded-[26px] bg-primary flex items-center justify-center shadow-lg shadow-primary/30"><Truck size={36} className="text-white"/></div>
        <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-green-400 border-2 border-background flex items-center justify-center"><div className="w-2 h-2 rounded-full bg-white"/></div>
      </div>
      <div className="text-center">
        <h1 className="text-3xl font-bold text-foreground tracking-tight">elchi</h1>
        <p className="text-sm text-muted-foreground mt-1">{t("splashTagline")}</p>
      </div>
      <div className="absolute bottom-14 flex gap-1.5">
        {[0,1,2].map(i=><div key={i} className={`h-1.5 rounded-full bg-primary ${i===1?"w-6":"w-1.5 opacity-40"}`}/>)}
      </div>
    </div>
  );
}

function OnboardingScreen({ onContinue }: { onContinue:()=>void }) {
  const { t } = useT();
  const [idx,setIdx] = useState(0);
  const slides = [
    {icon:Route,     col:"bg-blue-500/15",  ic:"text-primary",     title:t("onboardingTitle"), desc:t("onboardingDesc")},
    {icon:MapPin,    col:"bg-green-500/15", ic:"text-green-400",   title:"365 km bo'ylab",     desc:"Toshkent, Samarqand, Buxoro, Farg'ona va boshqa shaharlar"},
    {icon:TrendingUp,col:"bg-amber-500/15", ic:"text-amber-400",   title:"Daromadingizni kuzating", desc:"Har bir buyurtma uchun sof daromadingizni ko'ring"},
  ];
  const s = slides[idx];
  return (
    <div className="flex flex-col h-full bg-background px-6 pt-12 pb-8">
      <ElchiLogo size={36}/>
      <div className="flex-1 flex flex-col items-center justify-center text-center gap-6 py-8">
        <div className={`w-24 h-24 rounded-3xl flex items-center justify-center ${s.col}`}><s.icon size={44} className={s.ic}/></div>
        <div className="flex gap-1.5 justify-center">
          {slides.map((_,i)=><button key={i} onClick={()=>setIdx(i)} className={`h-1.5 rounded-full bg-primary transition-all ${i===idx?"w-6":"w-1.5 opacity-30"}`}/>)}
        </div>
        <div><h2 className="text-2xl font-bold text-foreground mb-2">{s.title}</h2><p className="text-sm text-muted-foreground leading-relaxed max-w-xs mx-auto">{s.desc}</p></div>
      </div>
      <button onClick={onContinue} className="w-full bg-primary text-white rounded-2xl py-4 text-base font-semibold flex items-center justify-center gap-2">
        {t("onboardingCta")}<ArrowRight size={18}/>
      </button>
    </div>
  );
}

function RoleSelectScreen({ onSelect, onBack }: { onSelect:(r:Role)=>void; onBack:()=>void }) {
  const { t } = useT();
  return (
    <div className="flex flex-col h-full bg-background px-5 pt-10 pb-8">
      <button onClick={onBack} className="self-start p-2 rounded-xl bg-secondary mb-6"><ChevronLeft size={18} className="text-foreground"/></button>
      <ElchiLogo size={36}/>
      <div className="mt-6 mb-8"><h2 className="text-2xl font-bold text-foreground">{t("roleTitle")}</h2><p className="text-sm text-muted-foreground mt-1">{t("roleDesc")}</p></div>
      <div className="flex flex-col gap-4 flex-1">
        <button onClick={()=>onSelect("driver")} className="flex items-center gap-4 rounded-2xl border-2 border-primary bg-primary/5 p-5 text-left active:scale-[0.98] transition-all">
          <div className="w-14 h-14 rounded-2xl bg-primary/15 flex items-center justify-center flex-shrink-0"><Truck size={26} className="text-primary"/></div>
          <div className="flex-1"><p className="text-base font-bold text-foreground">{t("roleDriver")}</p><p className="text-sm text-muted-foreground">{t("roleDriverDesc")}</p></div>
          <ChevronRight size={18} className="text-primary"/>
        </button>
        <button onClick={()=>onSelect("client")} className="flex items-center gap-4 rounded-2xl border-2 border-border bg-card p-5 text-left active:scale-[0.98] transition-all hover:border-primary/30">
          <div className="w-14 h-14 rounded-2xl bg-secondary flex items-center justify-center flex-shrink-0"><Package size={26} className="text-muted-foreground"/></div>
          <div className="flex-1"><p className="text-base font-bold text-foreground">{t("roleClient")}</p><p className="text-sm text-muted-foreground">{t("roleClientDesc")}</p></div>
          <ChevronRight size={18} className="text-muted-foreground"/>
        </button>
      </div>
      <button onClick={()=>onSelect("admin")} className="flex items-center justify-center gap-2 mt-2 text-xs text-muted-foreground hover:text-foreground transition-colors py-2">
        <ShieldCheck size={13}/> Admin Panel →
      </button>
      <p className="text-center text-xs text-muted-foreground mt-2">Elchi · UZ · {new Date().getFullYear()}</p>
    </div>
  );
}

function PhoneScreen({ role, onSubmit, onBack }: { role:Role; onSubmit:(p:string)=>void; onBack:()=>void }) {
  const { t } = useT();
  const [phone,setPhone] = useState("+998 ");
  const [error,setError] = useState("");
  const [loading,setLoading] = useState(false);
  function fmtPhone(raw:string) {
    const d=raw.replace(/\D/g,"").slice(0,12);
    if(d.length<=3) return `+${d}`;
    if(d.length<=5) return `+${d.slice(0,3)} ${d.slice(3)}`;
    if(d.length<=8) return `+${d.slice(0,3)} ${d.slice(3,5)} ${d.slice(5)}`;
    if(d.length<=10) return `+${d.slice(0,3)} ${d.slice(3,5)} ${d.slice(5,8)} ${d.slice(8)}`;
    return `+${d.slice(0,3)} ${d.slice(3,5)} ${d.slice(5,8)} ${d.slice(8,10)} ${d.slice(10)}`;
  }
  function handleChange(v:string) { if(!v.startsWith("+998")){setPhone("+998 ");return;} setPhone(fmtPhone(v)); if(error)setError(""); }
  function handleSubmit() { const d=phone.replace(/\D/g,""); if(d.length<12){setError(t("phoneError"));return;} setLoading(true); setTimeout(()=>{setLoading(false);onSubmit(phone);},1000); }
  const RoleIcon = role==="driver"?Truck:Package;
  return (
    <div className="flex flex-col h-full bg-background px-5 pt-10 pb-8">
      <button onClick={onBack} className="self-start p-2 rounded-xl bg-secondary mb-6"><ChevronLeft size={18} className="text-foreground"/></button>
      <div className="flex items-center gap-2 mb-6">
        <div className="w-8 h-8 rounded-xl bg-primary/15 flex items-center justify-center"><RoleIcon size={15} className="text-primary"/></div>
        <span className="text-xs font-medium text-muted-foreground">{t("as")} <span className="text-foreground font-semibold">{t(role==="driver"?"roleDriver":"roleClient")}</span></span>
      </div>
      <h2 className="text-2xl font-bold text-foreground mb-1">{t("phoneTitle")}</h2>
      <p className="text-sm text-muted-foreground mb-8">{t("phoneDesc")}</p>
      <div className="flex-1">
        <label className="text-xs font-medium text-muted-foreground mb-2 block">{t("phoneLabel")}</label>
        <div className={`flex items-center gap-3 bg-input-background border rounded-2xl px-4 py-4 mb-2 transition-colors ${error?"border-red-500/50":"border-border focus-within:border-primary/60"}`}>
          <span className="text-2xl">🇺🇿</span>
          <input type="tel" autoFocus className="flex-1 bg-transparent text-lg font-bold font-mono text-foreground placeholder:text-muted-foreground outline-none"
            placeholder="+998 XX XXX XX XX" value={phone} onChange={e=>handleChange(e.target.value)}/>
        </div>
        {error && <p className="text-xs text-red-400 flex items-center gap-1"><AlertCircle size={11}/>{error}</p>}
      </div>
      <button onClick={handleSubmit} disabled={loading} className="w-full bg-primary text-white rounded-2xl py-4 text-base font-semibold flex items-center justify-center gap-2 disabled:opacity-70">
        {loading?<span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"/>:<><Send size={16}/>{t("phoneCta")}</>}
      </button>
    </div>
  );
}

function OtpScreen({ phone, onVerify, onBack }: { phone:string; role:Role; onVerify:()=>void; onBack:()=>void }) {
  const { t } = useT();
  const [otp,setOtp] = useState(["","","","","",""]);
  const [error,setError] = useState("");
  const [loading,setLoading] = useState(false);
  const [resend,setResend] = useState(59);
  const refs = useRef<(HTMLInputElement|null)[]>([]);
  useEffect(()=>{ if(resend<=0)return; const id=setInterval(()=>setResend(s=>s-1),1000); return()=>clearInterval(id); },[resend]);
  function dig(i:number,v:string){ const d=v.replace(/\D/g,"").slice(-1); const n=[...otp]; n[i]=d; setOtp(n); setError(""); if(d&&i<5)refs.current[i+1]?.focus(); if(!d&&i>0)refs.current[i-1]?.focus(); }
  function kd(i:number,e:React.KeyboardEvent){ if(e.key==="Backspace"&&!otp[i]&&i>0)refs.current[i-1]?.focus(); }
  function paste(e:React.ClipboardEvent){ const txt=e.clipboardData.getData("text").replace(/\D/g,"").slice(0,6); if(txt.length===6){setOtp(txt.split(""));refs.current[5]?.focus();} e.preventDefault(); }
  function verify(){ const code=otp.join(""); if(code.length<6){setError(t("otpError"));return;} if(code==="000000"){setError(t("otpError"));return;} setLoading(true); setTimeout(()=>{setLoading(false);onVerify();},1200); }
  return (
    <div className="flex flex-col h-full bg-background px-5 pt-10 pb-8">
      <button onClick={onBack} className="self-start p-2 rounded-xl bg-secondary mb-6"><ChevronLeft size={18} className="text-foreground"/></button>
      <h2 className="text-2xl font-bold text-foreground mb-1">{t("otpTitle")}</h2>
      <p className="text-sm text-muted-foreground mb-1">{t("otpDesc")}</p>
      <p className="text-sm font-mono font-semibold text-foreground mb-8">{phone}</p>
      <div className="flex gap-2.5 justify-center mb-3" onPaste={paste}>
        {otp.map((d,i)=>(
          <input key={i} ref={el=>{refs.current[i]=el;}} type="text" inputMode="numeric" maxLength={1} value={d}
            onChange={e=>dig(i,e.target.value)} onKeyDown={e=>kd(i,e)} autoFocus={i===0}
            className={`w-12 h-14 rounded-2xl border-2 text-center text-xl font-bold font-mono text-foreground bg-input-background outline-none transition-all ${d?"border-primary bg-primary/5":error?"border-red-500/50":"border-border focus:border-primary/60"}`}/>
        ))}
      </div>
      {error && <p className="text-xs text-red-400 text-center flex items-center justify-center gap-1 mb-3"><AlertCircle size={11}/>{error}</p>}
      <div className="flex justify-center mb-8">
        {resend>0
          ?<p className="text-xs text-muted-foreground font-mono">{t("otpResendIn")} 0:{resend.toString().padStart(2,"0")}</p>
          :<button onClick={()=>setResend(59)} className="flex items-center gap-1 text-xs text-primary font-medium"><RefreshCw size={11}/>{t("otpResend")}</button>}
      </div>
      <div className="flex-1"/>
      <button onClick={verify} disabled={!otp.every(d=>d)||loading}
        className="w-full bg-primary text-white rounded-2xl py-4 text-base font-semibold flex items-center justify-center gap-2 disabled:opacity-50">
        {loading?<span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"/>:t("otpVerify")}
      </button>
      <p className="text-center text-[10px] text-muted-foreground mt-4 font-mono">Demo: 000000 dan tashqari istalgan 6 ta raqam</p>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// CLIENT APP
// ═══════════════════════════════════════════════════════════════════════════════

function ClientHomeScreen({ onSelectFrom, onSelectTo, draft, onViewRoute }: {
  onSelectFrom:()=>void; onSelectTo:()=>void; draft:OrderDraft; onViewRoute:()=>void;
}) {
  const { t } = useT();
  const can = draft.pickup!==null && draft.dropoff!==null;
  return (
    <div className="flex flex-col h-full relative">
      <div className="absolute inset-0">
        <img src="https://images.unsplash.com/photo-1524661135-423995f22d0b?w=800&h=900&fit=crop&auto=format" alt="map" className="w-full h-full object-cover"/>
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/10"/>
      </div>
      <div className="relative z-10 flex justify-end p-4 pt-2">
        <button className="w-10 h-10 rounded-xl bg-card border border-border flex items-center justify-center shadow-md"><Locate size={16} className="text-primary"/></button>
      </div>
      {draft.pickup && (
        <div className="absolute top-[38%] left-[38%] z-10">
          <div className="w-8 h-8 rounded-full bg-primary border-2 border-white shadow-lg flex items-center justify-center"><Navigation size={14} className="text-white"/></div>
        </div>
      )}
      {draft.dropoff && (
        <div className="absolute top-[28%] left-[58%] z-10">
          <div className="w-8 h-8 rounded-full bg-green-400 border-2 border-white shadow-lg flex items-center justify-center"><MapPin size={14} className="text-white"/></div>
        </div>
      )}
      <div className="absolute bottom-0 left-0 right-0 z-20 bg-background rounded-t-[28px] border-t border-border shadow-2xl">
        <div className="flex justify-center pt-3 pb-1"><div className="w-10 h-1 rounded-full bg-border"/></div>
        <div className="px-5 pt-2 pb-6">
          <div className="mb-4"><h2 className="text-lg font-bold text-foreground">{t("sendParcel")}</h2><p className="text-xs text-muted-foreground mt-0.5">{t("chooseExactAddress")}</p></div>
          {/* Pickup */}
          <div className="flex items-center gap-3 mb-2">
            <div className="w-2.5 h-2.5 rounded-full bg-primary border-2 border-primary/30 flex-shrink-0"/>
            <div className="flex-1 min-w-0">
              {draft.pickup
                ?<><p className="text-sm font-semibold text-foreground truncate">{draft.pickup.district||draft.pickup.city.en}</p><p className="text-[11px] text-muted-foreground">{draft.pickup.city.en}{draft.pickup.district?` · ${draft.pickup.district}`:""}</p></>
                :<p className="text-sm text-muted-foreground">{t("selectPickup")}</p>}
            </div>
            <button onClick={onSelectFrom} className="text-xs text-primary font-medium bg-primary/10 px-2.5 py-1 rounded-lg flex-shrink-0">{t("changeBtn")}</button>
          </div>
          <div className="ml-1 w-px h-4 bg-border mb-2"/>
          {/* Dropoff */}
          <div className="flex items-center gap-3 mb-4">
            <div className="w-2.5 h-2.5 rounded-full bg-green-400 border-2 border-green-400/30 flex-shrink-0"/>
            <div className="flex-1 min-w-0">
              {draft.dropoff
                ?<><p className="text-sm font-semibold text-foreground truncate">{draft.dropoff.district||draft.dropoff.city.en}</p><p className="text-[11px] text-muted-foreground">{draft.dropoff.city.en}{draft.dropoff.district?` · ${draft.dropoff.district}`:""}</p></>
                :<p className="text-sm text-muted-foreground">{t("selectDropoff")}</p>}
            </div>
            <button onClick={onSelectTo} className="text-xs text-primary font-medium bg-primary/10 px-2.5 py-1 rounded-lg flex-shrink-0">{t("changeBtn")}</button>
          </div>
          {/* Stats */}
          <div className="flex gap-3 mb-4 py-3 border-y border-border">
            {[{label:t("activeStat"),value:"2"},{label:t("bidsStat"),value:"3"},{label:t("completedStat"),value:"4"}].map(({label,value})=>(
              <div key={label} className="flex-1 text-center"><p className="text-base font-bold font-mono text-foreground">{value}</p><p className="text-[10px] text-muted-foreground">{label}</p></div>
            ))}
          </div>
          {!can && <p className="text-xs text-amber-400 flex items-center gap-1 mb-2"><AlertCircle size={11}/>{t("cityNotSelected")}</p>}
          <button onClick={onViewRoute} disabled={!can}
            className="w-full bg-primary text-white rounded-2xl py-3.5 text-sm font-semibold disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2">
            <ArrowRight size={16}/>{t("viewRoute")}
          </button>
        </div>
      </div>
    </div>
  );
}

function CitySelectScreen({ title, onBack, onSelect }: { title:string; onBack:()=>void; onSelect:(c:CityInfo)=>void }) {
  const { t, lang } = useT();
  const [q,setQ] = useState("");
  const filtered = CITIES.filter(c => [c.uz,c.ru,c.en].some(n=>n.toLowerCase().includes(q.toLowerCase())));
  const name = (c:CityInfo) => lang==="ru"?c.ru:lang==="en"?c.en:c.uz;
  return (
    <div className="flex flex-col h-full">
      <BackHeader onBack={onBack} title={title}/>
      <div className="p-4 pb-2">
        <div className="flex items-center gap-2 bg-input-background border border-border rounded-xl px-3 py-2.5">
          <Search size={14} className="text-muted-foreground flex-shrink-0"/>
          <input autoFocus className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none" placeholder={t("searchCity")} value={q} onChange={e=>setQ(e.target.value)}/>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto">
        {filtered.length===0
          ?<div className="flex flex-col items-center py-16 text-muted-foreground"><Search size={32} className="opacity-30 mb-2"/><p className="text-sm">{t("noResults")}</p></div>
          :filtered.map(c=>(
            <button key={c.id} onClick={()=>onSelect(c)} className="w-full flex items-center gap-3 px-4 py-3.5 border-b border-border hover:bg-secondary/40 transition-colors">
              <MapPin size={14} className="text-primary flex-shrink-0"/>
              <div className="flex-1 text-left">
                <p className="text-sm font-medium text-foreground">{name(c)}</p>
                {c.dist && <p className="text-[10px] text-muted-foreground font-mono">Tumanlar mavjud</p>}
              </div>
              {c.dist && <ChevronRight size={14} className="text-muted-foreground"/>}
            </button>
          ))}
      </div>
    </div>
  );
}

function DistrictSelectScreen({ city, onBack, onSelect }: { city:CityInfo; onBack:()=>void; onSelect:(d:string)=>void }) {
  const { t } = useT();
  const [q,setQ] = useState("");
  const all = DISTRICTS[city.id] || [];
  const filtered = all.filter(d=>d.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="flex flex-col h-full">
      <BackHeader onBack={onBack} title={t("chooseDistrict")}/>
      <div className="p-4 pb-2">
        <div className="flex items-center gap-2 bg-input-background border border-border rounded-xl px-3 py-2.5">
          <Search size={14} className="text-muted-foreground flex-shrink-0"/>
          <input autoFocus className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none" placeholder={t("searchDistrict")} value={q} onChange={e=>setQ(e.target.value)}/>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto">
        {filtered.length===0
          ?<div className="flex flex-col items-center py-16 text-muted-foreground"><Search size={32} className="opacity-30 mb-2"/><p className="text-sm">{t("noDistricts")}</p></div>
          :filtered.map(d=>(
            <button key={d} onClick={()=>onSelect(d)} className="w-full flex items-center gap-3 px-4 py-3.5 border-b border-border hover:bg-secondary/40 transition-colors">
              <div className="w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0"/>
              <p className="text-sm font-medium text-foreground flex-1 text-left">{d}</p>
              <ChevronRight size={14} className="text-muted-foreground"/>
            </button>
          ))}
      </div>
    </div>
  );
}

function MapPickerScreen({ city, district, onBack, onConfirm }: { city:CityInfo; district?:string; onBack:()=>void; onConfirm:(addr:string)=>void }) {
  const { t } = useT();
  const [addr,setAddr] = useState(district?`${district}, ${city.en}`:city.en);
  return (
    <div className="flex flex-col h-full relative">
      <div className="absolute inset-0">
        <img src="https://images.unsplash.com/photo-1569336415962-a4bd9f69c51f?w=800&h=900&fit=crop&auto=format" alt="map" className="w-full h-full object-cover"/>
        <div className="absolute inset-0 bg-black/20"/>
      </div>
      <div className="relative z-10 flex items-center gap-3 p-4">
        <button onClick={onBack} className="p-2 rounded-xl bg-card border border-border shadow"><ChevronLeft size={18} className="text-foreground"/></button>
        <div className="flex-1 bg-card border border-border rounded-xl px-3 py-2 flex items-center gap-2 shadow">
          <Search size={13} className="text-muted-foreground"/><input className="flex-1 bg-transparent text-sm text-foreground outline-none" value={addr} onChange={e=>setAddr(e.target.value)} placeholder={t("manualAddress")}/>
        </div>
      </div>
      <div className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none" style={{paddingBottom:200}}>
        <div className="flex flex-col items-center">
          <div className="w-10 h-10 rounded-full bg-primary border-4 border-white shadow-xl flex items-center justify-center"><MapPin size={18} className="text-white"/></div>
          <div className="w-2 h-2 bg-primary/40 rounded-full mt-0.5"/>
        </div>
      </div>
      <button className="absolute right-4 bottom-52 z-10 w-10 h-10 rounded-xl bg-card border border-border shadow flex items-center justify-center"><Locate size={16} className="text-primary"/></button>
      <div className="absolute bottom-0 left-0 right-0 z-20 bg-background rounded-t-[28px] border-t border-border p-5">
        <div className="flex justify-center mb-3"><div className="w-10 h-1 rounded-full bg-border"/></div>
        <p className="text-[10px] text-muted-foreground font-mono uppercase tracking-wide mb-1">{t("confirmLocation")}</p>
        <div className="flex items-start gap-2 mb-4"><MapPin size={14} className="text-primary mt-0.5 flex-shrink-0"/><p className="text-sm font-semibold text-foreground">{addr}</p></div>
        <button onClick={()=>onConfirm(addr)} className="w-full bg-primary text-white rounded-2xl py-3 text-sm font-semibold">{t("confirmLocation")}</button>
      </div>
    </div>
  );
}

function ContactsScreen({ draft, onChange, onBack, onNext }: { draft:OrderDraft; onChange:(d:Partial<OrderDraft>)=>void; onBack:()=>void; onNext:()=>void }) {
  const { t } = useT();
  const [errs,setErrs] = useState<Record<string,string>>({});
  function validate() {
    const e:Record<string,string>={};
    if(!draft.senderPhone) e.senderPhone=t("phoneError");
    if(!draft.receiverPhone) e.receiverPhone=t("phoneError");
    if(!draft.pickupAddress) e.pickupAddress="Kiriting";
    if(!draft.dropoffAddress) e.dropoffAddress="Kiriting";
    setErrs(e); return Object.keys(e).length===0;
  }
  const fields = [
    {label:t("senderPhone"),   key:"senderPhone",   ph:"+998 XX XXX XX XX", icon:Phone},
    {label:t("receiverPhone"), key:"receiverPhone",  ph:"+998 XX XXX XX XX", icon:Phone},
    {label:t("pickupAddress"), key:"pickupAddress",  ph:"Ko'cha, uy raqami",  icon:Navigation},
    {label:t("dropoffAddress"),key:"dropoffAddress", ph:"Ko'cha, uy raqami",  icon:MapPin},
  ];
  return (
    <div className="flex flex-col h-full">
      <BackHeader onBack={onBack} title={t("contactsTitle")}/>
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
        {fields.map(({label,key,ph,icon:Icon})=>(
          <div key={key}>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">{label}</label>
            <div className={`flex items-center gap-3 bg-input-background border rounded-xl px-4 py-3 transition-colors ${errs[key]?"border-red-500/50":"border-border focus-within:border-primary/60"}`}>
              <Icon size={14} className="text-muted-foreground flex-shrink-0"/>
              <input className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none font-mono" placeholder={ph}
                value={(draft as Record<string,string>)[key]}
                onChange={e=>{ onChange({[key]:e.target.value}); if(errs[key])setErrs(p=>({...p,[key]:""})); }}/>
            </div>
            {errs[key] && <p className="text-xs text-red-400 mt-1 flex items-center gap-1"><AlertCircle size={10}/>{errs[key]}</p>}
          </div>
        ))}
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-1.5 block">{t("commentOptional")}</label>
          <textarea rows={2} className="w-full bg-input-background border border-border rounded-xl px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground outline-none resize-none focus:border-primary/60 transition-colors"
            placeholder={t("commentPlaceholder")} value={draft.comment} onChange={e=>onChange({comment:e.target.value})}/>
        </div>
      </div>
      <div className="p-4 border-t border-border">
        <button onClick={()=>{ if(validate()) onNext(); }} className="w-full bg-primary text-white rounded-2xl py-3.5 text-sm font-semibold">{t("nextBtn")}</button>
      </div>
    </div>
  );
}

function CargoPhotoScreen({ draft, onChange, onBack, onNext }: { draft:OrderDraft; onChange:(d:Partial<OrderDraft>)=>void; onBack:()=>void; onNext:()=>void }) {
  const { t } = useT();
  const [uploading,setUploading] = useState(false);
  function handleUpload(){ setUploading(true); setTimeout(()=>{setUploading(false);onChange({hasPhoto:true});},1500); }
  return (
    <div className="flex flex-col h-full">
      <BackHeader onBack={onBack} title={t("cargoPhotoTitle")}/>
      <div className="flex-1 flex flex-col items-center justify-center p-6 gap-6">
        {draft.hasPhoto
          ?<div className="w-full rounded-2xl overflow-hidden border border-green-500/30 bg-green-500/5">
            <img src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=250&fit=crop&auto=format" alt="cargo" className="w-full h-48 object-cover"/>
            <div className="p-4 flex items-center gap-2"><CheckCircle2 size={16} className="text-green-400"/><p className="text-sm font-medium text-green-400">{t("photoUploaded")}</p><button onClick={()=>onChange({hasPhoto:false})} className="ml-auto text-xs text-muted-foreground border border-border px-2.5 py-1 rounded-lg">{t("changePhoto")}</button></div>
          </div>
          :<button onClick={handleUpload} disabled={uploading}
            className="w-full border-2 border-dashed border-border bg-secondary/30 rounded-2xl p-10 flex flex-col items-center gap-4 hover:border-primary/40 transition-colors disabled:opacity-60">
            {uploading?<span className="w-10 h-10 border-2 border-primary/30 border-t-primary rounded-full animate-spin"/>
              :<><div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center"><Camera size={28} className="text-primary"/></div>
                <div className="text-center"><p className="text-sm font-semibold text-foreground">{t("uploadPhoto")}</p><p className="text-xs text-muted-foreground mt-1">{t("photoDesc")}</p></div></>}
          </button>}
        <div className="flex items-center gap-3 w-full"><div className="flex-1 h-px bg-border"/><span className="text-xs text-muted-foreground">yoki</span><div className="flex-1 h-px bg-border"/></div>
        <button onClick={()=>onChange({hasPhoto:false})} className="text-sm text-muted-foreground underline">{t("skipPhoto")}</button>
      </div>
      <div className="p-4 border-t border-border"><button onClick={onNext} className="w-full bg-primary text-white rounded-2xl py-3.5 text-sm font-semibold">{t("nextBtn")}</button></div>
    </div>
  );
}

function OrderReviewScreen({ draft, onBack, onPublish }: { draft:OrderDraft; onBack:()=>void; onPublish:()=>void }) {
  const { t } = useT();
  const price = draft.pickup&&draft.dropoff ? Math.round((draft.pickup.city.price+draft.dropoff.city.price)/2*0.8) : 150_000;
  const [busy,setBusy] = useState(false);
  function go(){ setBusy(true); setTimeout(()=>{setBusy(false);onPublish();},1200); }
  return (
    <div className="flex flex-col h-full">
      <BackHeader onBack={onBack} title={t("reviewTitle")}/>
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
        <div className="rounded-2xl border border-border bg-card p-4">
          <div className="flex items-center gap-3">
            <div className="flex flex-col items-center gap-1"><div className="w-3 h-3 rounded-full bg-primary border-2 border-primary/30"/><div className="w-px h-8 bg-border"/><div className="w-3 h-3 rounded-full bg-green-400 border-2 border-green-400/30"/></div>
            <div className="flex-1">
              <p className="text-sm font-bold text-foreground mb-1">{draft.pickup?.city.en}{draft.pickup?.district?` · ${draft.pickup.district}`:""}</p>
              <p className="text-xs text-muted-foreground mb-2">{draft.pickupAddress||draft.pickup?.address}</p>
              <p className="text-sm font-bold text-foreground mb-1">{draft.dropoff?.city.en}{draft.dropoff?.district?` · ${draft.dropoff.district}`:""}</p>
              <p className="text-xs text-muted-foreground">{draft.dropoffAddress||draft.dropoff?.address}</p>
            </div>
          </div>
        </div>
        <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4 flex items-center justify-between">
          <div><p className="text-xs text-muted-foreground">{t("suggestedPrice")}</p><p className="text-xl font-bold font-mono text-foreground">{fmt(price)}</p></div>
          <CreditCard size={24} className="text-primary opacity-60"/>
        </div>
        <div className="rounded-2xl border border-border bg-card p-4 flex flex-col gap-2">
          <p className="text-[10px] text-muted-foreground font-mono uppercase tracking-wide mb-1">{t("contactDetails")}</p>
          {[{label:t("sender"),value:draft.senderPhone},{label:t("receiver"),value:draft.receiverPhone}].map(({label,value})=>(
            <div key={label} className="flex items-center justify-between"><span className="text-xs text-muted-foreground">{label}</span><span className="text-sm font-mono text-foreground">{value}</span></div>
          ))}
          {draft.comment && <div className="pt-2 border-t border-border"><p className="text-xs text-muted-foreground">{t("comment")}</p><p className="text-sm text-foreground mt-0.5">{draft.comment}</p></div>}
        </div>
        {draft.hasPhoto && (
          <div className="rounded-2xl border border-border bg-card p-4 flex items-center gap-3">
            <Image size={16} className="text-primary"/><p className="text-sm font-medium text-foreground flex-1">{t("cargoPhotoTitle")}</p><CheckCircle2 size={16} className="text-green-400"/>
          </div>
        )}
        <div className="rounded-xl bg-secondary/50 border border-border p-3 flex items-center gap-2">
          <CreditCard size={14} className="text-muted-foreground"/><p className="text-xs text-muted-foreground">{t("cashNote")}</p>
        </div>
      </div>
      <div className="p-4 border-t border-border flex gap-3">
        <button onClick={onBack} className="flex-1 border border-border bg-secondary rounded-2xl py-3 text-sm font-semibold text-foreground">{t("editOrder")}</button>
        <button onClick={go} disabled={busy} className="flex-[2] flex items-center justify-center gap-2 bg-primary text-white rounded-2xl py-3 text-sm font-semibold disabled:opacity-70">
          {busy?<span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"/>:<><Send size={14}/>{t("publishOrder")}</>}
        </button>
      </div>
    </div>
  );
}

function OrderSuccessScreen({ onViewOrder, onHome }: { onViewOrder:()=>void; onHome:()=>void }) {
  const { t } = useT();
  return (
    <div className="flex flex-col h-full bg-background items-center justify-center px-8 text-center">
      <div className="w-24 h-24 rounded-full bg-green-500/15 flex items-center justify-center mb-6"><CheckCircle2 size={48} className="text-green-400"/></div>
      <h2 className="text-2xl font-bold text-foreground mb-2">{t("orderPublished")}</h2>
      <p className="text-sm text-muted-foreground leading-relaxed mb-10">{t("orderPublishedDesc")}</p>
      <div className="flex flex-col gap-3 w-full">
        <button onClick={onViewOrder} className="w-full bg-primary text-white rounded-2xl py-3.5 text-sm font-semibold">{t("viewMyOrder")}</button>
        <button onClick={onHome} className="w-full border border-border bg-secondary rounded-2xl py-3.5 text-sm font-semibold text-foreground">{t("backHome")}</button>
      </div>
    </div>
  );
}

function ClientOrdersScreen({ onOrderDetail, onCreateOrder }: { onOrderDetail:(id:string)=>void; onCreateOrder:()=>void }) {
  const { t } = useT();
  const [tab,setTab] = useState<"all"|"active"|"completed"|"cancelled">("all");
  const filtered = clientOrders.filter(o=>{
    if(tab==="all") return true;
    if(tab==="active") return ["published","bidding","accepted","in_transit"].includes(o.status);
    if(tab==="completed") return ["delivered","confirmed"].includes(o.status);
    return o.status==="cancelled";
  });
  const tabs = [{id:"all" as const,label:t("allOrders")},{id:"active" as const,label:t("activeOrders")},{id:"completed" as const,label:t("completedOrders")},{id:"cancelled" as const,label:t("cancelledOrders")}];
  return (
    <div className="flex flex-col h-full">
      <div className="p-4 pt-5 pb-2">
        <h1 className="text-xl font-semibold text-foreground mb-3">{t("myOrders")}</h1>
        <div className="flex gap-1 bg-secondary rounded-xl p-1">
          {tabs.map(tp=>(
            <button key={tp.id} onClick={()=>setTab(tp.id)}
              className={`flex-1 py-1.5 rounded-lg text-[11px] font-medium transition-colors whitespace-nowrap ${tab===tp.id?"bg-card text-foreground":"text-muted-foreground"}`}>
              {tp.label}
            </button>
          ))}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
        {filtered.length===0
          ?<div className="flex flex-col items-center justify-center py-16 text-center">
            <Package size={40} className="text-muted-foreground mb-3 opacity-40"/>
            <p className="text-sm font-medium text-muted-foreground">{t("noOrdersYet")}</p>
            <p className="text-xs text-muted-foreground mt-1 mb-5">{t("noOrdersDesc")}</p>
            <button onClick={onCreateOrder} className="bg-primary text-white rounded-xl px-5 py-2.5 text-sm font-medium">{t("createOrder")}</button>
          </div>
          :filtered.map(o=>(
            <button key={o.id} onClick={()=>onOrderDetail(o.id)} className="rounded-2xl border border-border bg-card p-4 text-left hover:border-primary/30 transition-colors">
              <div className="flex items-center justify-between mb-2"><span className="font-mono text-xs text-muted-foreground">{o.id}</span><StatusBadge status={o.status}/></div>
              <p className="text-sm font-bold text-foreground mb-1">{o.from} → {o.to}</p>
              <p className="text-xs text-muted-foreground mb-3">{o.pickup} → {o.dropoff}</p>
              <div className="flex items-center justify-between pt-3 border-t border-border">
                <p className="text-sm font-bold font-mono text-foreground">{fmt(o.price)}</p>
                <div className="flex items-center gap-2">
                  {o.bidsCount>0 && <span className="text-xs bg-amber-500/15 text-amber-400 border border-amber-500/20 rounded-lg px-2 py-0.5 font-mono">{o.bidsCount} {t("bidsStat")}</span>}
                  <span className="text-xs text-muted-foreground font-mono">{o.date}</span>
                </div>
              </div>
            </button>
          ))}
      </div>
    </div>
  );
}

function ClientOrderDetailScreen({ orderId, onBack, onViewBids, onConfirmDelivery, onRate, onDispute }: {
  orderId:string; onBack:()=>void; onViewBids:()=>void; onConfirmDelivery:()=>void; onRate:()=>void; onDispute:()=>void;
}) {
  const { t } = useT();
  const o = clientOrders.find(x=>x.id===orderId)||clientOrders[0];
  const sf = [{key:"published",label:t("statusPublished")},{key:"bidding",label:t("statusBidding")},{key:"accepted",label:t("statusAccepted")},{key:"in_transit",label:t("statusInTransit")},{key:"delivered",label:t("statusDelivered")}];
  const ci = sf.findIndex(s=>s.key===o.status);
  return (
    <div className="flex flex-col h-full">
      <BackHeader onBack={onBack} title={o.id} right={<StatusBadge status={o.status}/>}/>
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
        <div className="rounded-2xl border border-border bg-card p-4">
          <div className="flex items-center gap-3">
            <div className="flex flex-col items-center gap-1"><div className="w-3 h-3 rounded-full bg-primary border-2 border-primary/40"/><div className="w-px h-10 bg-border"/><div className="w-3 h-3 rounded-full bg-green-400 border-2 border-green-400/40"/></div>
            <div className="flex-1">
              <p className="text-sm font-bold text-foreground">{o.from}</p><p className="text-xs text-muted-foreground mb-3">{o.pickup}</p>
              <p className="text-sm font-bold text-foreground">{o.to}</p><p className="text-xs text-muted-foreground">{o.dropoff}</p>
            </div>
            <p className="text-base font-bold font-mono text-foreground">{fmt(o.price)}</p>
          </div>
        </div>
        {!["confirmed","cancelled"].includes(o.status) && (
          <div className="rounded-2xl border border-border bg-card p-4">
            <p className="text-xs text-muted-foreground mb-3 font-mono uppercase tracking-wide">{t("statusTimeline")}</p>
            <div className="flex items-center gap-0.5">{sf.map((s,i)=>(
              <div key={s.key} className="flex items-center flex-1">
                <div className={`w-3 h-3 rounded-full border-2 flex-shrink-0 ${i<=ci?"bg-primary border-primary":"bg-secondary border-border"}`}/>
                {i<sf.length-1 && <div className={`flex-1 h-0.5 ${i<ci?"bg-primary":"bg-border"}`}/>}
              </div>
            ))}</div>
            <div className="flex justify-between mt-2">{sf.map(s=><p key={s.key} className="text-[8px] text-muted-foreground font-mono leading-tight">{s.label}</p>)}</div>
          </div>
        )}
        {o.hasDriver && o.driver && (
          <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4">
            <p className="text-[10px] text-muted-foreground font-mono uppercase tracking-wide mb-3">{t("assignedDriver")}</p>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-primary/15 flex items-center justify-center"><Truck size={20} className="text-primary"/></div>
              <div className="flex-1">
                <p className="text-sm font-bold text-foreground">{o.driver}</p>
                <p className="text-xs text-muted-foreground">{o.driverCar}</p>
                <div className="flex items-center gap-1 mt-0.5"><Star size={10} className="text-amber-400 fill-amber-400"/><span className="text-xs font-mono">{o.driverRating}</span></div>
              </div>
            </div>
          </div>
        )}
        {["published","bidding"].includes(o.status) && (
          <div className="rounded-2xl border border-border bg-card p-4">
            <div className="flex items-center justify-between mb-2"><p className="text-sm font-semibold text-foreground">{t("bidsSection")}</p>{o.bidsCount>0&&<span className="text-xs bg-amber-500/15 text-amber-400 border border-amber-500/20 rounded-lg px-2 py-0.5 font-mono">{o.bidsCount}</span>}</div>
            {o.bidsCount===0
              ?<p className="text-xs text-muted-foreground">{t("waitingBids")}</p>
              :<button onClick={onViewBids} className="w-full flex items-center justify-center gap-2 bg-primary/10 text-primary border border-primary/20 rounded-xl py-2.5 text-sm font-medium"><Eye size={14}/>{t("viewBids")}</button>}
          </div>
        )}
        <div className="flex flex-col gap-2">
          {o.status==="delivered" && <button onClick={onConfirmDelivery} className="w-full bg-green-500 text-white rounded-2xl py-3 text-sm font-semibold flex items-center justify-center gap-2"><CheckCheck size={16}/>{t("confirmDelivery")}</button>}
          {o.status==="confirmed" && <button onClick={onRate} className="w-full bg-amber-500 text-white rounded-2xl py-3 text-sm font-semibold flex items-center justify-center gap-2"><Star size={16}/>{t("rateDriverTitle")}</button>}
          {["published","bidding"].includes(o.status) && <button className="w-full border border-border bg-secondary rounded-2xl py-3 text-sm font-semibold text-foreground flex items-center justify-center gap-2"><Edit3 size={14}/>{t("editOrderBtn")}</button>}
          {!["confirmed","cancelled"].includes(o.status) && <button onClick={onDispute} className="w-full border border-amber-500/30 text-amber-400 rounded-2xl py-3 text-sm font-medium flex items-center justify-center gap-2"><Flag size={14}/>{t("openDisputeBtn")}</button>}
          {["published","bidding","accepted"].includes(o.status) && <button className="w-full border border-red-500/30 text-red-400 rounded-2xl py-3 text-sm font-medium flex items-center justify-center gap-2"><Ban size={14}/>{t("cancelOrderBtn")}</button>}
        </div>
      </div>
    </div>
  );
}

function ClientBidsScreen({ onBack, onSelectDriver }: { onBack:()=>void; onSelectDriver:()=>void }) {
  const { t } = useT();
  const [sel,setSel] = useState<typeof driverBids[number]|null>(null);
  return (
    <div className="flex flex-col h-full relative">
      {sel && (
        <div className="absolute inset-0 z-50 flex flex-col justify-end bg-black/50 backdrop-blur-sm">
          <div className="bg-card rounded-t-[28px] border-t border-border p-5">
            <div className="flex justify-center mb-4"><div className="w-10 h-1 rounded-full bg-border"/></div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-primary/15 flex items-center justify-center"><Truck size={20} className="text-primary"/></div>
              <div className="flex-1"><p className="text-base font-bold text-foreground">{sel.name}</p><p className="text-xs text-muted-foreground">{sel.car}</p><div className="flex items-center gap-1 mt-0.5"><Star size={10} className="text-amber-400 fill-amber-400"/><span className="text-xs font-mono">{sel.rating}</span></div></div>
              <p className="text-lg font-bold font-mono text-foreground">{fmt(sel.price)}</p>
            </div>
            <h3 className="text-sm font-semibold text-foreground mb-1">{t("confirmDriverTitle")}</h3>
            <p className="text-xs text-muted-foreground mb-5">{t("confirmDriverDesc")}</p>
            <div className="flex gap-3">
              <button onClick={()=>setSel(null)} className="flex-1 border border-border bg-secondary rounded-2xl py-3 text-sm font-semibold text-foreground">{t("bidSheetCancel")}</button>
              <button onClick={()=>{setSel(null);onSelectDriver();}} className="flex-[2] bg-primary text-white rounded-2xl py-3 text-sm font-semibold">{t("confirmSelectDriver")}</button>
            </div>
          </div>
        </div>
      )}
      <BackHeader onBack={onBack} title={t("driverOffers")}/>
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
        {driverBids.map((b,i)=>(
          <div key={b.id} className={`rounded-2xl border bg-card p-4 ${i===0?"border-primary/30 bg-primary/5":"border-border"}`}>
            {i===0 && <div className="flex items-center gap-1 mb-2"><Star size={10} className="text-amber-400 fill-amber-400"/><span className="text-[10px] text-amber-400 font-medium">Top taklif</span></div>}
            <div className="flex items-center gap-3 mb-3">
              <div className="w-11 h-11 rounded-xl bg-secondary flex items-center justify-center"><Truck size={18} className="text-muted-foreground"/></div>
              <div className="flex-1">
                <p className="text-sm font-bold text-foreground">{b.name}</p><p className="text-xs text-muted-foreground">{b.car}</p>
                <div className="flex items-center gap-2 mt-0.5"><div className="flex items-center gap-0.5"><Star size={10} className="text-amber-400 fill-amber-400"/><span className="text-xs font-mono">{b.rating}</span></div><span className="text-xs text-muted-foreground">· {b.completedOrders} {t("completed")}</span></div>
              </div>
              <div className="text-right"><p className="text-lg font-bold font-mono text-foreground">{(b.price/1000).toFixed(0)}K</p><p className="text-[10px] text-muted-foreground">so'm</p></div>
            </div>
            <button onClick={()=>setSel(b)} className={`w-full py-2.5 rounded-xl text-sm font-semibold ${i===0?"bg-primary text-white":"border border-border bg-secondary text-foreground"}`}>{t("selectDriver")}</button>
          </div>
        ))}
      </div>
    </div>
  );
}

function ConfirmDeliveryScreen({ onBack, onConfirm }: { onBack:()=>void; onConfirm:()=>void }) {
  const { t } = useT();
  const o = clientOrders.find(x=>x.status==="delivered")||clientOrders[0];
  const [loading,setLoading] = useState(false);
  function go(){ setLoading(true); setTimeout(()=>{setLoading(false);onConfirm();},1000); }
  return (
    <div className="flex flex-col h-full">
      <BackHeader onBack={onBack} title={t("confirmDeliveryTitle")}/>
      <div className="flex-1 p-4 flex flex-col gap-4">
        <div className="rounded-2xl border border-green-500/20 bg-green-500/5 p-5 text-center">
          <div className="w-16 h-16 rounded-full bg-green-500/15 flex items-center justify-center mx-auto mb-3"><CheckCheck size={28} className="text-green-400"/></div>
          <p className="text-base font-bold text-foreground mb-1">{o.from} → {o.to}</p>
          <p className="text-sm text-muted-foreground">{t("statusDelivered")}</p>
        </div>
        <div className="rounded-2xl border border-border bg-card p-4">
          <div className="flex items-center gap-3 mb-3"><CreditCard size={16} className="text-primary"/><p className="text-sm font-semibold text-foreground">{t("paymentNote")}</p></div>
          <p className="text-sm text-muted-foreground">{t("cashNote")}</p>
          <div className="mt-3 pt-3 border-t border-border flex items-center justify-between"><span className="text-xs text-muted-foreground">Jami to'lov</span><span className="text-base font-bold font-mono text-foreground">{fmt(o.price)}</span></div>
        </div>
      </div>
      <div className="p-4 border-t border-border">
        <button onClick={go} disabled={loading} className="w-full bg-green-500 text-white rounded-2xl py-3.5 text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-70">
          {loading?<span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"/>:<><CheckCheck size={16}/>{t("confirmBtn")}</>}
        </button>
      </div>
    </div>
  );
}

function RatingScreen({ onBack, onSubmit }: { onBack:()=>void; onSubmit:()=>void }) {
  const { t } = useT();
  const labels = t("ratingLabels") as unknown as string[];
  const [stars,setStars] = useState(0); const [hover,setHover] = useState(0);
  const [comment,setComment] = useState(""); const [loading,setLoading] = useState(false); const [done,setDone] = useState(false);
  function go(){ if(!stars)return; setLoading(true); setTimeout(()=>{setLoading(false);setDone(true);setTimeout(onSubmit,1800);},1000); }
  if(done) return (
    <div className="flex flex-col h-full items-center justify-center px-8 text-center">
      <div className="w-20 h-20 rounded-full bg-amber-500/15 flex items-center justify-center mb-4"><ThumbsUp size={36} className="text-amber-400"/></div>
      <p className="text-xl font-bold text-foreground mb-2">{t("ratingSuccess")}</p>
      <p className="text-sm text-muted-foreground">Bahoingiz uchun rahmat!</p>
    </div>
  );
  return (
    <div className="flex flex-col h-full">
      <BackHeader onBack={onBack} title={t("rateDriverTitle")}/>
      <div className="flex-1 p-6 flex flex-col items-center gap-6">
        <div className="w-20 h-20 rounded-2xl bg-primary/15 flex items-center justify-center"><Truck size={36} className="text-primary"/></div>
        <div className="text-center"><p className="text-base font-bold text-foreground">Bobur Yusupov</p><p className="text-xs text-muted-foreground mt-0.5">Toshkent → Farg'ona</p></div>
        <div>
          <p className="text-sm font-medium text-muted-foreground text-center mb-4">{t("ratingDesc")}</p>
          <div className="flex gap-3 justify-center">
            {[1,2,3,4,5].map(s=>(
              <button key={s} onMouseEnter={()=>setHover(s)} onMouseLeave={()=>setHover(0)} onClick={()=>setStars(s)}>
                <Star size={36} className={`transition-colors ${s<=(hover||stars)?"text-amber-400 fill-amber-400":"text-border"}`}/>
              </button>
            ))}
          </div>
          {stars>0 && <p className="text-center text-sm font-medium text-foreground mt-3">{labels[stars]}</p>}
        </div>
        <div className="w-full">
          <label className="text-xs font-medium text-muted-foreground mb-1.5 block">{t("addComment")}</label>
          <textarea rows={3} className="w-full bg-input-background border border-border rounded-xl px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground outline-none resize-none focus:border-primary/60 transition-colors"
            placeholder="Izoh..." value={comment} onChange={e=>setComment(e.target.value)}/>
        </div>
      </div>
      <div className="p-4 border-t border-border">
        <button onClick={go} disabled={!stars||loading} className="w-full bg-amber-500 text-white rounded-2xl py-3.5 text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-40">
          {loading?<span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"/>:<><Star size={14}/>{t("submitRating")}</>}
        </button>
      </div>
    </div>
  );
}

function DisputeScreen({ onBack }: { onBack:()=>void }) {
  const { t } = useT();
  const reasons = (t("disputeReasons") as unknown as string).split("|");
  const [sel,setSel] = useState(""); const [comment,setComment] = useState(""); const [err,setErr] = useState(""); const [loading,setLoading] = useState(false); const [done,setDone] = useState(false);
  function go(){ if(!sel){setErr(t("disputeErrorEmpty"));return;} setLoading(true); setTimeout(()=>{setLoading(false);setDone(true);},1200); }
  if(done) return (
    <div className="flex flex-col h-full items-center justify-center px-8 text-center">
      <div className="w-20 h-20 rounded-full bg-amber-500/15 flex items-center justify-center mb-4"><Flag size={36} className="text-amber-400"/></div>
      <p className="text-xl font-bold text-foreground mb-2">{t("disputeSuccess")}</p>
      <p className="text-sm text-muted-foreground mb-8">{t("disputeSuccessDesc")}</p>
      <button onClick={onBack} className="bg-primary text-white rounded-2xl px-8 py-3 text-sm font-semibold">{t("back")}</button>
    </div>
  );
  return (
    <div className="flex flex-col h-full">
      <BackHeader onBack={onBack} title={t("disputeTitle")}/>
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-2 block">{t("disputeReason")}</label>
          <div className="flex flex-col gap-2">
            {reasons.map((r:string)=>(
              <button key={r} onClick={()=>{setSel(r);setErr("");}} className={`flex items-center gap-3 rounded-xl border px-4 py-3 text-left transition-all ${sel===r?"border-primary bg-primary/10":"border-border bg-card"}`}>
                <div className={`w-4 h-4 rounded-full border-2 flex-shrink-0 ${sel===r?"border-primary bg-primary":"border-border"}`}/>
                <span className="text-sm font-medium text-foreground">{r}</span>
              </button>
            ))}
          </div>
          {err && <p className="text-xs text-red-400 mt-2 flex items-center gap-1"><AlertCircle size={11}/>{err}</p>}
        </div>
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-1.5 block">{t("disputeComment")}</label>
          <textarea rows={4} className="w-full bg-input-background border border-border rounded-xl px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground outline-none resize-none focus:border-primary/60 transition-colors"
            placeholder={t("disputeReasonPlaceholder")} value={comment} onChange={e=>setComment(e.target.value)}/>
        </div>
      </div>
      <div className="p-4 border-t border-border">
        <button onClick={go} disabled={loading} className="w-full bg-primary text-white rounded-2xl py-3.5 text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-70">
          {loading?<span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"/>:<><Flag size={14}/>{t("submitDispute")}</>}
        </button>
      </div>
    </div>
  );
}

function ClientNotificationsScreen() {
  const { t } = useT();
  const [notifs,setNotifs] = useState(clientNotifs);
  const unread = notifs.filter(n=>!n.read).length;
  return (
    <div className="flex flex-col h-full">
      <div className="p-4 pt-5 pb-2 flex items-center justify-between">
        <div><h1 className="text-xl font-semibold text-foreground">{t("notifications")}</h1>{unread>0&&<p className="text-xs text-muted-foreground mt-0.5">{unread} ta o'qilmagan</p>}</div>
        {unread>0&&<button onClick={()=>setNotifs(n=>n.map(x=>({...x,read:true})))} className="text-xs text-primary font-medium">{t("markAllRead")}</button>}
      </div>
      <div className="flex-1 overflow-y-auto">
        {notifs.length===0
          ?<div className="flex flex-col items-center justify-center py-16 text-center px-8"><Bell size={40} className="text-muted-foreground mb-3 opacity-40"/><p className="text-sm font-medium text-muted-foreground">{t("noNotifications")}</p><p className="text-xs text-muted-foreground mt-1">{t("noNotifDesc")}</p></div>
          :notifs.map(n=>(
            <button key={n.id} onClick={()=>setNotifs(p=>p.map(x=>x.id===n.id?{...x,read:true}:x))}
              className={`w-full flex items-start gap-3 px-4 py-4 border-b border-border text-left transition-colors ${!n.read?"bg-primary/5":"hover:bg-secondary/40"}`}>
              <div className={`w-2.5 h-2.5 rounded-full mt-1.5 flex-shrink-0 ${!n.read?"bg-primary":"bg-transparent border border-border"}`}/>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-0.5">
                  <p className={`text-sm font-semibold ${!n.read?"text-foreground":"text-muted-foreground"}`}>{n.title}</p>
                  <span className="text-[10px] text-muted-foreground font-mono flex-shrink-0 ml-2">{n.date}</span>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">{n.message}</p>
                <p className="text-[10px] text-primary font-mono mt-1">{n.orderId}</p>
              </div>
            </button>
          ))}
      </div>
    </div>
  );
}

function ClientProfileScreen({ phone, onOrders, onNotifications, onSettings, onLogout }: {
  phone:string; onOrders:()=>void; onNotifications:()=>void; onSettings:()=>void; onLogout:()=>void;
}) {
  const { t } = useT();
  const [name,setName] = useState("Aziz Karimov");
  const [saving,setSaving] = useState(false); const [saved,setSaved] = useState(false);
  function save(){ setSaving(true); setTimeout(()=>{setSaving(false);setSaved(true);setTimeout(()=>setSaved(false),2000);},800); }
  return (
    <div className="flex flex-col gap-4 p-4 pb-6">
      <h1 className="text-xl font-semibold text-foreground pt-1">{t("clientProfile")}</h1>
      <div className="rounded-2xl border border-border bg-card p-5">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-primary/15 flex items-center justify-center"><User size={28} className="text-primary"/></div>
          <div><h2 className="text-lg font-bold text-foreground">{name}</h2><p className="text-sm text-muted-foreground font-mono">{phone}</p><StatusBadge status="active"/></div>
        </div>
        <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-border">
          {[{label:t("activeStat"),value:"2",color:"text-primary"},{label:t("bidsStat"),value:"3",color:"text-amber-400"},{label:t("completedStat"),value:"4",color:"text-green-400"}].map(({label,value,color})=>(
            <div key={label} className="text-center"><p className={`text-lg font-bold font-mono ${color}`}>{value}</p><p className="text-[10px] text-muted-foreground">{label}</p></div>
          ))}
        </div>
      </div>
      <div className="rounded-2xl border border-border bg-card p-4">
        <p className="text-xs font-semibold text-muted-foreground mb-3 font-mono uppercase tracking-wide">{t("personalData")}</p>
        <label className="text-xs text-muted-foreground mb-1.5 block">{t("fullNameLabel")}</label>
        <div className="flex gap-2">
          <input className="flex-1 bg-input-background border border-border rounded-xl px-4 py-3 text-sm text-foreground outline-none focus:border-primary/60 transition-colors" value={name} onChange={e=>setName(e.target.value)}/>
          <button onClick={save} disabled={saving} className={`px-4 rounded-xl text-sm font-medium transition-colors ${saved?"bg-green-500/15 text-green-400 border border-green-500/20":"bg-primary text-white"} disabled:opacity-60`}>
            {saving?<span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin inline-block"/>:saved?<CheckCircle2 size={16}/>:t("saveProfile")}
          </button>
        </div>
      </div>
      <div className="rounded-2xl border border-border bg-card overflow-hidden">
        {[{icon:Package,label:t("myOrdersLink"),action:onOrders},{icon:Bell,label:t("notificationsLink"),action:onNotifications},{icon:Settings,label:t("settings"),action:onSettings}].map(({icon:Icon,label,action},i)=>(
          <button key={label} onClick={action} className={`w-full flex items-center gap-3 px-4 py-3.5 hover:bg-secondary/50 transition-colors ${i>0?"border-t border-border":""}`}>
            <Icon size={16} className="text-muted-foreground"/><span className="text-sm text-foreground flex-1 text-left">{label}</span><ChevronRight size={14} className="text-muted-foreground"/>
          </button>
        ))}
        <button onClick={onLogout} className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-red-500/5 transition-colors border-t border-border">
          <LogOut size={16} className="text-red-400"/><span className="text-sm text-red-400 flex-1 text-left">{t("logOut")}</span>
        </button>
      </div>
    </div>
  );
}

// ─── Client Shell ─────────────────────────────────────────────────────────────

const CLIENT_NAV: { id:ClientTab; icon:typeof Home }[] = [
  { id:"home",          icon:Home    },
  { id:"orders",        icon:Package },
  { id:"notifications", icon:Bell    },
  { id:"profile",       icon:User    },
];

function ClientApp({ phone, themeMode, onThemeChange, lang, onLangChange, onLogout }: {
  phone:string; themeMode:ThemeMode; onThemeChange:(m:ThemeMode)=>void;
  lang:Lang; onLangChange:(l:Lang)=>void; onLogout:()=>void;
}) {
  const { t } = useT();
  const [tab,setTab]       = useState<ClientTab>("home");
  const [screen,setScreen] = useState<ClientScreen>("home");
  const [draft,setDraft]   = useState<OrderDraft>(EMPTY_DRAFT);
  const [selOrder,setSelOrder] = useState("ORD-5010");
  const [pendingCity,setPendingCity]     = useState<CityInfo|null>(null);
  const [pendingDist,setPendingDist]     = useState<string|undefined>();
  const [side,setSide]                   = useState<"from"|"to">("from");

  function goTo(s:ClientScreen){ setScreen(s); }
  function goTab(t:ClientTab){ setTab(t); setScreen(t); }

  function handleCity(city:CityInfo, forSide:"from"|"to"){
    setSide(forSide); setPendingCity(city);
    if(city.dist) goTo(forSide==="from"?"district-select-from":"district-select-to");
    else { setPendingDist(undefined); goTo(forSide==="from"?"map-picker-from":"map-picker-to"); }
  }
  function handleDistrict(d:string){ setPendingDist(d); goTo(side==="from"?"map-picker-from":"map-picker-to"); }
  function handleConfirmLoc(addr:string){
    if(!pendingCity) return;
    const pt:LocationPoint = { city:pendingCity, district:pendingDist, address:addr };
    if(side==="from") setDraft(d=>({...d,pickup:pt})); else setDraft(d=>({...d,dropoff:pt}));
    goTo("home");
  }

  const unread = clientNotifs.filter(n=>!n.read).length;
  const isMain = ["home","orders","notifications","profile"].includes(screen);

  return (
    <div className="flex flex-col h-full relative">
      <div className="flex-1 overflow-y-auto scrollbar-hide">
        {screen==="home" && <ClientHomeScreen onSelectFrom={()=>{setSide("from");goTo("city-select-from");}} onSelectTo={()=>{setSide("to");goTo("city-select-to");}} draft={draft} onViewRoute={()=>goTo("contacts")}/>}
        {screen==="city-select-from" && <CitySelectScreen title={t("chooseCity")} onBack={()=>goTo("home")} onSelect={c=>handleCity(c,"from")}/>}
        {screen==="city-select-to"   && <CitySelectScreen title={t("chooseCity")} onBack={()=>goTo("home")} onSelect={c=>handleCity(c,"to")}/>}
        {screen==="district-select-from" && pendingCity && <DistrictSelectScreen city={pendingCity} onBack={()=>goTo("city-select-from")} onSelect={handleDistrict}/>}
        {screen==="district-select-to"   && pendingCity && <DistrictSelectScreen city={pendingCity} onBack={()=>goTo("city-select-to")}   onSelect={handleDistrict}/>}
        {screen==="map-picker-from" && pendingCity && <MapPickerScreen city={pendingCity} district={pendingDist} onBack={()=>goTo(pendingCity.dist?"district-select-from":"city-select-from")} onConfirm={handleConfirmLoc}/>}
        {screen==="map-picker-to"   && pendingCity && <MapPickerScreen city={pendingCity} district={pendingDist} onBack={()=>goTo(pendingCity.dist?"district-select-to":"city-select-to")}   onConfirm={handleConfirmLoc}/>}
        {screen==="contacts"     && <ContactsScreen     draft={draft} onChange={p=>setDraft(d=>({...d,...p}))} onBack={()=>goTo("home")}     onNext={()=>goTo("cargo-photo")}/>}
        {screen==="cargo-photo"  && <CargoPhotoScreen   draft={draft} onChange={p=>setDraft(d=>({...d,...p}))} onBack={()=>goTo("contacts")} onNext={()=>goTo("order-review")}/>}
        {screen==="order-review" && <OrderReviewScreen  draft={draft} onBack={()=>goTo("cargo-photo")} onPublish={()=>goTo("order-success")}/>}
        {screen==="order-success"&& <OrderSuccessScreen onViewOrder={()=>{setDraft(EMPTY_DRAFT);goTab("orders");}} onHome={()=>{setDraft(EMPTY_DRAFT);goTab("home");}}/>}
        {screen==="orders"       && <ClientOrdersScreen onOrderDetail={id=>{setSelOrder(id);goTo("c-order-detail");}} onCreateOrder={()=>goTab("home")}/>}
        {screen==="c-order-detail"&&<ClientOrderDetailScreen orderId={selOrder} onBack={()=>goTo("orders")} onViewBids={()=>goTo("bids")} onConfirmDelivery={()=>goTo("confirm-delivery")} onRate={()=>goTo("rating")} onDispute={()=>goTo("dispute")}/>}
        {screen==="bids"          &&<ClientBidsScreen onBack={()=>goTo("c-order-detail")} onSelectDriver={()=>goTab("orders")}/>}
        {screen==="confirm-delivery"&&<ConfirmDeliveryScreen onBack={()=>goTo("c-order-detail")} onConfirm={()=>goTo("rating")}/>}
        {screen==="rating"        &&<RatingScreen onBack={()=>goTo("orders")} onSubmit={()=>goTab("orders")}/>}
        {screen==="dispute"       &&<DisputeScreen onBack={()=>goTo("c-order-detail")}/>}
        {screen==="notifications" &&<ClientNotificationsScreen/>}
        {screen==="profile"       &&<ClientProfileScreen phone={phone} onOrders={()=>goTab("orders")} onNotifications={()=>goTab("notifications")} onSettings={()=>goTo("c-settings")} onLogout={onLogout}/>}
        {screen==="c-settings"    &&<SettingsPanel onBack={()=>goTo("profile")} themeMode={themeMode} onThemeChange={onThemeChange} lang={lang} onLangChange={onLangChange} onLogout={onLogout} notifKeys={{a:"bidAlerts",ad:"bidAlertsDesc",b:"orderUpdates",bd:"orderUpdatesDesc"}}/>}
      </div>
      {isMain && (
        <div className="flex-shrink-0 bg-card border-t border-border px-2 pt-2 pb-6">
          <div className="flex">
            {CLIENT_NAV.map(({id,icon:Icon})=>{
              const active=tab===id&&screen===id;
              const label=id==="home"?t("home"):id==="orders"?t("orders"):id==="notifications"?t("notifications"):t("profile");
              return (
                <button key={id} onClick={()=>goTab(id)} className="flex-1 flex flex-col items-center gap-1 py-2 rounded-xl transition-colors">
                  <div className={`p-1.5 rounded-xl relative ${active?"bg-primary/15":""}`}>
                    <Icon size={20} className={active?"text-primary":"text-muted-foreground"} strokeWidth={active?2.5:1.5}/>
                    {id==="notifications"&&unread>0&&<div className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-red-500 flex items-center justify-center"><span className="text-[8px] text-white font-bold">{unread}</span></div>}
                  </div>
                  <span className={`text-[10px] font-medium ${active?"text-primary":"text-muted-foreground"}`}>{label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// DRIVER APP
// ═══════════════════════════════════════════════════════════════════════════════

type BidOrder = typeof driverOrders[number];
type BidState = "form"|"loading"|"success";

function BidSheet({ order, onClose }: { order:BidOrder; onClose:()=>void }) {
  const { t } = useT();
  const [price,setPrice] = useState(""); const [note,setNote] = useState(""); const [err,setErr] = useState(""); const [st,setSt] = useState<BidState>("form");
  const num = parseInt(price.replace(/\D/g,""),10)||0;
  const net = num>0?Math.round(num*0.9):0;
  function bd(e:React.MouseEvent<HTMLDivElement>){ if(e.target===e.currentTarget)onClose(); }
  function hp(raw:string){ const d=raw.replace(/\D/g,""); setPrice(d?parseInt(d,10).toLocaleString("ru-RU"):""); if(err)setErr(""); }
  function go(){ if(!price||num===0){setErr(num===0&&price?t("bidSheetErrorZero"):t("bidSheetErrorEmpty"));return;} setSt("loading"); setTimeout(()=>setSt("success"),1400); }
  useEffect(()=>{ if(st==="success"){const id=setTimeout(onClose,2200);return()=>clearTimeout(id);} },[st,onClose]);
  return (
    <div className="absolute inset-0 z-50 flex flex-col justify-end" style={{background:"rgba(0,0,0,0.55)",backdropFilter:"blur(2px)"}} onClick={bd}>
      <div className="bg-card rounded-t-[28px] border-t border-border overflow-hidden">
        <div className="flex justify-center pt-3 pb-1"><div className="w-10 h-1 rounded-full bg-border"/></div>
        {st==="success"
          ?<div className="flex flex-col items-center py-10 px-6 gap-3">
            <div className="w-16 h-16 rounded-full bg-green-500/15 flex items-center justify-center mb-2"><CheckCircle2 size={32} className="text-green-400"/></div>
            <p className="text-lg font-bold text-foreground">{t("bidSheetSuccess")}</p>
            <p className="text-sm text-muted-foreground text-center">{t("bidSheetSuccessDesc")}</p>
            <p className="text-xs font-mono text-muted-foreground">{order.from} → {order.to} · {num.toLocaleString("ru-RU")} so'm</p>
          </div>
          :<div className="px-5 pt-2 pb-7 flex flex-col gap-0">
            <div className="flex items-center justify-between mb-5"><h2 className="text-lg font-bold text-foreground">{t("bidSheetTitle")}</h2><button onClick={onClose} className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center"><X size={14} className="text-foreground"/></button></div>
            <div className="rounded-2xl border border-border bg-background p-4 mb-4">
              <p className="text-[10px] text-muted-foreground font-mono uppercase tracking-wide mb-2">{t("bidSheetRoute")}</p>
              <div className="flex items-center gap-3">
                <div className="flex flex-col items-center gap-1"><div className="w-2.5 h-2.5 rounded-full bg-primary border-2 border-primary/30"/><div className="w-px h-5 bg-border"/><div className="w-2.5 h-2.5 rounded-full bg-green-400 border-2 border-green-400/30"/></div>
                <div className="flex-1"><p className="text-sm font-semibold text-foreground">{order.from}</p><p className="text-[11px] text-muted-foreground mb-1">{order.pickup}</p><p className="text-sm font-semibold text-foreground">{order.to}</p><p className="text-[11px] text-muted-foreground">{order.dropoff}</p></div>
                <div className="text-right"><p className="text-[10px] text-muted-foreground mb-0.5">{t("bidSheetSuggestedPrice")}</p><p className="text-base font-bold font-mono text-foreground">{(order.price/1000).toFixed(0)}K</p><p className="text-[10px] text-muted-foreground">so'm</p></div>
              </div>
            </div>
            <div className="mb-3">
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">{t("bidSheetYourPrice")} *</label>
              <div className={`flex items-center gap-3 bg-input-background border rounded-xl px-4 py-3 ${err?"border-red-500/50":"border-border focus-within:border-primary/60"}`}>
                <span className="text-sm text-muted-foreground font-mono flex-shrink-0">so'm</span>
                <input type="text" inputMode="numeric" autoFocus className="flex-1 bg-transparent text-sm font-bold font-mono text-foreground placeholder:text-muted-foreground outline-none" placeholder={t("bidSheetPricePlaceholder")} value={price} onChange={e=>hp(e.target.value)}/>
              </div>
              {err && <p className="text-xs text-red-400 mt-1.5 flex items-center gap-1"><AlertCircle size={11}/>{err}</p>}
            </div>
            {num>0 && <div className="rounded-xl border border-green-500/20 bg-green-500/5 px-4 py-2.5 mb-3 flex items-center justify-between"><div><p className="text-xs font-medium text-green-400">{t("bidSheetNetEst")}</p><p className="text-[10px] text-muted-foreground">{t("bidSheetCommissionNote")}</p></div><p className="text-base font-bold font-mono text-green-400">{net.toLocaleString("ru-RU")}</p></div>}
            <div className="mb-5">
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">{t("bidSheetNote")}</label>
              <textarea rows={2} className="w-full bg-input-background border border-border rounded-xl px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground outline-none resize-none focus:border-primary/60 transition-colors" placeholder={t("bidSheetNotePlaceholder")} value={note} onChange={e=>setNote(e.target.value)}/>
            </div>
            <div className="flex gap-3">
              <button onClick={onClose} className="flex-1 border border-border bg-secondary rounded-2xl py-3 text-sm font-semibold text-foreground">{t("bidSheetCancel")}</button>
              <button onClick={go} disabled={st==="loading"} className="flex-[2] flex items-center justify-center gap-2 bg-primary text-white rounded-2xl py-3 text-sm font-semibold disabled:opacity-70">
                {st==="loading"?<span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"/>:<><Send size={14}/>{t("bidSheetSubmit")}</>}
              </button>
            </div>
          </div>}
      </div>
    </div>
  );
}

function DriverApp({ themeMode, onThemeChange, lang, onLangChange, onLogout }: {
  themeMode:ThemeMode; onThemeChange:(m:ThemeMode)=>void;
  lang:Lang; onLangChange:(l:Lang)=>void; onLogout:()=>void;
}) {
  const { t } = useT();
  const [tab,setTab]       = useState<DriverTab>("home");
  const [screen,setScreen] = useState<DriverScreen>("home");
  const [avail,setAvail]   = useState(driverData.available);
  const [bidOrder,setBidOrder] = useState<BidOrder|null>(null);
  const [routeList,setRouteList] = useState(routesData);
  const [period,setPeriod] = useState<"daily"|"monthly">("daily");
  const [orderTab,setOrderTab] = useState<"feed"|"history">("feed");

  function goTo(s:DriverScreen){ setScreen(s); }
  function goBack(){ setScreen(tab); }
  function switchTab(t:DriverTab){ setTab(t); setScreen(t); }

  const isApproved = driverData.status==="approved";
  const isDetail = !["home","routes","orders","profile"].includes(screen);
  const data = period==="daily"?dailyData:monthlyData;
  const xKey = period==="daily"?"day":"month";

  return (
    <>
      {bidOrder && <BidSheet order={bidOrder} onClose={()=>setBidOrder(null)}/>}
      <div className="flex-1 overflow-y-auto scrollbar-hide">

        {/* HOME */}
        {screen==="home" && (
          <div className="flex flex-col gap-4 p-4 pb-6">
            <div className="flex items-center justify-between pt-1">
              <div><p className="text-xs text-muted-foreground font-mono">{t("goodMorning")}</p><h1 className="text-xl font-semibold text-foreground">{driverData.name.split(" ")[0]}</h1></div>
              <button onClick={()=>goTo("income")} className="flex items-center gap-2 bg-card border border-border rounded-xl px-3 py-2 hover:border-primary/40 transition-colors">
                <TrendingUp size={14} className="text-primary"/>
                <div className="text-right"><p className="text-[9px] text-muted-foreground font-mono uppercase tracking-wide">{t("netIncome")}</p><p className="text-sm font-semibold text-foreground font-mono">{(driverData.netIncome/1_000_000).toFixed(2)}M</p></div>
                <ChevronRight size={12} className="text-muted-foreground"/>
              </button>
            </div>
            <div className="relative rounded-2xl overflow-hidden h-44 bg-[#1a2234]">
              <div className="absolute inset-0 bg-cover bg-center opacity-40" style={{backgroundImage:"url(https://images.unsplash.com/photo-1619546952812-520e98064a52?w=800&h=400&fit=crop&auto=format)"}} aria-hidden="true"/>
              <div className="absolute inset-0 bg-gradient-to-t from-[#0d1117]/90 via-transparent to-transparent"/>
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <div className="flex items-center gap-2 text-sm font-medium text-white"><div className="w-2 h-2 rounded-full bg-primary"/><span>Toshkent</span><div className="flex-1 border-t border-dashed border-white/20"/><span>Samarqand</span><div className="w-2 h-2 rounded-full bg-green-400"/></div>
                <p className="text-xs text-white/60 mt-1">{t("activeRoute")} · 365 km</p>
              </div>
              <div className="absolute top-3 right-3 bg-primary/90 text-white text-xs font-mono px-2 py-1 rounded-lg">{t("liveLabel")}</div>
            </div>
            <div className={`rounded-2xl border p-4 ${isApproved?"border-green-500/20 bg-green-500/5":"border-amber-500/20 bg-amber-500/5"}`}>
              <div className="flex items-start gap-3">
                <div className={`p-2 rounded-xl ${isApproved?"bg-green-500/15":"bg-amber-500/15"}`}><Shield size={18} className={isApproved?"text-green-400":"text-amber-400"}/></div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5"><p className="text-sm font-semibold text-foreground">{isApproved?t("verifiedDriver"):t("pendingVerification")}</p><StatusBadge status={isApproved?"approved":"pending"}/></div>
                  <p className="text-xs text-muted-foreground leading-relaxed">{isApproved?t("approvedDesc"):t("notApprovedDesc")}</p>
                </div>
              </div>
            </div>
            <div className="rounded-2xl border border-border bg-card p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-xl ${avail?"bg-primary/15":"bg-secondary"}`}><Navigation size={18} className={avail?"text-primary":"text-muted-foreground"}/></div>
                  <div><p className="text-sm font-semibold text-foreground">{t("availability")}</p><p className="text-xs text-muted-foreground">{avail?t("visibleToClients"):t("currentlyOffline")}</p></div>
                </div>
                <button onClick={isApproved?()=>setAvail(v=>!v):undefined} className={!isApproved?"opacity-40 cursor-not-allowed":""}>
                  {avail?<ToggleRight size={36} className="text-primary"/>:<ToggleLeft size={36} className="text-muted-foreground"/>}
                </button>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {[{label:t("rating"),value:driverData.rating.toString(),icon:Star,color:"text-amber-400"},{label:t("completed"),value:driverData.completedOrders.toString(),icon:CheckCircle2,color:"text-green-400"},{label:t("total"),value:driverData.totalOrders.toString(),icon:Package,color:"text-primary"}].map(({label,value,icon:Icon,color})=>(
                <div key={label} className="rounded-2xl border border-border bg-card p-3 text-center"><Icon size={16} className="text-primary mx-auto mb-1"/><p className="text-lg font-bold font-mono text-foreground">{value}</p><p className="text-[10px] text-muted-foreground">{label}</p></div>
              ))}
            </div>
          </div>
        )}

        {/* ROUTES */}
        {screen==="routes" && (
          <div className="flex flex-col gap-4 p-4 pb-6">
            <div className="flex items-center justify-between pt-1"><h1 className="text-xl font-semibold text-foreground">{t("myRoutes")}</h1><button onClick={()=>goTo("add-route")} className="flex items-center gap-1.5 bg-primary text-white rounded-xl px-3 py-2 text-sm font-medium"><Plus size={14}/>{t("addRoute")}</button></div>
            {routeList.length===0
              ?<div className="flex flex-col items-center justify-center py-16 text-center"><Route size={40} className="text-muted-foreground mb-3 opacity-50"/><p className="text-sm font-medium text-muted-foreground">{t("noRoutesYet")}</p><p className="text-xs text-muted-foreground mt-1">{t("noRoutesDesc")}</p><button onClick={()=>goTo("add-route")} className="mt-4 bg-primary text-white rounded-xl px-5 py-2.5 text-sm font-medium">{t("addFirstRoute")}</button></div>
              :routeList.map(r=>(
                <div key={r.id} className="rounded-2xl border border-border bg-card p-4">
                  <div className="flex items-start justify-between mb-3"><StatusBadge status={r.status}/><div className="flex gap-1.5"><button className="p-1.5 rounded-lg bg-secondary"><Plus size={13} className="text-muted-foreground"/></button><button onClick={()=>setRouteList(p=>p.filter(x=>x.id!==r.id))} className="p-1.5 rounded-lg bg-red-500/10"><Trash2 size={13} className="text-red-400"/></button></div></div>
                  <div className="flex items-center gap-3">
                    <div className="flex flex-col items-center gap-1"><div className="w-2.5 h-2.5 rounded-full bg-primary border-2 border-primary/40"/><div className="w-px h-8 bg-border"/><div className="w-2.5 h-2.5 rounded-full bg-green-400 border-2 border-green-400/40"/></div>
                    <div className="flex-1"><p className="text-sm font-semibold text-foreground">{r.from}</p>{r.fromDistrict&&<p className="text-xs text-muted-foreground">{r.fromDistrict}</p>}<div className="mt-2"><p className="text-sm font-semibold text-foreground">{r.to}</p>{r.toDistrict&&<p className="text-xs text-muted-foreground">{r.toDistrict}</p>}</div></div>
                  </div>
                </div>
              ))}
          </div>
        )}

        {/* ADD ROUTE */}
        {screen==="add-route" && (
          <div className="flex flex-col h-full">
            <BackHeader onBack={goBack} title={t("addRoute")}/>
            <div className="flex flex-col gap-4 p-4 flex-1">
              {[{label:t("fromCity"),key:"from",isSelect:true},{label:t("fromDistrict"),key:"fromDistrict",isSelect:false},{label:t("toCity"),key:"to",isSelect:true},{label:t("toDistrict"),key:"toDistrict",isSelect:false}].map(({label,key,isSelect})=>(
                <div key={key}>
                  <label className="text-xs text-muted-foreground mb-1.5 block">{label}</label>
                  {isSelect
                    ?<select className="w-full bg-input-background border border-border rounded-xl px-4 py-3 text-sm text-foreground appearance-none"><option value="">{t("selectCity")}</option>{CITIES.map(c=><option key={c.id}>{c.uz}</option>)}</select>
                    :<input className="w-full bg-input-background border border-border rounded-xl px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground"/>}
                </div>
              ))}
              <div className="mt-auto pt-4"><button onClick={goBack} className="w-full bg-primary text-white rounded-2xl py-3.5 text-sm font-semibold">{t("saveRoute")}</button></div>
            </div>
          </div>
        )}

        {/* ORDERS */}
        {screen==="orders" && (
          <div className="flex flex-col h-full">
            <div className="p-4 pt-5 pb-0"><h1 className="text-xl font-semibold text-foreground mb-4">{t("orders")}</h1>
              <div className="flex gap-1 bg-secondary rounded-xl p-1">{(["feed","history"] as const).map(tp=><button key={tp} onClick={()=>setOrderTab(tp)} className={`flex-1 py-2 rounded-lg text-xs font-medium transition-colors ${orderTab===tp?"bg-card text-foreground":"text-muted-foreground"}`}>{tp==="feed"?t("matchingOrders"):t("myHistory")}</button>)}</div>
            </div>
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
              {orderTab==="feed" ? driverOrders.map(o=>(
                <div key={o.id} className="rounded-2xl border border-border bg-card p-4 cursor-pointer hover:border-primary/30 transition-colors" onClick={()=>goTo("order-detail")}>
                  <div className="flex items-center justify-between mb-3"><span className="font-mono text-xs text-muted-foreground">{o.id}</span><StatusBadge status={o.status}/></div>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="flex flex-col items-center gap-1"><div className="w-2 h-2 rounded-full bg-primary"/><div className="w-px h-6 bg-border"/><div className="w-2 h-2 rounded-full bg-green-400"/></div>
                    <div className="flex-1"><p className="text-sm font-semibold text-foreground">{o.from}</p><p className="text-[11px] text-muted-foreground mb-1">{o.pickup}</p><p className="text-sm font-semibold text-foreground">{o.to}</p><p className="text-[11px] text-muted-foreground">{o.dropoff}</p></div>
                    <div className="text-right"><p className="text-base font-bold font-mono text-foreground">{(o.price/1000).toFixed(0)}K</p><p className="text-[10px] text-muted-foreground">so'm</p></div>
                  </div>
                  <div className="flex items-center justify-between pt-3 border-t border-border">
                    <span className="text-[11px] text-muted-foreground font-mono">{o.date}</span>
                    {o.hasBid
                      ?<div className="flex items-center gap-1.5 text-amber-400 text-xs"><CheckCircle2 size={12}/><span className="font-mono">{t("bid")}: {((o.bidPrice??0)/1000).toFixed(0)}K</span></div>
                      :<button className="flex items-center gap-1 bg-primary/15 text-primary border border-primary/20 rounded-lg px-3 py-1.5 text-xs font-medium" onClick={e=>{e.stopPropagation();setBidOrder(o);}}><Send size={11}/>{t("sendBid")}</button>}
                  </div>
                </div>
              )) : (
                <div className="flex flex-col gap-3">
                  <div className="rounded-2xl border border-indigo-500/30 bg-indigo-500/5 p-4 cursor-pointer" onClick={()=>goTo("order-detail")}>
                    <div className="flex items-center justify-between mb-2"><span className="font-mono text-xs text-muted-foreground">{activeDriverOrder.id}</span><StatusBadge status={activeDriverOrder.status}/></div>
                    <p className="text-sm font-semibold text-foreground mb-1">{activeDriverOrder.from} → {activeDriverOrder.to}</p>
                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-indigo-500/20">
                      <div className="flex gap-4 text-xs font-mono"><span className="text-muted-foreground">{t("gross")}: <span className="text-foreground">{(activeDriverOrder.gross/1000).toFixed(0)}K</span></span><span className="text-muted-foreground">{t("net")}: <span className="text-green-400">{(activeDriverOrder.net/1000).toFixed(0)}K</span></span></div>
                      <ChevronRight size={14} className="text-muted-foreground"/>
                    </div>
                  </div>
                  {recentEarnings.map(e=><div key={e.id} className="rounded-2xl border border-border bg-card p-4"><div className="flex items-center justify-between"><div><p className="text-sm font-semibold text-foreground">{e.from} → {e.to}</p><p className="text-[11px] text-muted-foreground font-mono">{e.id} · {e.date}</p></div><div className="text-right"><p className="text-sm font-bold text-green-400 font-mono">+{(e.net/1000).toFixed(0)}K</p><p className="text-[10px] text-muted-foreground">{t("net")}</p></div></div></div>)}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ORDER DETAIL */}
        {screen==="order-detail" && (
          <div className="flex flex-col h-full">
            <BackHeader onBack={goBack} title={activeDriverOrder.id} right={<StatusBadge status={activeDriverOrder.status}/>}/>
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
              <div className="rounded-2xl border border-border bg-card p-4">
                <div className="flex items-center gap-3"><div className="flex flex-col items-center gap-1"><div className="w-3 h-3 rounded-full bg-primary border-2 border-primary/40"/><div className="w-px h-10 bg-border"/><div className="w-3 h-3 rounded-full bg-green-400 border-2 border-green-400/40"/></div><div className="flex-1"><div className="mb-3"><p className="text-sm font-bold text-foreground">{activeDriverOrder.from}</p><p className="text-xs text-muted-foreground">{activeDriverOrder.pickup}</p></div><div><p className="text-sm font-bold text-foreground">{activeDriverOrder.to}</p><p className="text-xs text-muted-foreground">{activeDriverOrder.dropoff}</p></div></div></div>
              </div>
              <div className="rounded-2xl border border-border bg-card p-4">
                <p className="text-xs text-muted-foreground mb-3 font-mono uppercase tracking-wide">{t("statusProgress")}</p>
                {(()=>{ const sf=[{key:"accepted",label:t("accepted")},{key:"picked_up",label:t("pickedUp")},{key:"in_transit",label:t("inTransit")},{key:"delivered",label:t("delivered")}]; const ci=sf.findIndex(s=>s.key===activeDriverOrder.status);
                  return (<><div className="flex items-center gap-1">{sf.map((s,i)=><div key={s.key} className="flex items-center flex-1"><div className={`w-3 h-3 rounded-full border-2 flex-shrink-0 ${i<=ci?"bg-primary border-primary":"bg-secondary border-border"}`}/>{i<sf.length-1&&<div className={`flex-1 h-0.5 ${i<ci?"bg-primary":"bg-border"}`}/>}</div>)}</div><div className="flex justify-between mt-2">{sf.map(s=><p key={s.key} className="text-[8px] text-muted-foreground font-mono">{s.label}</p>)}</div></>);
                })()}
              </div>
              <div className="rounded-2xl border border-border bg-card p-4 flex flex-col gap-3">
                <p className="text-xs text-muted-foreground font-mono uppercase tracking-wide">{t("contactDetails")}</p>
                {[{icon:Phone,label:t("sender"),value:activeDriverOrder.sender},{icon:Phone,label:t("receiver"),value:activeDriverOrder.receiver},{icon:FileText,label:t("comment"),value:activeDriverOrder.comment}].map(({icon:Icon,label,value})=>(
                  <div key={label} className="flex items-start gap-3"><Icon size={14} className="text-muted-foreground mt-0.5"/><div><p className="text-[10px] text-muted-foreground">{label}</p><p className="text-sm text-foreground font-mono">{value}</p></div></div>
                ))}
              </div>
              <div className="rounded-2xl border border-green-500/20 bg-green-500/5 p-4">
                <p className="text-xs text-muted-foreground font-mono uppercase tracking-wide mb-3">{t("incomeReport")}</p>
                <div className="flex flex-col gap-2">
                  {[{label:t("grossAmount"),value:fmt(activeDriverOrder.gross),cls:"text-foreground"},{label:t("systemFee"),value:`−${fmt(activeDriverOrder.commission)}`,cls:"text-red-400"},{label:t("netIncome"),value:fmt(activeDriverOrder.net),cls:"text-green-400 text-base font-bold"}].map(({label,value,cls})=>(
                    <div key={label} className="flex items-center justify-between"><span className="text-xs text-muted-foreground">{label}</span><span className={`text-sm font-mono ${cls}`}>{value}</span></div>
                  ))}
                </div>
              </div>
              <button className="flex items-center justify-center gap-2 border border-border bg-secondary rounded-2xl py-3 text-sm font-medium text-foreground"><MapPin size={14} className="text-primary"/>{t("viewOnMap")}</button>
              <button className="w-full bg-primary text-white rounded-2xl py-3.5 text-sm font-semibold">{t("markDelivered")}</button>
            </div>
          </div>
        )}

        {/* INCOME */}
        {screen==="income" && (
          <div className="flex flex-col h-full">
            <BackHeader onBack={goBack} title={t("income")}/>
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
              <div className="rounded-2xl border border-primary/20 bg-primary/5 p-5">
                <p className="text-xs text-muted-foreground font-mono uppercase tracking-wide mb-1">{t("netIncome")}</p>
                <p className="text-3xl font-bold font-mono text-foreground">{(driverData.netIncome/1_000_000).toFixed(2)}M so'm</p>
                <p className="text-xs text-muted-foreground mt-1">{t("afterCommission")}</p>
                <div className="flex gap-4 mt-4 pt-4 border-t border-primary/10"><div><p className="text-[10px] text-muted-foreground">{t("gross")}</p><p className="text-sm font-mono text-foreground">5.36M so'm</p></div><div><p className="text-[10px] text-muted-foreground">{t("commission")}</p><p className="text-sm font-mono text-red-400">−536K so'm</p></div></div>
              </div>
              <div className="rounded-2xl border border-border bg-card p-4">
                <div className="flex items-center justify-between mb-4"><p className="text-sm font-semibold text-foreground">{t("earningsChart")}</p><div className="flex gap-1 bg-secondary rounded-lg p-0.5">{(["daily","monthly"] as const).map(p=><button key={p} onClick={()=>setPeriod(p)} className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${period===p?"bg-card text-foreground":"text-muted-foreground"}`}>{p==="daily"?t("sevenDays"):t("sixMonths")}</button>)}</div></div>
                <ResponsiveContainer width="100%" height={140}>
                  <BarChart data={data} barSize={period==="daily"?24:32}>
                    <XAxis dataKey={xKey} tick={{fontSize:10,fill:"#8b949e",fontFamily:"JetBrains Mono"}} axisLine={false} tickLine={false}/>
                    <YAxis hide/>
                    <Tooltip contentStyle={{background:"#161b22",border:"1px solid rgba(255,255,255,0.08)",borderRadius:10,fontSize:11}} labelStyle={{color:"#8b949e"}} itemStyle={{color:"#f0f2f5",fontFamily:"JetBrains Mono"}} formatter={(v:number)=>[`${(v/1000).toFixed(0)}K so'm`,t("net")]}/>
                    <Bar dataKey="amount" fill="#1B4FD8" radius={[6,6,0,0]}/>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div><p className="text-xs text-muted-foreground font-mono uppercase tracking-wide mb-3">{t("recentEarnings")}</p><div className="flex flex-col gap-2">{recentEarnings.map(e=><div key={e.id} className="flex items-center justify-between rounded-xl border border-border bg-card px-4 py-3"><div><p className="text-sm font-semibold text-foreground">{e.from} → {e.to}</p><p className="text-[11px] text-muted-foreground font-mono">{e.id} · {e.date}</p></div><p className="text-sm font-bold text-green-400 font-mono">+{(e.net/1000).toFixed(0)}K</p></div>)}</div></div>
            </div>
          </div>
        )}

        {/* DOCUMENTS */}
        {screen==="documents" && (
          <div className="flex flex-col h-full">
            <BackHeader onBack={goBack} title={t("documents")}/>
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
              <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-3 text-xs text-amber-400 flex items-center gap-2"><AlertCircle size={14}/>{t("uploadAllDocs")}</div>
              {driverDocs.map(doc=>(
                <div key={doc.type} className="rounded-2xl border border-border bg-card p-4">
                  <div className="flex items-center justify-between mb-3"><div className="flex items-center gap-2">{doc.status==="approved"?<CheckCircle2 size={16} className="text-green-400"/>:doc.status==="pending"?<Clock size={16} className="text-amber-400"/>:<AlertCircle size={16} className="text-red-400"/>}<p className="text-sm font-semibold text-foreground">{doc.type}</p></div><StatusBadge status={doc.status}/></div>
                  {doc.status==="missing"?<button className="w-full border border-dashed border-primary/30 bg-primary/5 text-primary rounded-xl py-2.5 text-xs font-medium flex items-center justify-center gap-1.5"><Plus size={12}/>{t("upload")} {doc.type}</button>:doc.status==="pending"?<div className="flex gap-2"><button className="flex-1 bg-secondary rounded-xl py-2 text-xs text-muted-foreground">{t("viewFile")}</button><button className="flex-1 border border-dashed border-amber-500/30 rounded-xl py-2 text-xs text-amber-400">{t("replace")}</button></div>:<button className="w-full bg-secondary rounded-xl py-2 text-xs text-muted-foreground">{t("viewFile")}</button>}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* EDIT PROFILE */}
        {screen==="edit-profile" && (
          <div className="flex flex-col h-full">
            <BackHeader onBack={goBack} title={t("editProfile")}/>
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
              {[{label:t("fullName"),ph:driverData.name},{label:t("carModel"),ph:driverData.car.model},{label:t("carColor"),ph:driverData.car.color},{label:t("plateNumber"),ph:driverData.car.plate}].map(({label,ph},i)=>(
                <div key={i}><label className="text-xs text-muted-foreground mb-1.5 block">{label}</label><input className="w-full bg-input-background border border-border rounded-xl px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground font-mono outline-none" placeholder={ph} defaultValue={ph}/></div>
              ))}
              <button className="w-full bg-primary text-white rounded-2xl py-3.5 text-sm font-semibold mt-2" onClick={goBack}>{t("saveChanges")}</button>
            </div>
          </div>
        )}

        {/* SETTINGS */}
        {screen==="settings" && <SettingsPanel onBack={goBack} themeMode={themeMode} onThemeChange={onThemeChange} lang={lang} onLangChange={onLangChange} onLogout={onLogout} notifKeys={{a:"orderUpdates",ad:"orderUpdatesDesc",b:"bidAlerts",bd:"bidAlertsDesc"}}/>}

        {/* PROFILE */}
        {screen==="profile" && (
          <div className="flex flex-col gap-4 p-4 pb-6">
            <h1 className="text-xl font-semibold text-foreground pt-1">{t("profile")}</h1>
            <div className="rounded-2xl border border-border bg-card p-5">
              <div className="flex items-center gap-4 mb-4"><div className="w-16 h-16 rounded-2xl bg-primary/15 flex items-center justify-center"><Truck size={28} className="text-primary"/></div><div className="flex-1 min-w-0"><h2 className="text-lg font-bold text-foreground truncate">{driverData.name}</h2><p className="text-sm text-muted-foreground font-mono">{driverData.phone}</p><div className="flex gap-2 mt-1"><StatusBadge status={driverData.status}/><StatusBadge status={avail?"active":"inactive"}/></div></div></div>
              <div className="grid grid-cols-3 gap-3 pt-4 border-t border-border">{[{icon:Star,label:t("rating"),value:driverData.rating.toString(),color:"text-amber-400"},{icon:CheckCircle2,label:t("completed"),value:driverData.completedOrders.toString(),color:"text-green-400"},{icon:Package,label:t("total"),value:driverData.totalOrders.toString(),color:"text-primary"}].map(({icon:Icon,label,value,color})=><div key={label} className="text-center"><Icon size={14} className="text-primary mx-auto mb-1"/><p className="text-base font-bold font-mono text-foreground">{value}</p><p className="text-[10px] text-muted-foreground">{label}</p></div>)}</div>
            </div>
            <div className="rounded-2xl border border-border bg-card p-4"><div className="flex items-center justify-between"><div><p className="text-sm font-semibold text-foreground">{t("availability")}</p><p className="text-xs text-muted-foreground">{avail?t("youAreOnline"):t("youAreOffline")}</p></div><button onClick={isApproved?()=>setAvail(v=>!v):undefined} className={!isApproved?"opacity-40 cursor-not-allowed":""}>{avail?<ToggleRight size={36} className="text-primary"/>:<ToggleLeft size={36} className="text-muted-foreground"/>}</button></div></div>
            <div className="rounded-2xl border border-border bg-card p-4">
              <div className="flex items-center gap-2 mb-3"><Truck size={16} className="text-primary"/><p className="text-sm font-semibold text-foreground">{t("vehicle")}</p><StatusBadge status="approved"/></div>
              <div className="flex flex-col gap-2">{[{label:t("carModel"),value:driverData.car.model},{label:t("carColor"),value:driverData.car.color},{label:t("plateNumber"),value:driverData.car.plate}].map(({label,value})=><div key={label} className="flex justify-between"><span className="text-xs text-muted-foreground">{label}</span><span className="text-xs font-mono text-foreground">{value}</span></div>)}</div>
            </div>
            <div className="rounded-2xl border border-border bg-card overflow-hidden">
              {[{icon:Pencil,label:t("editProfile"),action:()=>goTo("edit-profile")},{icon:FileText,label:t("documents"),action:()=>goTo("documents")},{icon:Route,label:t("myRoutes"),action:()=>switchTab("routes")},{icon:Package,label:t("orders"),action:()=>switchTab("orders")},{icon:TrendingUp,label:t("income"),action:()=>goTo("income")},{icon:Settings,label:t("settings"),action:()=>goTo("settings")}].map(({icon:Icon,label,action},i)=>(
                <button key={label} onClick={action} className={`w-full flex items-center gap-3 px-4 py-3.5 hover:bg-secondary/50 transition-colors ${i>0?"border-t border-border":""}`}><Icon size={16} className="text-muted-foreground"/><span className="text-sm text-foreground flex-1 text-left">{label}</span><ChevronRight size={14} className="text-muted-foreground"/></button>
              ))}
              <button onClick={onLogout} className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-red-500/5 transition-colors border-t border-border"><LogOut size={16} className="text-red-400"/><span className="text-sm text-red-400 flex-1 text-left">{t("logOut")}</span></button>
            </div>
          </div>
        )}
      </div>

      {/* Driver bottom nav */}
      {!isDetail && (
        <div className="flex-shrink-0 bg-card border-t border-border px-2 pt-2 pb-6">
          <div className="flex">
            {([{id:"home" as DriverTab,icon:Home},{id:"routes" as DriverTab,icon:Route},{id:"orders" as DriverTab,icon:Inbox},{id:"profile" as DriverTab,icon:User}]).map(({id,icon:Icon})=>{
              const active=tab===id&&screen===id;
              const label=id==="home"?t("home"):id==="routes"?t("myRoutes"):id==="orders"?t("orders"):t("profile");
              return <button key={id} onClick={()=>switchTab(id)} className="flex-1 flex flex-col items-center gap-1 py-2 rounded-xl transition-colors"><div className={`p-1.5 rounded-xl ${active?"bg-primary/15":""}`}><Icon size={20} className={active?"text-primary":"text-muted-foreground"} strokeWidth={active?2.5:1.5}/></div><span className={`text-[10px] font-medium ${active?"text-primary":"text-muted-foreground"}`}>{label}</span></button>;
            })}
          </div>
        </div>
      )}
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// ADMIN PANEL
// ═══════════════════════════════════════════════════════════════════════════════

// ── Admin Mock Data ───────────────────────────────────────────────────────────

const adminMetrics = {
  totalRevenue: 45_680_000, platformProfit: 4_568_000, driverEarnings: 41_112_000, avgOrderValue: 178_437,
  totalOrders: 256, publishedBidding: 18, activeDeliveries: 23, deliveredToday: 9,
  confirmed: 187, pendingDrivers: 8, approvedDrivers: 34, openDisputes: 3,
  activeCities: 12, activeTariffs: 28, missingTariffs: 4,
  todayProfit: 312_000,
};

const adminOrders = [
  { id:"ORD-5021",code:"#5021",from:"Tashkent",to:"Samarkand",client:"Aziz K.",driver:"Jasur T.",price:145_000,status:"bidding",   payment:"pending",  date:"Jun 25, 09:14" },
  { id:"ORD-5019",code:"#5019",from:"Tashkent",to:"Fergana",  client:"Nodira R.",driver:"Bobur Y.",price:200_000,status:"in_transit",payment:"pending",  date:"Jun 25, 08:30" },
  { id:"ORD-5015",code:"#5015",from:"Samarkand",to:"Tashkent",client:"Ulugbek M.",driver:"Sherzod K.",price:155_000,status:"delivered", payment:"pending",  date:"Jun 24, 17:42" },
  { id:"ORD-5012",code:"#5012",from:"Tashkent",to:"Bukhara", client:"Malika S.",driver:"Doniyor A.",price:210_000,status:"confirmed", payment:"completed",date:"Jun 24, 14:10" },
  { id:"ORD-5008",code:"#5008",from:"Fergana", to:"Tashkent",client:"Sardor B.",driver:"—",         price:180_000,status:"published", payment:"pending",  date:"Jun 24, 11:05" },
  { id:"ORD-5004",code:"#5004",from:"Tashkent",to:"Namangan",client:"Zulfiya T.",driver:"Otabek N.",price:195_000,status:"accepted",  payment:"pending",  date:"Jun 24, 09:33" },
  { id:"ORD-4998",code:"#4998",from:"Bukhara", to:"Tashkent",client:"Kamol H.",driver:"—",          price:200_000,status:"cancelled", payment:"pending",  date:"Jun 23, 16:20" },
  { id:"ORD-4995",code:"#4995",from:"Tashkent",to:"Andijan", client:"Feruza A.",driver:"Behruz R.", price:185_000,status:"disputed",  payment:"pending",  date:"Jun 23, 13:45" },
  { id:"ORD-4990",code:"#4990",from:"Namangan",to:"Tashkent",client:"Jasur Q.",driver:"Dilshod M.", price:192_000,status:"confirmed", payment:"completed",date:"Jun 23, 10:11" },
  { id:"ORD-4985",code:"#4985",from:"Tashkent",to:"Termiz",  client:"Barno Y.",driver:"Sanjar K.",  price:248_000,status:"confirmed", payment:"completed",date:"Jun 22, 15:58" },
];

const adminDrivers = [
  { id:1,name:"Jasur Toshmatov",  phone:"+998901234567",car:"Nexia 3",plate:"01A777AA", status:"approved", avail:true,  docs:5,routes:3,orders:143,rating:4.8,created:"Mar 12" },
  { id:2,name:"Bobur Yusupov",   phone:"+998901234568",car:"Cobalt",  plate:"30B123CC", status:"pending",  avail:false, docs:3,routes:2,orders:0,  rating:0,  created:"Jun 20" },
  { id:3,name:"Sherzod Karimov", phone:"+998901234569",car:"Lacetti", plate:"10C456BB", status:"approved", avail:true,  docs:5,routes:4,orders:201,rating:4.9,created:"Jan 5"  },
  { id:4,name:"Doniyor Alimov",  phone:"+998901234570",car:"Malibu",  plate:"40D789CC", status:"approved", avail:false, docs:5,routes:2,orders:89, rating:4.7,created:"Feb 18" },
  { id:5,name:"Otabek Nazarov",  phone:"+998901234571",car:"Nexia 2", plate:"50E012DD", status:"pending",  avail:false, docs:4,routes:1,orders:0,  rating:0,  created:"Jun 22" },
  { id:6,name:"Behruz Razzaqov", phone:"+998901234572",car:"Spark",   plate:"60F345EE", status:"rejected", avail:false, docs:2,routes:0,orders:0,  rating:0,  created:"Jun 18" },
  { id:7,name:"Sanjar Komilov",  phone:"+998901234573",car:"Lacetti", plate:"70G678FF", status:"approved", avail:true,  docs:5,routes:3,orders:67, rating:4.6,created:"Apr 3"  },
  { id:8,name:"Dilshod Mirzayev",phone:"+998901234574",car:"Cobalt",  plate:"80H901GG", status:"blocked",  avail:false, docs:5,routes:2,orders:12, rating:3.2,created:"May 10" },
];

const adminClients = [
  { id:1,name:"Aziz Karimov",   phone:"+998901111111",status:"active",  verified:true, orders:5,active:1,last:"Jun 25",created:"Jan 20" },
  { id:2,name:"Nodira Rashidova",phone:"+998902222222",status:"active", verified:true, orders:12,active:1,last:"Jun 25",created:"Dec 5"  },
  { id:3,name:"Ulugbek Mamatov",phone:"+998903333333", status:"active", verified:true, orders:3, active:0,last:"Jun 24",created:"Mar 8"  },
  { id:4,name:"Malika Saidova",  phone:"+998904444444",status:"active", verified:true, orders:8, active:0,last:"Jun 24",created:"Feb 14" },
  { id:5,name:"Sardor Botirov",  phone:"+998905555555",status:"active", verified:false,orders:1, active:1,last:"Jun 24",created:"Jun 20" },
  { id:6,name:"Zulfiya Tursunova",phone:"+998906666666",status:"active",verified:true, orders:6, active:1,last:"Jun 24",created:"Apr 2"  },
  { id:7,name:"Kamol Holiqov",   phone:"+998907777777",status:"blocked",verified:true, orders:4, active:0,last:"Jun 23",created:"Mar 15" },
  { id:8,name:"Feruza Abdullayeva",phone:"+998908888888",status:"active",verified:true,orders:9, active:1,last:"Jun 23",created:"Nov 30" },
];

const adminRegions = [
  { id:1,uz:"Toshkent",      ru:"Ташкент",   type:"city",   dist:true, districts:12,active:true  },
  { id:2,uz:"Samarqand",     ru:"Самарканд", type:"region", dist:false,districts:14,active:true  },
  { id:3,uz:"Buxoro",        ru:"Бухара",    type:"region", dist:false,districts:11,active:true  },
  { id:4,uz:"Farg'ona",      ru:"Фергана",   type:"region", dist:true, districts:15,active:true  },
  { id:5,uz:"Namangan",      ru:"Наманган",  type:"region", dist:false,districts:11,active:true  },
  { id:6,uz:"Andijon",       ru:"Андижан",   type:"region", dist:false,districts:14,active:true  },
  { id:7,uz:"Nukus",         ru:"Нукус",     type:"city",   dist:false,districts:0, active:true  },
  { id:8,uz:"Termiz",        ru:"Термез",    type:"city",   dist:false,districts:0, active:true  },
  { id:9,uz:"Qarshi",        ru:"Карши",     type:"city",   dist:false,districts:0, active:true  },
  { id:10,uz:"Jizzax",       ru:"Джизак",    type:"region", dist:false,districts:12,active:true  },
  { id:11,uz:"Guliston",     ru:"Гулистан",  type:"city",   dist:false,districts:0, active:true  },
  { id:12,uz:"Navoiy",       ru:"Навои",     type:"region", dist:false,districts:8, active:false },
];

const adminTariffs = [
  { id:1,from:"Tashkent", to:"Samarkand",suggested:150_000,min:120_000,max:200_000,currency:"UZS",active:true, created:"Jan 5"  },
  { id:2,from:"Samarkand",to:"Tashkent", suggested:150_000,min:120_000,max:200_000,currency:"UZS",active:true, created:"Jan 5"  },
  { id:3,from:"Tashkent", to:"Fergana",  suggested:180_000,min:150_000,max:230_000,currency:"UZS",active:true, created:"Jan 6"  },
  { id:4,from:"Tashkent", to:"Bukhara",  suggested:200_000,min:170_000,max:260_000,currency:"UZS",active:true, created:"Jan 6"  },
  { id:5,from:"Tashkent", to:"Nukus",    suggested:280_000,min:250_000,max:350_000,currency:"UZS",active:true, created:"Jan 7"  },
  { id:6,from:"Tashkent", to:"Termiz",   suggested:250_000,min:220_000,max:320_000,currency:"UZS",active:true, created:"Jan 7"  },
  { id:7,from:"Fergana",  to:"Tashkent", suggested:180_000,min:150_000,max:230_000,currency:"UZS",active:true, created:"Feb 1"  },
  { id:8,from:"Bukhara",  to:"Tashkent", suggested:200_000,min:170_000,max:260_000,currency:"UZS",active:false,created:"Feb 1"  },
  { id:9,from:"Tashkent", to:"Namangan", suggested:190_000,min:160_000,max:240_000,currency:"UZS",active:true, created:"Feb 5"  },
  { id:10,from:"Samarkand",to:"Bukhara",suggested:120_000,min:100_000,max:160_000,currency:"UZS",active:true, created:"Mar 2"  },
];

const adminDisputes = [
  { id:1,orderId:"ORD-4995",reason:"Cargo damaged",status:"open",      openedBy:"Feruza A.",created:"Jun 23",resolution:"" },
  { id:2,orderId:"ORD-4920",reason:"Late delivery",  status:"in_review", openedBy:"Ulugbek M.",created:"Jun 20",resolution:"" },
  { id:3,orderId:"ORD-4800",reason:"Driver behavior",status:"resolved",  openedBy:"Malika S.", created:"Jun 15",resolution:"Refund issued" },
  { id:4,orderId:"ORD-4750",reason:"Wrong address",  status:"resolved",  openedBy:"Aziz K.",   created:"Jun 10",resolution:"Clarified" },
  { id:5,orderId:"ORD-4700",reason:"Other",           status:"open",      openedBy:"Sardor B.", created:"Jun 23",resolution:"" },
];

const adminStaff = [
  { id:1,name:"Alisher Qodirov",  phone:"+998901230001",role:"super_admin",status:"active", verified:true, created:"Dec 1",  lastLogin:"Jun 25" },
  { id:2,name:"Shahnoza Nazarova",phone:"+998901230002",role:"admin",       status:"active", verified:true, created:"Jan 10", lastLogin:"Jun 25" },
  { id:3,name:"Bekzod Tursunov",  phone:"+998901230003",role:"operator",    status:"active", verified:true, created:"Feb 5",  lastLogin:"Jun 24" },
  { id:4,name:"Dilnoza Yusupova", phone:"+998901230004",role:"operator",    status:"active", verified:false,created:"May 20", lastLogin:"Jun 23" },
  { id:5,name:"Timur Abdullayev", phone:"+998901230005",role:"operator",    status:"blocked",verified:true, created:"Apr 1",  lastLogin:"Jun 10" },
];

const adminAuditLog = [
  { id:1,actor:"Shahnoza Nazarova",role:"admin",   action:"approve_driver",  entity:"driver",  entityId:"3",    created:"Jun 25, 09:20" },
  { id:2,actor:"Bekzod Tursunov",  role:"operator",action:"assign_driver",   entity:"order",   entityId:"5019", created:"Jun 25, 08:35" },
  { id:3,actor:"Alisher Qodirov",  role:"admin",   action:"update_commission",entity:"settings",entityId:"1",   created:"Jun 24, 17:00" },
  { id:4,actor:"Shahnoza Nazarova",role:"admin",   action:"reject_driver",   entity:"driver",  entityId:"6",    created:"Jun 24, 14:30" },
  { id:5,actor:"Bekzod Tursunov",  role:"operator",action:"cancel_order",    entity:"order",   entityId:"4998", created:"Jun 24, 11:15" },
  { id:6,actor:"Shahnoza Nazarova",role:"admin",   action:"block_client",    entity:"client",  entityId:"7",    created:"Jun 23, 16:40" },
  { id:7,actor:"Dilnoza Yusupova", role:"operator",action:"update_status",   entity:"order",   entityId:"5015", created:"Jun 23, 15:00" },
  { id:8,actor:"Alisher Qodirov",  role:"admin",   action:"create_tariff",   entity:"tariff",  entityId:"10",   created:"Jun 22, 10:30" },
];

const adminAdminNotifs = [
  { id:1,recipient:"All drivers",  type:"system",   title:"Commission update",         message:"Platform commission updated to 10%", channel:"push",read:false,date:"Jun 25, 09:00" },
  { id:2,recipient:"Feruza A.",    type:"dispute",  title:"Dispute opened",            message:"Order ORD-4995 dispute opened",      channel:"push",read:true, date:"Jun 23, 13:45" },
  { id:3,recipient:"Jasur T.",     type:"order",    title:"New order assigned",        message:"Order ORD-5021 assigned to you",     channel:"push",read:true, date:"Jun 25, 09:14" },
  { id:4,recipient:"All operators",type:"system",   title:"System maintenance",        message:"Scheduled at 02:00 AM tonight",      channel:"email",read:false,date:"Jun 24, 18:00"},
  { id:5,recipient:"Aziz K.",      type:"bid",      title:"New bid received",          message:"Driver Jasur T. sent a bid",         channel:"push",read:true, date:"Jun 25, 09:15" },
];

// ── Admin Shared Components ───────────────────────────────────────────────────

function AdminStatusBadge({ status }: { status: string }) {
  const map: Record<string,string> = {
    published: "bg-blue-100 text-blue-700 border-blue-200",
    bidding:   "bg-amber-100 text-amber-700 border-amber-200",
    accepted:  "bg-blue-100 text-blue-800 border-blue-200",
    in_transit:"bg-indigo-100 text-indigo-700 border-indigo-200",
    delivered: "bg-green-100 text-green-700 border-green-200",
    confirmed: "bg-emerald-100 text-emerald-700 border-emerald-200",
    cancelled: "bg-red-100 text-red-700 border-red-200",
    disputed:  "bg-rose-100 text-rose-700 border-rose-200",
    approved:  "bg-green-100 text-green-700 border-green-200",
    pending:   "bg-amber-100 text-amber-700 border-amber-200",
    rejected:  "bg-red-100 text-red-700 border-red-200",
    blocked:   "bg-slate-100 text-slate-600 border-slate-200",
    new:       "bg-slate-100 text-slate-600 border-slate-200",
    active:    "bg-green-100 text-green-700 border-green-200",
    inactive:  "bg-slate-100 text-slate-500 border-slate-200",
    open:      "bg-rose-100 text-rose-700 border-rose-200",
    in_review: "bg-amber-100 text-amber-700 border-amber-200",
    resolved:  "bg-green-100 text-green-700 border-green-200",
    completed: "bg-emerald-100 text-emerald-700 border-emerald-200",
    super_admin:"bg-purple-100 text-purple-700 border-purple-200",
    admin:     "bg-blue-100 text-blue-700 border-blue-200",
    operator:  "bg-slate-100 text-slate-600 border-slate-200",
    system:    "bg-slate-100 text-slate-500 border-slate-200",
    push:      "bg-blue-100 text-blue-600 border-blue-200",
    email:     "bg-violet-100 text-violet-600 border-violet-200",
  };
  const cls = map[status] ?? "bg-slate-100 text-slate-600 border-slate-200";
  const label = status.replace(/_/g," ").replace(/\b\w/g, l=>l.toUpperCase());
  return <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold border uppercase tracking-wide ${cls}`}>{label}</span>;
}

function AdminMetricCard({ title, value, sub, icon: Icon, color, onClick }: {
  title:string; value:string; sub?:string; icon:typeof Home; color:string; onClick?:()=>void;
}) {
  return (
    <div onClick={onClick} className={`bg-white border border-slate-200 rounded-lg p-4 flex items-start gap-3 ${onClick?"cursor-pointer hover:shadow-md hover:border-blue-200":""} transition-all`}>
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${color}`}>
        <Icon size={18}/>
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-500 mb-0.5">{title}</p>
        <p className="text-xl font-bold text-slate-900 font-mono leading-tight">{value}</p>
        {sub && <p className="text-[11px] text-slate-400 mt-0.5">{sub}</p>}
      </div>
    </div>
  );
}

function AdminTableWrapper({ children, className="" }: { children:React.ReactNode; className?:string }) {
  return (
    <div className={`overflow-x-auto rounded-lg border border-slate-200 bg-white ${className}`}>
      <table className="min-w-full text-sm">{children}</table>
    </div>
  );
}

function AdminTh({ children }: { children:React.ReactNode }) {
  return <th className="px-4 py-2.5 text-[10px] font-semibold uppercase tracking-widest text-slate-500 text-left bg-slate-50 border-b border-slate-200 whitespace-nowrap">{children}</th>;
}
function AdminTd({ children, className="" }: { children:React.ReactNode; className?:string }) {
  return <td className={`px-4 py-2.5 text-slate-700 border-b border-slate-100 whitespace-nowrap ${className}`}>{children}</td>;
}

function AdminSearchBar({ placeholder, value, onChange }: { placeholder:string; value:string; onChange:(v:string)=>void }) {
  return (
    <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
      <Search size={14} className="text-slate-400 flex-shrink-0"/>
      <input className="flex-1 bg-transparent text-sm text-slate-700 placeholder:text-slate-400 outline-none min-w-0"
        placeholder={placeholder} value={value} onChange={e=>onChange(e.target.value)}/>
    </div>
  );
}

function AdminActionBtn({ label, onClick, variant="default", icon:Icon }: {
  label:string; onClick?:()=>void; variant?:"default"|"approve"|"reject"|"block"|"danger"; icon?:typeof Eye;
}) {
  const cls = {
    default:"border-slate-200 text-slate-600 hover:bg-slate-50",
    approve:"border-green-200 text-green-700 hover:bg-green-50",
    reject: "border-orange-200 text-orange-700 hover:bg-orange-50",
    block:  "border-red-200 text-red-700 hover:bg-red-50",
    danger: "border-red-200 text-red-700 hover:bg-red-50",
  }[variant];
  return (
    <button onClick={onClick} title={label} className={`inline-flex items-center gap-1 px-2 py-1 rounded border text-[11px] font-medium transition-colors ${cls}`}>
      {Icon && <Icon size={11}/>}{label}
    </button>
  );
}

// ── Admin Drawer ──────────────────────────────────────────────────────────────

function AdminDrawer({ title, onClose, children }: { title:string; onClose:()=>void; children:React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="flex-1 bg-black/30 backdrop-blur-sm" onClick={onClose}/>
      <div className="w-[420px] bg-white h-full shadow-2xl flex flex-col overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 flex-shrink-0">
          <h2 className="text-base font-semibold text-slate-800">{title}</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-100 transition-colors"><X size={16} className="text-slate-500"/></button>
        </div>
        <div className="flex-1 overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}

// ── Admin Modal ───────────────────────────────────────────────────────────────

function AdminModal({ title, onClose, onSubmit, submitLabel="Submit", submitVariant="primary", children }: {
  title:string; onClose:()=>void; onSubmit?:()=>void; submitLabel?:string; submitVariant?:"primary"|"danger"; children:React.ReactNode;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose}/>
      <div className="relative bg-white rounded-xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200">
          <h2 className="text-base font-semibold text-slate-800">{title}</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-100"><X size={16} className="text-slate-500"/></button>
        </div>
        <div className="p-5 flex flex-col gap-4">{children}</div>
        {onSubmit && (
          <div className="flex gap-3 px-5 py-4 border-t border-slate-200">
            <button onClick={onClose} className="flex-1 border border-slate-200 rounded-lg py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50">Cancel</button>
            <button onClick={()=>{onSubmit();onClose();}} className={`flex-[2] rounded-lg py-2.5 text-sm font-semibold text-white ${submitVariant==="danger"?"bg-red-600 hover:bg-red-700":"bg-[#1B4FD8] hover:bg-blue-700"}`}>{submitLabel}</button>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Admin Dashboard ───────────────────────────────────────────────────────────

function AdminDashboard({ onNav }: { onNav:(s:AdminSection)=>void }) {
  const fm = (n:number) => (n/1_000_000).toFixed(2)+"M so'm";
  const fk = (n:number) => (n/1_000).toFixed(0)+"K so'm";
  return (
    <div className="p-6 space-y-6">
      {/* Financial metrics */}
      <div>
        <p className="text-xs font-semibold uppercase tracking-widest text-slate-400 mb-3">Financial Overview</p>
        <div className="grid grid-cols-4 gap-4">
          <AdminMetricCard title="Total Revenue"    value={fm(adminMetrics.totalRevenue)}    icon={DollarSign}   color="bg-blue-50 text-blue-600"/>
          <AdminMetricCard title="Platform Profit"  value={fm(adminMetrics.platformProfit)}  icon={TrendingUp}   color="bg-emerald-50 text-emerald-600" sub={`Today: ${fk(adminMetrics.todayProfit)}`}/>
          <AdminMetricCard title="Driver Earnings"  value={fm(adminMetrics.driverEarnings)}  icon={Truck}        color="bg-violet-50 text-violet-600"/>
          <AdminMetricCard title="Avg Order Value"  value={fk(adminMetrics.avgOrderValue)}   icon={Activity}     color="bg-amber-50 text-amber-600"/>
        </div>
      </div>

      {/* Operations metrics */}
      <div>
        <p className="text-xs font-semibold uppercase tracking-widest text-slate-400 mb-3">Operations</p>
        <div className="grid grid-cols-4 gap-4">
          <AdminMetricCard title="Total Orders"      value={adminMetrics.totalOrders.toString()}      icon={Package}    color="bg-slate-100 text-slate-600" onClick={()=>onNav("orders")}/>
          <AdminMetricCard title="Active Deliveries" value={adminMetrics.activeDeliveries.toString()} icon={Navigation} color="bg-indigo-50 text-indigo-600" onClick={()=>onNav("orders")}/>
          <AdminMetricCard title="Pending Drivers"   value={adminMetrics.pendingDrivers.toString()}   icon={Clock}      color="bg-amber-50 text-amber-600"   onClick={()=>onNav("drivers")}/>
          <AdminMetricCard title="Open Disputes"     value={adminMetrics.openDisputes.toString()}     icon={Flag}       color="bg-rose-50 text-rose-600"     onClick={()=>onNav("disputes")}/>
          <AdminMetricCard title="Published/Bidding" value={adminMetrics.publishedBidding.toString()} icon={CircleDot}  color="bg-blue-50 text-blue-600"     onClick={()=>onNav("orders")}/>
          <AdminMetricCard title="Approved Drivers"  value={adminMetrics.approvedDrivers.toString()}  icon={UserCheck}  color="bg-green-50 text-green-600"   onClick={()=>onNav("drivers")}/>
          <AdminMetricCard title="Active Tariffs"    value={adminMetrics.activeTariffs.toString()}    icon={Tag}        color="bg-teal-50 text-teal-600"     onClick={()=>onNav("tariffs")}/>
          <AdminMetricCard title="Missing Tariffs"   value={adminMetrics.missingTariffs.toString()}   icon={AlertCircle}color="bg-red-50 text-red-600"       onClick={()=>onNav("tariffs")}/>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Recent orders */}
        <div className="col-span-2 bg-white border border-slate-200 rounded-lg overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100">
            <p className="text-sm font-semibold text-slate-800">Recent Orders</p>
            <button onClick={()=>onNav("orders")} className="text-xs text-blue-600 hover:underline flex items-center gap-1">View all <ChevronRight size={12}/></button>
          </div>
          <AdminTableWrapper>
            <thead><tr><AdminTh>Order</AdminTh><AdminTh>Route</AdminTh><AdminTh>Client</AdminTh><AdminTh>Status</AdminTh><AdminTh>Price</AdminTh></tr></thead>
            <tbody>
              {adminOrders.slice(0,6).map(o=>(
                <tr key={o.id} className="hover:bg-slate-50">
                  <AdminTd><span className="font-mono text-xs text-slate-500">{o.code}</span></AdminTd>
                  <AdminTd><span className="font-medium">{o.from}</span><span className="text-slate-400 mx-1">→</span>{o.to}</AdminTd>
                  <AdminTd>{o.client}</AdminTd>
                  <AdminTd><AdminStatusBadge status={o.status}/></AdminTd>
                  <AdminTd><span className="font-mono text-xs">{(o.price/1000).toFixed(0)}K</span></AdminTd>
                </tr>
              ))}
            </tbody>
          </AdminTableWrapper>
        </div>

        {/* Right panels */}
        <div className="flex flex-col gap-4">
          {/* Driver queue */}
          <div className="bg-white border border-slate-200 rounded-lg overflow-hidden flex-1">
            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100">
              <p className="text-sm font-semibold text-slate-800">Verification Queue</p>
              <button onClick={()=>onNav("drivers")} className="text-xs text-blue-600 hover:underline"><ChevronRight size={12}/></button>
            </div>
            <div className="divide-y divide-slate-100">
              {adminDrivers.filter(d=>d.status==="pending").map(d=>(
                <div key={d.id} className="flex items-center gap-3 px-4 py-2.5">
                  <div className="w-7 h-7 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0"><Truck size={12} className="text-amber-600"/></div>
                  <div className="flex-1 min-w-0"><p className="text-xs font-medium text-slate-800 truncate">{d.name}</p><p className="text-[10px] text-slate-400 font-mono">{d.docs}/5 docs</p></div>
                  <AdminStatusBadge status={d.status}/>
                </div>
              ))}
            </div>
          </div>

          {/* Disputes */}
          <div className="bg-white border border-slate-200 rounded-lg overflow-hidden flex-1">
            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100">
              <p className="text-sm font-semibold text-slate-800">Open Disputes</p>
              <button onClick={()=>onNav("disputes")} className="text-xs text-blue-600 hover:underline"><ChevronRight size={12}/></button>
            </div>
            <div className="divide-y divide-slate-100">
              {adminDisputes.filter(d=>d.status==="open"||d.status==="in_review").map(d=>(
                <div key={d.id} className="flex items-center gap-3 px-4 py-2.5">
                  <div className="w-7 h-7 rounded-full bg-rose-100 flex items-center justify-center flex-shrink-0"><Flag size={12} className="text-rose-600"/></div>
                  <div className="flex-1 min-w-0"><p className="text-xs font-medium text-slate-800 truncate">{d.orderId}</p><p className="text-[10px] text-slate-400">{d.reason}</p></div>
                  <AdminStatusBadge status={d.status}/>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Recent audit */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100">
          <p className="text-sm font-semibold text-slate-800">Recent Activity</p>
          <button onClick={()=>onNav("audit")} className="text-xs text-blue-600 hover:underline flex items-center gap-1">View log <ChevronRight size={12}/></button>
        </div>
        <AdminTableWrapper>
          <thead><tr><AdminTh>Actor</AdminTh><AdminTh>Role</AdminTh><AdminTh>Action</AdminTh><AdminTh>Entity</AdminTh><AdminTh>Time</AdminTh></tr></thead>
          <tbody>
            {adminAuditLog.slice(0,5).map(l=>(
              <tr key={l.id} className="hover:bg-slate-50">
                <AdminTd><span className="font-medium">{l.actor}</span></AdminTd>
                <AdminTd><AdminStatusBadge status={l.role}/></AdminTd>
                <AdminTd><span className="font-mono text-xs bg-slate-100 px-2 py-0.5 rounded">{l.action}</span></AdminTd>
                <AdminTd><span className="text-slate-500">{l.entity}</span> <span className="font-mono text-xs text-slate-400">#{l.entityId}</span></AdminTd>
                <AdminTd><span className="text-slate-400 text-xs">{l.created}</span></AdminTd>
              </tr>
            ))}
          </tbody>
        </AdminTableWrapper>
      </div>
    </div>
  );
}

// ── Admin Orders ──────────────────────────────────────────────────────────────

function AdminOrders() {
  const [tab,setTab] = useState<string>("all");
  const [search,setSearch] = useState("");
  const [drawer,setDrawer] = useState<typeof adminOrders[number]|null>(null);
  const [modal,setModal] = useState<"assign"|"status"|"cancel"|null>(null);
  const [drawerTab,setDrawerTab] = useState("overview");

  const tabs = ["all","published","bidding","accepted","in_transit","delivered","confirmed","cancelled","disputed"];
  const filtered = adminOrders.filter(o=>(tab==="all"||o.status===tab) && (search===""||o.code.includes(search)||o.client.toLowerCase().includes(search.toLowerCase())||o.driver.toLowerCase().includes(search.toLowerCase())));

  return (
    <div className="p-6 space-y-5">
      {drawer && (
        <AdminDrawer title={`Order ${drawer.code}`} onClose={()=>setDrawer(null)}>
          {modal==="assign" && (
            <AdminModal title="Assign Driver" onClose={()=>setModal(null)} onSubmit={()=>{}} submitLabel="Assign Driver">
              <div><label className="text-xs font-medium text-slate-600 block mb-1.5">Search Driver</label><AdminSearchBar placeholder="Name, phone or plate..." value="" onChange={()=>{}}/></div>
              <div><label className="text-xs font-medium text-slate-600 block mb-1.5">Final Price</label><input className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none" placeholder="e.g. 145000"/></div>
              <div><label className="text-xs font-medium text-slate-600 block mb-1.5">Reason *</label><textarea rows={2} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none resize-none" placeholder="Admin assignment reason..."/></div>
            </AdminModal>
          )}
          {modal==="status" && (
            <AdminModal title="Change Status" onClose={()=>setModal(null)} onSubmit={()=>{}} submitLabel="Update Status">
              <div><label className="text-xs font-medium text-slate-600 block mb-1.5">New Status</label><select className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none appearance-none"><option>Select status...</option>{tabs.slice(1).map(t=><option key={t}>{t.replace("_"," ")}</option>)}</select></div>
              <div><label className="text-xs font-medium text-slate-600 block mb-1.5">Reason *</label><textarea rows={2} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none resize-none" placeholder="Reason for status change..."/></div>
            </AdminModal>
          )}
          {modal==="cancel" && (
            <AdminModal title="Cancel Order" onClose={()=>setModal(null)} onSubmit={()=>{}} submitLabel="Cancel Order" submitVariant="danger">
              <p className="text-sm text-slate-600">This action cannot be undone. Order <strong>{drawer.code}</strong> will be cancelled.</p>
              <div><label className="text-xs font-medium text-slate-600 block mb-1.5">Reason *</label><textarea rows={3} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none resize-none" placeholder="Cancellation reason..."/></div>
            </AdminModal>
          )}
          <div className="p-5 space-y-4">
            <div className="flex items-center justify-between">
              <AdminStatusBadge status={drawer.status}/>
              <span className="text-xs text-slate-400">{drawer.date}</span>
            </div>
            {/* Drawer tabs */}
            <div className="flex gap-1 bg-slate-100 rounded-lg p-1">
              {["overview","bids","history"].map(t=><button key={t} onClick={()=>setDrawerTab(t)} className={`flex-1 py-1.5 rounded-md text-xs font-medium capitalize transition-colors ${drawerTab===t?"bg-white text-slate-800 shadow-sm":"text-slate-500"}`}>{t}</button>)}
            </div>
            {drawerTab==="overview" && (
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-slate-50 rounded-lg p-3"><p className="text-[10px] text-slate-400 uppercase mb-1">From</p><p className="text-sm font-semibold text-slate-800">{drawer.from}</p></div>
                  <div className="bg-slate-50 rounded-lg p-3"><p className="text-[10px] text-slate-400 uppercase mb-1">To</p><p className="text-sm font-semibold text-slate-800">{drawer.to}</p></div>
                </div>
                {[
                  {label:"Client",value:drawer.client},{label:"Driver",value:drawer.driver},
                  {label:"Suggested Price",value:(drawer.price/1000).toFixed(0)+"K so'm"},
                  {label:"Payment",value:drawer.payment},{label:"Date",value:drawer.date},
                ].map(({label,value})=>(
                  <div key={label} className="flex items-center justify-between py-2 border-b border-slate-100">
                    <span className="text-xs text-slate-500">{label}</span>
                    <span className="text-sm font-medium text-slate-800">{value}</span>
                  </div>
                ))}
              </div>
            )}
            {drawerTab==="bids" && (
              <div className="space-y-2">
                {adminDrivers.slice(0,3).map((d,i)=>(
                  <div key={d.id} className={`flex items-center gap-3 p-3 rounded-lg border ${i===0?"border-green-200 bg-green-50":"border-slate-200"}`}>
                    <div className="flex-1"><p className="text-sm font-medium text-slate-800">{d.name}</p><div className="flex items-center gap-1 mt-0.5"><Star size={10} className="text-amber-500 fill-amber-500"/><span className="text-xs text-slate-500">{d.rating}</span></div></div>
                    <span className="text-sm font-bold font-mono text-slate-800">{(drawer.price*0.95/1000).toFixed(0)}K</span>
                    {i===0 && <span className="text-[10px] bg-green-100 text-green-700 px-1.5 py-0.5 rounded font-medium">Selected</span>}
                  </div>
                ))}
              </div>
            )}
            {drawerTab==="history" && (
              <div className="space-y-2">
                {[{status:"published",time:"Jun 25, 09:00"},{status:"bidding",time:"Jun 25, 09:10"},{status:"accepted",time:"Jun 25, 09:20"}].map((h,i)=>(
                  <div key={i} className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0"/>
                    <div className="flex-1"><p className="text-xs font-medium text-slate-700 capitalize">{h.status.replace("_"," ")}</p></div>
                    <span className="text-[11px] text-slate-400">{h.time}</span>
                  </div>
                ))}
              </div>
            )}
            {/* Actions */}
            <div className="flex flex-col gap-2 pt-2 border-t border-slate-100">
              <button onClick={()=>setModal("assign")} className="w-full flex items-center justify-center gap-2 bg-[#1B4FD8] text-white rounded-lg py-2.5 text-sm font-medium"><UserCheck size={14}/>Assign Driver</button>
              <div className="flex gap-2">
                <button onClick={()=>setModal("status")} className="flex-1 border border-slate-200 text-slate-600 rounded-lg py-2 text-xs font-medium hover:bg-slate-50">Change Status</button>
                <button onClick={()=>setModal("cancel")} className="flex-1 border border-red-200 text-red-600 rounded-lg py-2 text-xs font-medium hover:bg-red-50">Cancel Order</button>
              </div>
            </div>
          </div>
        </AdminDrawer>
      )}

      {/* Summary cards */}
      <div className="grid grid-cols-4 gap-4">
        <AdminMetricCard title="Total Orders"    value={adminOrders.length.toString()}  icon={Package}    color="bg-slate-100 text-slate-600"/>
        <AdminMetricCard title="Active Deliveries" value="2"                            icon={Navigation} color="bg-indigo-50 text-indigo-600"/>
        <AdminMetricCard title="Awaiting Bids"   value="2"                              icon={CircleDot}  color="bg-amber-50 text-amber-600"/>
        <AdminMetricCard title="Disputed"        value={adminDisputes.length.toString()} icon={Flag}      color="bg-rose-50 text-rose-600"/>
      </div>

      {/* Status tabs */}
      <div className="flex gap-1 bg-slate-100 p-1 rounded-lg overflow-x-auto">
        {tabs.map(t=><button key={t} onClick={()=>setTab(t)} className={`px-3 py-1.5 rounded-md text-xs font-medium capitalize whitespace-nowrap transition-colors ${tab===t?"bg-white text-slate-800 shadow-sm":"text-slate-500 hover:text-slate-700"}`}>{t.replace("_"," ")}</button>)}
      </div>

      {/* Filters */}
      <div className="flex gap-3"><AdminSearchBar placeholder="Search order, client, driver..." value={search} onChange={setSearch}/></div>

      {/* Table */}
      <AdminTableWrapper>
        <thead><tr><AdminTh>Order</AdminTh><AdminTh>Status</AdminTh><AdminTh>Route</AdminTh><AdminTh>Client</AdminTh><AdminTh>Driver</AdminTh><AdminTh>Price</AdminTh><AdminTh>Payment</AdminTh><AdminTh>Date</AdminTh><AdminTh>Actions</AdminTh></tr></thead>
        <tbody>
          {filtered.map(o=>(
            <tr key={o.id} className="hover:bg-slate-50 cursor-pointer" onClick={()=>setDrawer(o)}>
              <AdminTd><span className="font-mono text-xs font-semibold text-blue-600">{o.code}</span></AdminTd>
              <AdminTd><AdminStatusBadge status={o.status}/></AdminTd>
              <AdminTd><span className="font-medium">{o.from}</span><span className="text-slate-400 mx-1">→</span>{o.to}</AdminTd>
              <AdminTd>{o.client}</AdminTd>
              <AdminTd><span className={o.driver==="—"?"text-slate-400":""} >{o.driver}</span></AdminTd>
              <AdminTd><span className="font-mono text-xs font-semibold">{(o.price/1000).toFixed(0)}K</span></AdminTd>
              <AdminTd><AdminStatusBadge status={o.payment}/></AdminTd>
              <AdminTd><span className="text-slate-400 text-xs">{o.date}</span></AdminTd>
              <AdminTd onClick={e=>e.stopPropagation()}>
                <div className="flex gap-1">
                  <AdminActionBtn label="View" icon={Eye} onClick={()=>setDrawer(o)}/>
                </div>
              </AdminTd>
            </tr>
          ))}
        </tbody>
      </AdminTableWrapper>
    </div>
  );
}

// ── Admin Drivers ─────────────────────────────────────────────────────────────

function AdminDrivers() {
  const [tab,setTab] = useState("all");
  const [search,setSearch] = useState("");
  const [drawer,setDrawer] = useState<typeof adminDrivers[number]|null>(null);
  const [modal,setModal] = useState<"approve"|"reject"|"block"|null>(null);

  const tabs = ["all","new","pending","approved","rejected","blocked"];
  const filtered = adminDrivers.filter(d=>(tab==="all"||(tab==="new"?d.orders===0&&d.status==="approved":d.status===tab))&&(search===""||d.name.toLowerCase().includes(search.toLowerCase())||d.phone.includes(search)));

  const counts = { total:adminDrivers.length, pending:adminDrivers.filter(d=>d.status==="pending").length, approved:adminDrivers.filter(d=>d.status==="approved").length, rejected:adminDrivers.filter(d=>d.status==="rejected").length, blocked:adminDrivers.filter(d=>d.status==="blocked").length, available:adminDrivers.filter(d=>d.status==="approved"&&d.avail).length };

  return (
    <div className="p-6 space-y-5">
      {drawer && (
        <AdminDrawer title={drawer.name} onClose={()=>setDrawer(null)}>
          {modal==="approve" && (
            <AdminModal title="Approve Driver" onClose={()=>setModal(null)} onSubmit={()=>{}} submitLabel="Approve" submitVariant="primary">
              <p className="text-sm text-slate-600">Approve <strong>{drawer.name}</strong> to start working on the platform?</p>
              <div><label className="text-xs font-medium text-slate-600 block mb-1.5">Comment (optional)</label><textarea rows={2} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none resize-none" placeholder="Optional note..."/></div>
            </AdminModal>
          )}
          {(modal==="reject"||modal==="block") && (
            <AdminModal title={modal==="reject"?"Reject Driver":"Block Driver"} onClose={()=>setModal(null)} onSubmit={()=>{}} submitLabel={modal==="reject"?"Reject":"Block"} submitVariant="danger">
              <p className="text-sm text-slate-600">{modal==="reject"?"Reject":"Block"} <strong>{drawer.name}</strong>? This will prevent them from working.</p>
              <div><label className="text-xs font-medium text-slate-600 block mb-1.5">Reason *</label><div className="flex flex-col gap-2">{["Incomplete documents","Falsified documents","Policy violation","Other"].map(r=><label key={r} className="flex items-center gap-2 text-sm"><input type="radio" name="reason" className="text-blue-600"/>{r}</label>)}</div></div>
            </AdminModal>
          )}
          <div className="p-5 space-y-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl bg-blue-50 flex items-center justify-center"><Truck size={24} className="text-blue-600"/></div>
              <div>
                <p className="text-base font-bold text-slate-800">{drawer.name}</p>
                <p className="text-sm text-slate-500 font-mono">{drawer.phone}</p>
                <div className="flex gap-2 mt-1"><AdminStatusBadge status={drawer.status}/>{drawer.avail&&<AdminStatusBadge status="active"/>}</div>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3 py-3 border-y border-slate-100">
              {[{label:"Rating",value:drawer.rating||"—"},{label:"Completed",value:drawer.orders},{label:"Routes",value:drawer.routes}].map(({label,value})=>(
                <div key={label} className="text-center"><p className="text-lg font-bold font-mono text-slate-800">{value}</p><p className="text-[10px] text-slate-400 uppercase">{label}</p></div>
              ))}
            </div>
            <div className="space-y-2">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Vehicle</p>
              {[{l:"Model",v:drawer.car},{l:"Plate",v:drawer.plate}].map(({l,v})=><div key={l} className="flex justify-between py-1.5 border-b border-slate-100"><span className="text-xs text-slate-500">{l}</span><span className="text-sm font-mono font-medium text-slate-700">{v}</span></div>)}
            </div>
            <div className="space-y-2">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Documents ({drawer.docs}/5)</p>
              <div className="w-full bg-slate-100 rounded-full h-2"><div className="bg-blue-500 h-2 rounded-full transition-all" style={{width:`${(drawer.docs/5)*100}%`}}/></div>
              {["Passport","Selfie","Driver License","Car Document","Car Photo"].map((doc,i)=>(
                <div key={doc} className="flex items-center justify-between py-1.5 border-b border-slate-100">
                  <span className="text-xs text-slate-600">{doc}</span>
                  {i<drawer.docs?<span className="text-[10px] bg-green-100 text-green-700 px-1.5 py-0.5 rounded font-medium">Uploaded</span>:<span className="text-[10px] bg-red-100 text-red-600 px-1.5 py-0.5 rounded font-medium">Missing</span>}
                </div>
              ))}
            </div>
            <div className="flex gap-2 pt-2">
              {drawer.status==="pending" && <>
                <button onClick={()=>setModal("approve")} className="flex-1 bg-green-600 text-white rounded-lg py-2 text-sm font-medium hover:bg-green-700"><UserCheck size={13} className="inline mr-1"/>Approve</button>
                <button onClick={()=>setModal("reject")}  className="flex-1 border border-orange-200 text-orange-700 rounded-lg py-2 text-sm font-medium hover:bg-orange-50"><UserX size={13} className="inline mr-1"/>Reject</button>
              </>}
              {drawer.status==="approved" && <button onClick={()=>setModal("block")} className="flex-1 border border-red-200 text-red-700 rounded-lg py-2 text-sm font-medium hover:bg-red-50"><Ban size={13} className="inline mr-1"/>Block</button>}
            </div>
          </div>
        </AdminDrawer>
      )}

      <div className="grid grid-cols-4 gap-4">
        <AdminMetricCard title="Total Drivers"  value={counts.total.toString()}    icon={Truck}     color="bg-slate-100 text-slate-600"/>
        <AdminMetricCard title="Pending Review" value={counts.pending.toString()}  icon={Clock}     color="bg-amber-50 text-amber-600"/>
        <AdminMetricCard title="Approved"       value={counts.approved.toString()} icon={UserCheck} color="bg-green-50 text-green-600"/>
        <AdminMetricCard title="Available Now"  value={counts.available.toString()} icon={Navigation}color="bg-blue-50 text-blue-600"/>
      </div>

      <div className="flex gap-1 bg-slate-100 p-1 rounded-lg">
        {tabs.map(t=><button key={t} onClick={()=>setTab(t)} className={`px-3 py-1.5 rounded-md text-xs font-medium capitalize transition-colors ${tab===t?"bg-white text-slate-800 shadow-sm":"text-slate-500"}`}>{t}</button>)}
      </div>

      <AdminSearchBar placeholder="Search name, phone, plate..." value={search} onChange={setSearch}/>

      <AdminTableWrapper>
        <thead><tr><AdminTh>Driver</AdminTh><AdminTh>Phone</AdminTh><AdminTh>Vehicle</AdminTh><AdminTh>Status</AdminTh><AdminTh>Available</AdminTh><AdminTh>Docs</AdminTh><AdminTh>Routes</AdminTh><AdminTh>Orders</AdminTh><AdminTh>Joined</AdminTh><AdminTh>Actions</AdminTh></tr></thead>
        <tbody>
          {filtered.map(d=>(
            <tr key={d.id} className="hover:bg-slate-50">
              <AdminTd><span className="font-medium text-slate-800">{d.name}</span></AdminTd>
              <AdminTd><span className="font-mono text-xs">{d.phone}</span></AdminTd>
              <AdminTd><span className="text-xs">{d.car} · <span className="font-mono">{d.plate}</span></span></AdminTd>
              <AdminTd><AdminStatusBadge status={d.status}/></AdminTd>
              <AdminTd>{d.avail?<span className="text-green-600 text-xs font-medium">Online</span>:<span className="text-slate-400 text-xs">Offline</span>}</AdminTd>
              <AdminTd><span className={`font-mono text-xs font-semibold ${d.docs<5?"text-amber-600":"text-green-600"}`}>{d.docs}/5</span></AdminTd>
              <AdminTd><span className="font-mono text-xs">{d.routes}</span></AdminTd>
              <AdminTd><span className="font-mono text-xs">{d.orders}</span></AdminTd>
              <AdminTd><span className="text-slate-400 text-xs">{d.created}</span></AdminTd>
              <AdminTd>
                <div className="flex gap-1">
                  <AdminActionBtn label="View"   icon={Eye}    onClick={()=>setDrawer(d)}/>
                  {d.status==="pending"  && <AdminActionBtn label="Approve" variant="approve" onClick={()=>{setDrawer(d);setModal("approve");}}/>}
                  {d.status==="pending"  && <AdminActionBtn label="Reject"  variant="reject"  onClick={()=>{setDrawer(d);setModal("reject");}}/>}
                  {d.status==="approved" && <AdminActionBtn label="Block"   variant="block"   onClick={()=>{setDrawer(d);setModal("block");}}/>}
                </div>
              </AdminTd>
            </tr>
          ))}
        </tbody>
      </AdminTableWrapper>
    </div>
  );
}

// ── Admin Clients ─────────────────────────────────────────────────────────────

function AdminClients() {
  const [search,setSearch] = useState("");
  const [drawer,setDrawer] = useState<typeof adminClients[number]|null>(null);
  const filtered = adminClients.filter(c=>search===""||c.name.toLowerCase().includes(search.toLowerCase())||c.phone.includes(search));
  return (
    <div className="p-6 space-y-5">
      {drawer && (
        <AdminDrawer title={drawer.name} onClose={()=>setDrawer(null)}>
          <div className="p-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center"><User size={22} className="text-slate-500"/></div>
              <div><p className="text-base font-bold text-slate-800">{drawer.name}</p><p className="text-sm text-slate-500 font-mono">{drawer.phone}</p><div className="flex gap-2 mt-1"><AdminStatusBadge status={drawer.status}/>{drawer.verified&&<span className="text-[10px] bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded font-medium border border-blue-200">Verified</span>}</div></div>
            </div>
            <div className="grid grid-cols-3 gap-3 py-3 border-y border-slate-100">
              {[{l:"Total Orders",v:drawer.orders},{l:"Active",v:drawer.active},{l:"Completed",v:drawer.orders-drawer.active}].map(({l,v})=><div key={l} className="text-center"><p className="text-lg font-bold font-mono text-slate-800">{v}</p><p className="text-[10px] text-slate-400 uppercase">{l}</p></div>)}
            </div>
            {[{l:"Last Order",v:drawer.last},{l:"Joined",v:drawer.created}].map(({l,v})=><div key={l} className="flex justify-between py-2 border-b border-slate-100"><span className="text-xs text-slate-500">{l}</span><span className="text-sm text-slate-700">{v}</span></div>)}
            <div className="flex gap-2 pt-2">
              {drawer.status==="active"  && <button className="flex-1 border border-red-200 text-red-700 rounded-lg py-2 text-sm font-medium hover:bg-red-50"><Ban size={13} className="inline mr-1"/>Block Client</button>}
              {drawer.status==="blocked" && <button className="flex-1 border border-green-200 text-green-700 rounded-lg py-2 text-sm font-medium hover:bg-green-50"><CheckCircle2 size={13} className="inline mr-1"/>Unblock</button>}
            </div>
          </div>
        </AdminDrawer>
      )}
      <div className="grid grid-cols-4 gap-4">
        <AdminMetricCard title="Total Clients"  value={adminClients.length.toString()}                     icon={Users}        color="bg-slate-100 text-slate-600"/>
        <AdminMetricCard title="Active"         value={adminClients.filter(c=>c.status==="active").length.toString()} icon={CheckCircle2} color="bg-green-50 text-green-600"/>
        <AdminMetricCard title="Blocked"        value={adminClients.filter(c=>c.status==="blocked").length.toString()}icon={Ban}         color="bg-red-50 text-red-600"/>
        <AdminMetricCard title="With Orders"    value={adminClients.filter(c=>c.orders>0).length.toString()}           icon={Package}     color="bg-blue-50 text-blue-600"/>
      </div>
      <AdminSearchBar placeholder="Search by name or phone..." value={search} onChange={setSearch}/>
      <AdminTableWrapper>
        <thead><tr><AdminTh>Client</AdminTh><AdminTh>Phone</AdminTh><AdminTh>Status</AdminTh><AdminTh>Verified</AdminTh><AdminTh>Orders</AdminTh><AdminTh>Active</AdminTh><AdminTh>Last Order</AdminTh><AdminTh>Joined</AdminTh><AdminTh>Actions</AdminTh></tr></thead>
        <tbody>
          {filtered.map(c=>(
            <tr key={c.id} className="hover:bg-slate-50">
              <AdminTd><span className="font-medium">{c.name}</span></AdminTd>
              <AdminTd><span className="font-mono text-xs">{c.phone}</span></AdminTd>
              <AdminTd><AdminStatusBadge status={c.status}/></AdminTd>
              <AdminTd>{c.verified?<CheckCircle2 size={14} className="text-green-500"/>:<X size={14} className="text-slate-400"/>}</AdminTd>
              <AdminTd><span className="font-mono text-xs">{c.orders}</span></AdminTd>
              <AdminTd><span className="font-mono text-xs">{c.active}</span></AdminTd>
              <AdminTd><span className="text-slate-400 text-xs">{c.last}</span></AdminTd>
              <AdminTd><span className="text-slate-400 text-xs">{c.created}</span></AdminTd>
              <AdminTd>
                <div className="flex gap-1">
                  <AdminActionBtn label="View" icon={Eye} onClick={()=>setDrawer(c)}/>
                  {c.status==="active"  && <AdminActionBtn label="Block"   variant="block" onClick={()=>{}}/>}
                  {c.status==="blocked" && <AdminActionBtn label="Unblock" variant="approve" onClick={()=>{}}/>}
                </div>
              </AdminTd>
            </tr>
          ))}
        </tbody>
      </AdminTableWrapper>
    </div>
  );
}

// ── Admin Regions ─────────────────────────────────────────────────────────────

function AdminRegions() {
  const [search,setSearch] = useState("");
  const filtered = adminRegions.filter(r=>search===""||r.uz.toLowerCase().includes(search.toLowerCase())||r.ru.toLowerCase().includes(search.toLowerCase()));
  return (
    <div className="p-6 space-y-5">
      <div className="grid grid-cols-4 gap-4">
        <AdminMetricCard title="Total Regions"   value={adminRegions.length.toString()} icon={MapPin} color="bg-slate-100 text-slate-600"/>
        <AdminMetricCard title="Active"          value={adminRegions.filter(r=>r.active).length.toString()} icon={CheckCircle2} color="bg-green-50 text-green-600"/>
        <AdminMetricCard title="With Districts"  value={adminRegions.filter(r=>r.dist).length.toString()} icon={LayoutDashboard} color="bg-blue-50 text-blue-600"/>
        <AdminMetricCard title="Inactive"        value={adminRegions.filter(r=>!r.active).length.toString()} icon={Ban} color="bg-slate-100 text-slate-500"/>
      </div>
      <div className="flex gap-3 items-center justify-between">
        <AdminSearchBar placeholder="Search by name..." value={search} onChange={setSearch}/>
        <button className="flex items-center gap-2 bg-[#1B4FD8] text-white px-3 py-2 rounded-lg text-sm font-medium"><Plus size={14}/>Add Region</button>
      </div>
      <AdminTableWrapper>
        <thead><tr><AdminTh>ID</AdminTh><AdminTh>Uzbek</AdminTh><AdminTh>Russian</AdminTh><AdminTh>Type</AdminTh><AdminTh>Districts</AdminTh><AdminTh>Req. District</AdminTh><AdminTh>Active</AdminTh><AdminTh>Actions</AdminTh></tr></thead>
        <tbody>
          {filtered.map(r=>(
            <tr key={r.id} className="hover:bg-slate-50">
              <AdminTd><span className="font-mono text-xs text-slate-400">{r.id}</span></AdminTd>
              <AdminTd><span className="font-medium">{r.uz}</span></AdminTd>
              <AdminTd>{r.ru}</AdminTd>
              <AdminTd><AdminStatusBadge status={r.type}/></AdminTd>
              <AdminTd><span className="font-mono text-xs">{r.districts}</span></AdminTd>
              <AdminTd>{r.dist?<CheckCircle2 size={14} className="text-green-500"/>:<X size={14} className="text-slate-300"/>}</AdminTd>
              <AdminTd>{r.active?<CheckCircle2 size={14} className="text-green-500"/>:<X size={14} className="text-red-400"/>}</AdminTd>
              <AdminTd>
                <div className="flex gap-1">
                  <AdminActionBtn label="Edit" icon={Pencil}/>
                  <AdminActionBtn label={r.active?"Deactivate":"Activate"} variant={r.active?"reject":"approve"}/>
                </div>
              </AdminTd>
            </tr>
          ))}
        </tbody>
      </AdminTableWrapper>
    </div>
  );
}

// ── Admin Tariffs ─────────────────────────────────────────────────────────────

function AdminTariffs() {
  const [search,setSearch] = useState("");
  const [modal,setModal] = useState(false);
  const filtered = adminTariffs.filter(t=>search===""||t.from.toLowerCase().includes(search.toLowerCase())||t.to.toLowerCase().includes(search.toLowerCase()));
  return (
    <div className="p-6 space-y-5">
      {modal && (
        <AdminModal title="Add Tariff" onClose={()=>setModal(false)} onSubmit={()=>setModal(false)} submitLabel="Save Tariff">
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs font-medium text-slate-600 block mb-1">From City</label><select className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none"><option>Tashkent</option>{adminRegions.map(r=><option key={r.id}>{r.uz}</option>)}</select></div>
            <div><label className="text-xs font-medium text-slate-600 block mb-1">To City</label><select className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none"><option>Samarkand</option>{adminRegions.map(r=><option key={r.id}>{r.uz}</option>)}</select></div>
          </div>
          {[{l:"Suggested Price",ph:"150000"},{l:"Min Price",ph:"120000"},{l:"Max Price",ph:"200000"}].map(({l,ph})=>(
            <div key={l}><label className="text-xs font-medium text-slate-600 block mb-1">{l}</label><input className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none" placeholder={ph}/></div>
          ))}
          <label className="flex items-center gap-2 text-sm text-slate-700"><input type="checkbox" defaultChecked className="rounded"/> Active</label>
        </AdminModal>
      )}
      <div className="grid grid-cols-4 gap-4">
        <AdminMetricCard title="Total Tariffs" value={adminTariffs.length.toString()}                      icon={Tag} color="bg-slate-100 text-slate-600"/>
        <AdminMetricCard title="Active"        value={adminTariffs.filter(t=>t.active).length.toString()}  icon={CheckCircle2} color="bg-green-50 text-green-600"/>
        <AdminMetricCard title="Inactive"      value={adminTariffs.filter(t=>!t.active).length.toString()} icon={Ban} color="bg-slate-100 text-slate-500"/>
        <AdminMetricCard title="Avg Price"     value={(adminTariffs.reduce((a,t)=>a+t.suggested,0)/adminTariffs.length/1000).toFixed(0)+"K so'm"} icon={DollarSign} color="bg-amber-50 text-amber-600"/>
      </div>
      <div className="flex gap-3 items-center justify-between">
        <AdminSearchBar placeholder="Search route, city..." value={search} onChange={setSearch}/>
        <button onClick={()=>setModal(true)} className="flex items-center gap-2 bg-[#1B4FD8] text-white px-3 py-2 rounded-lg text-sm font-medium"><Plus size={14}/>Add Tariff</button>
      </div>
      <AdminTableWrapper>
        <thead><tr><AdminTh>ID</AdminTh><AdminTh>Route</AdminTh><AdminTh>Suggested</AdminTh><AdminTh>Min</AdminTh><AdminTh>Max</AdminTh><AdminTh>Currency</AdminTh><AdminTh>Active</AdminTh><AdminTh>Created</AdminTh><AdminTh>Actions</AdminTh></tr></thead>
        <tbody>
          {filtered.map(t=>(
            <tr key={t.id} className="hover:bg-slate-50">
              <AdminTd><span className="font-mono text-xs text-slate-400">{t.id}</span></AdminTd>
              <AdminTd><span className="font-medium">{t.from}</span><span className="text-slate-400 mx-1">→</span>{t.to}</AdminTd>
              <AdminTd><span className="font-mono text-sm font-semibold text-slate-800">{(t.suggested/1000).toFixed(0)}K</span></AdminTd>
              <AdminTd><span className="font-mono text-xs">{(t.min/1000).toFixed(0)}K</span></AdminTd>
              <AdminTd><span className="font-mono text-xs">{(t.max/1000).toFixed(0)}K</span></AdminTd>
              <AdminTd><span className="font-mono text-xs">{t.currency}</span></AdminTd>
              <AdminTd>{t.active?<CheckCircle2 size={14} className="text-green-500"/>:<X size={14} className="text-red-400"/>}</AdminTd>
              <AdminTd><span className="text-slate-400 text-xs">{t.created}</span></AdminTd>
              <AdminTd>
                <div className="flex gap-1">
                  <AdminActionBtn label="Edit" icon={Pencil}/>
                  <AdminActionBtn label={t.active?"Deactivate":"Activate"} variant={t.active?"reject":"approve"}/>
                </div>
              </AdminTd>
            </tr>
          ))}
        </tbody>
      </AdminTableWrapper>
    </div>
  );
}

// ── Admin Disputes ────────────────────────────────────────────────────────────

function AdminDisputesSection() {
  const [drawer,setDrawer] = useState<typeof adminDisputes[number]|null>(null);
  return (
    <div className="p-6 space-y-5">
      {drawer && (
        <AdminDrawer title={`Dispute — ${drawer.orderId}`} onClose={()=>setDrawer(null)}>
          <div className="p-5 space-y-4">
            <AdminStatusBadge status={drawer.status}/>
            <div className="space-y-2">
              {[{l:"Order",v:drawer.orderId},{l:"Reason",v:drawer.reason},{l:"Opened By",v:drawer.openedBy},{l:"Created",v:drawer.created},{l:"Resolution",v:drawer.resolution||"—"}].map(({l,v})=>(
                <div key={l} className="flex justify-between py-2 border-b border-slate-100"><span className="text-xs text-slate-500">{l}</span><span className="text-sm font-medium text-slate-700">{v}</span></div>
              ))}
            </div>
            {(drawer.status==="open"||drawer.status==="in_review") && (
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-600 block">Update Status</label>
                <select className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none"><option>in_review</option><option>resolved</option><option>rejected</option></select>
                <textarea rows={3} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none resize-none" placeholder="Resolution note..."/>
                <button className="w-full bg-[#1B4FD8] text-white rounded-lg py-2 text-sm font-medium">Update Dispute</button>
              </div>
            )}
          </div>
        </AdminDrawer>
      )}
      <div className="grid grid-cols-3 gap-4">
        <AdminMetricCard title="Total Disputes" value={adminDisputes.length.toString()} icon={Flag} color="bg-slate-100 text-slate-600"/>
        <AdminMetricCard title="Open"           value={adminDisputes.filter(d=>d.status==="open").length.toString()} icon={AlertCircle} color="bg-rose-50 text-rose-600"/>
        <AdminMetricCard title="Resolved"       value={adminDisputes.filter(d=>d.status==="resolved").length.toString()} icon={CheckCircle2} color="bg-green-50 text-green-600"/>
      </div>
      <AdminTableWrapper>
        <thead><tr><AdminTh>ID</AdminTh><AdminTh>Order</AdminTh><AdminTh>Reason</AdminTh><AdminTh>Status</AdminTh><AdminTh>Opened By</AdminTh><AdminTh>Created</AdminTh><AdminTh>Actions</AdminTh></tr></thead>
        <tbody>
          {adminDisputes.map(d=>(
            <tr key={d.id} className="hover:bg-slate-50">
              <AdminTd><span className="font-mono text-xs text-slate-400">{d.id}</span></AdminTd>
              <AdminTd><span className="font-mono text-xs font-semibold text-blue-600">{d.orderId}</span></AdminTd>
              <AdminTd>{d.reason}</AdminTd>
              <AdminTd><AdminStatusBadge status={d.status}/></AdminTd>
              <AdminTd>{d.openedBy}</AdminTd>
              <AdminTd><span className="text-slate-400 text-xs">{d.created}</span></AdminTd>
              <AdminTd><AdminActionBtn label="Review" icon={Eye} onClick={()=>setDrawer(d)}/></AdminTd>
            </tr>
          ))}
        </tbody>
      </AdminTableWrapper>
    </div>
  );
}

// ── Admin Staff ───────────────────────────────────────────────────────────────

function AdminStaffSection() {
  const [modal,setModal] = useState(false);
  return (
    <div className="p-6 space-y-5">
      {modal && (
        <AdminModal title="Create Staff User" onClose={()=>setModal(false)} onSubmit={()=>setModal(false)} submitLabel="Create User">
          {[{l:"Phone",ph:"+998XXXXXXXXX"},{l:"Full Name",ph:"Full name"}].map(({l,ph})=>(
            <div key={l}><label className="text-xs font-medium text-slate-600 block mb-1">{l}</label><input className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none" placeholder={ph}/></div>
          ))}
          <div><label className="text-xs font-medium text-slate-600 block mb-1">Role</label><select className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none"><option value="operator">Operator</option><option value="admin">Admin</option></select></div>
        </AdminModal>
      )}
      <div className="grid grid-cols-4 gap-4">
        <AdminMetricCard title="Total Staff"   value={adminStaff.length.toString()} icon={Users} color="bg-slate-100 text-slate-600"/>
        <AdminMetricCard title="Admins"        value={adminStaff.filter(s=>s.role==="admin"||s.role==="super_admin").length.toString()} icon={ShieldCheck} color="bg-purple-50 text-purple-600"/>
        <AdminMetricCard title="Operators"     value={adminStaff.filter(s=>s.role==="operator").length.toString()} icon={User} color="bg-blue-50 text-blue-600"/>
        <AdminMetricCard title="Active"        value={adminStaff.filter(s=>s.status==="active").length.toString()} icon={CheckCircle2} color="bg-green-50 text-green-600"/>
      </div>
      <div className="flex justify-end">
        <button onClick={()=>setModal(true)} className="flex items-center gap-2 bg-[#1B4FD8] text-white px-3 py-2 rounded-lg text-sm font-medium"><Plus size={14}/>Create Staff User</button>
      </div>
      <AdminTableWrapper>
        <thead><tr><AdminTh>Name</AdminTh><AdminTh>Phone</AdminTh><AdminTh>Role</AdminTh><AdminTh>Status</AdminTh><AdminTh>Verified</AdminTh><AdminTh>Created</AdminTh><AdminTh>Last Login</AdminTh><AdminTh>Actions</AdminTh></tr></thead>
        <tbody>
          {adminStaff.map(s=>(
            <tr key={s.id} className="hover:bg-slate-50">
              <AdminTd><span className="font-medium">{s.name}</span></AdminTd>
              <AdminTd><span className="font-mono text-xs">{s.phone}</span></AdminTd>
              <AdminTd><AdminStatusBadge status={s.role}/></AdminTd>
              <AdminTd><AdminStatusBadge status={s.status}/></AdminTd>
              <AdminTd>{s.verified?<CheckCircle2 size={14} className="text-green-500"/>:<X size={14} className="text-slate-400"/>}</AdminTd>
              <AdminTd><span className="text-slate-400 text-xs">{s.created}</span></AdminTd>
              <AdminTd><span className="text-slate-400 text-xs">{s.lastLogin}</span></AdminTd>
              <AdminTd>
                <div className="flex gap-1">
                  {s.role!=="super_admin" && <AdminActionBtn label="Edit" icon={Pencil}/>}
                  {s.status==="active" && s.role!=="super_admin" && <AdminActionBtn label="Block" variant="block"/>}
                  {s.status==="blocked" && <AdminActionBtn label="Unblock" variant="approve"/>}
                </div>
              </AdminTd>
            </tr>
          ))}
        </tbody>
      </AdminTableWrapper>
    </div>
  );
}

// ── Admin Notifications ───────────────────────────────────────────────────────

function AdminNotificationsSection() {
  return (
    <div className="p-6 space-y-5">
      <div className="grid grid-cols-3 gap-4">
        <AdminMetricCard title="Total" value={adminAdminNotifs.length.toString()} icon={Bell} color="bg-slate-100 text-slate-600"/>
        <AdminMetricCard title="Unread" value={adminAdminNotifs.filter(n=>!n.read).length.toString()} icon={AlertCircle} color="bg-amber-50 text-amber-600"/>
        <AdminMetricCard title="System" value={adminAdminNotifs.filter(n=>n.type==="system").length.toString()} icon={Zap} color="bg-blue-50 text-blue-600"/>
      </div>
      <AdminTableWrapper>
        <thead><tr><AdminTh>Recipient</AdminTh><AdminTh>Type</AdminTh><AdminTh>Title</AdminTh><AdminTh>Message</AdminTh><AdminTh>Channel</AdminTh><AdminTh>Read</AdminTh><AdminTh>Date</AdminTh></tr></thead>
        <tbody>
          {adminAdminNotifs.map(n=>(
            <tr key={n.id} className={`hover:bg-slate-50 ${!n.read?"bg-blue-50/30":""}`}>
              <AdminTd><span className="font-medium text-xs">{n.recipient}</span></AdminTd>
              <AdminTd><AdminStatusBadge status={n.type}/></AdminTd>
              <AdminTd><span className="font-medium text-xs">{n.title}</span></AdminTd>
              <AdminTd><span className="text-slate-500 text-xs max-w-[200px] block truncate">{n.message}</span></AdminTd>
              <AdminTd><AdminStatusBadge status={n.channel}/></AdminTd>
              <AdminTd>{n.read?<CheckCircle2 size={14} className="text-green-500"/>:<div className="w-2 h-2 rounded-full bg-blue-500"/>}</AdminTd>
              <AdminTd><span className="text-slate-400 text-xs">{n.date}</span></AdminTd>
            </tr>
          ))}
        </tbody>
      </AdminTableWrapper>
    </div>
  );
}

// ── Admin Audit Log ───────────────────────────────────────────────────────────

function AdminAuditLogSection() {
  const [search,setSearch] = useState("");
  const filtered = adminAuditLog.filter(l=>search===""||l.actor.toLowerCase().includes(search.toLowerCase())||l.action.includes(search));
  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center gap-3 justify-between">
        <AdminSearchBar placeholder="Search actor or action..." value={search} onChange={setSearch}/>
        <div className="flex items-center gap-2 text-xs text-slate-500 bg-amber-50 border border-amber-200 px-3 py-2 rounded-lg"><AlertCircle size={12} className="text-amber-500"/> Read-only audit trail</div>
      </div>
      <AdminTableWrapper>
        <thead><tr><AdminTh>ID</AdminTh><AdminTh>Actor</AdminTh><AdminTh>Role</AdminTh><AdminTh>Action</AdminTh><AdminTh>Entity</AdminTh><AdminTh>Entity ID</AdminTh><AdminTh>Time</AdminTh></tr></thead>
        <tbody>
          {filtered.map(l=>(
            <tr key={l.id} className="hover:bg-slate-50">
              <AdminTd><span className="font-mono text-xs text-slate-400">{l.id}</span></AdminTd>
              <AdminTd><span className="font-medium">{l.actor}</span></AdminTd>
              <AdminTd><AdminStatusBadge status={l.role}/></AdminTd>
              <AdminTd><span className="font-mono text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded">{l.action}</span></AdminTd>
              <AdminTd><span className="text-slate-600">{l.entity}</span></AdminTd>
              <AdminTd><span className="font-mono text-xs text-slate-400">#{l.entityId}</span></AdminTd>
              <AdminTd><span className="text-slate-400 text-xs">{l.created}</span></AdminTd>
            </tr>
          ))}
        </tbody>
      </AdminTableWrapper>
    </div>
  );
}

// ── Admin Profile ─────────────────────────────────────────────────────────────

function AdminProfileSection({ onLogout }: { onLogout:()=>void }) {
  const [name,setName] = useState("Alisher Qodirov");
  const [commission,setCommission] = useState("10");
  const [saved,setSaved] = useState(false);
  const [commSaved,setCommSaved] = useState(false);

  function saveProfile(){ setSaved(true); setTimeout(()=>setSaved(false),2000); }
  function saveComm(){ setCommSaved(true); setTimeout(()=>setCommSaved(false),2000); }

  return (
    <div className="p-6 max-w-2xl space-y-6">
      {/* Profile card */}
      <div className="bg-white border border-slate-200 rounded-lg p-6">
        <div className="flex items-center gap-4 mb-6 pb-6 border-b border-slate-100">
          <div className="w-16 h-16 rounded-xl bg-[#1B4FD8]/10 flex items-center justify-center"><ShieldCheck size={28} className="text-[#1B4FD8]"/></div>
          <div>
            <p className="text-lg font-bold text-slate-800">{name}</p>
            <p className="text-sm text-slate-500 font-mono">+998 90 123 00 01</p>
            <div className="flex gap-2 mt-1"><AdminStatusBadge status="super_admin"/><AdminStatusBadge status="active"/></div>
          </div>
        </div>
        <div className="space-y-4">
          <div>
            <label className="text-xs font-semibold uppercase tracking-wide text-slate-500 block mb-2">Full Name</label>
            <div className="flex gap-3">
              <input className="flex-1 border border-slate-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-blue-400" value={name} onChange={e=>setName(e.target.value)}/>
              <button onClick={saveProfile} className={`px-4 rounded-lg text-sm font-medium transition-colors ${saved?"bg-green-50 text-green-700 border border-green-200":"bg-[#1B4FD8] text-white hover:bg-blue-700"}`}>
                {saved?<><CheckCircle2 size={14} className="inline mr-1"/>Saved</>:"Save"}
              </button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[{l:"Role",v:"Super Admin"},{l:"Phone Verified",v:"Yes"},{l:"Last Login",v:"Jun 25, 09:00"},{l:"Account Created",v:"Dec 1, 2024"}].map(({l,v})=>(
              <div key={l}><p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400 mb-1">{l}</p><p className="text-sm font-medium text-slate-700">{v}</p></div>
            ))}
          </div>
        </div>
        <div className="flex gap-3 mt-6 pt-6 border-t border-slate-100">
          <button onClick={onLogout} className="flex items-center gap-2 text-red-600 border border-red-200 px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-50"><LogOut size={14}/>Log Out</button>
          <button className="flex items-center gap-2 text-slate-600 border border-slate-200 px-4 py-2 rounded-lg text-sm font-medium hover:bg-slate-50"><RefreshCw size={14}/>Refresh Profile</button>
        </div>
      </div>

      {/* Commission card */}
      <div className="bg-white border border-slate-200 rounded-lg p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center"><DollarSign size={18} className="text-emerald-600"/></div>
          <div><p className="text-base font-semibold text-slate-800">Platform Commission</p><p className="text-xs text-slate-500">Driver earnings deduction rate</p></div>
        </div>
        <div className="flex gap-3 items-end">
          <div className="flex-1">
            <label className="text-xs font-semibold uppercase tracking-wide text-slate-500 block mb-2">Commission %</label>
            <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden">
              <input type="number" min="0" max="50" className="flex-1 px-3 py-2.5 text-sm outline-none font-mono" value={commission} onChange={e=>setCommission(e.target.value)}/>
              <span className="px-3 py-2.5 bg-slate-50 border-l border-slate-200 text-sm text-slate-500 font-mono">%</span>
            </div>
          </div>
          <button onClick={saveComm} className={`px-5 py-2.5 rounded-lg text-sm font-medium transition-colors ${commSaved?"bg-green-50 text-green-700 border border-green-200":"bg-[#1B4FD8] text-white hover:bg-blue-700"}`}>
            {commSaved?<><CheckCircle2 size={14} className="inline mr-1"/>Saved</>:"Save"}
          </button>
        </div>
        <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
          <p className="text-xs text-amber-700 font-medium">⚠ Changes apply only to future accepted orders. Existing orders keep their original commission values.</p>
        </div>
      </div>
    </div>
  );
}

// ── Admin App Shell ───────────────────────────────────────────────────────────

const ADMIN_NAV: { id:AdminSection; icon:typeof Home; label:string }[] = [
  { id:"dashboard",     icon:LayoutDashboard, label:"Dashboard"     },
  { id:"orders",        icon:Package,         label:"Orders"        },
  { id:"drivers",       icon:Truck,           label:"Drivers"       },
  { id:"clients",       icon:Users,           label:"Clients"       },
  { id:"regions",       icon:MapPin,          label:"Regions"       },
  { id:"tariffs",       icon:Tag,             label:"Tariffs"       },
  { id:"disputes",      icon:Flag,            label:"Disputes"      },
  { id:"staff",         icon:ShieldCheck,     label:"Staff"         },
  { id:"notifications", icon:Bell,            label:"Notifications" },
  { id:"audit",         icon:ClipboardList,   label:"Audit Log"     },
  { id:"profile",       icon:User,            label:"Profile"       },
];

function AdminApp({ onLogout }: { onLogout:()=>void }) {
  const [section,setSection] = useState<AdminSection>("dashboard");
  const [collapsed,setCollapsed] = useState(false);
  const [refreshKey,setRefreshKey] = useState(0);

  const current = ADMIN_NAV.find(n=>n.id===section)!;
  const unreadDisputes = adminDisputes.filter(d=>d.status==="open").length;
  const unreadNotifs   = adminAdminNotifs.filter(n=>!n.read).length;

  return (
    <div className="flex h-screen bg-slate-100 overflow-hidden" style={{fontFamily:"Inter, sans-serif"}}>
      {/* Sidebar */}
      <aside className={`flex-shrink-0 flex flex-col bg-[#0f172a] transition-all duration-200 ${collapsed?"w-16":"w-60"}`}>
        {/* Brand */}
        <div className="flex items-center gap-3 px-4 py-5 border-b border-white/10 flex-shrink-0">
          <div className="w-8 h-8 rounded-lg bg-[#1B4FD8] flex items-center justify-center flex-shrink-0"><Truck size={16} className="text-white"/></div>
          {!collapsed && <div className="min-w-0"><p className="text-sm font-bold text-white truncate">Elchi Admin</p><p className="text-[10px] text-white/40">Super Admin</p></div>}
        </div>

        {/* Nav items */}
        <nav className="flex-1 overflow-y-auto py-3 space-y-0.5 px-2">
          {ADMIN_NAV.map(({ id,icon:Icon,label })=>{
            const active = section===id;
            const badge = id==="disputes"?unreadDisputes:id==="notifications"?unreadNotifs:0;
            return (
              <button key={id} onClick={()=>setSection(id)}
                className={`w-full flex items-center gap-3 rounded-lg transition-all ${collapsed?"justify-center px-0 py-2.5":"px-3 py-2"} ${active?"bg-[#1B4FD8] text-white":"text-white/60 hover:bg-white/5 hover:text-white"}`}
                title={collapsed?label:undefined}>
                <div className="relative flex-shrink-0">
                  <Icon size={16}/>
                  {badge>0 && <div className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-red-500 flex items-center justify-center"><span className="text-[8px] font-bold text-white">{badge}</span></div>}
                </div>
                {!collapsed && <span className="text-sm font-medium flex-1 text-left">{label}</span>}
                {!collapsed && badge>0 && <span className="text-[10px] bg-red-500 text-white px-1.5 py-0.5 rounded-full font-bold">{badge}</span>}
              </button>
            );
          })}
        </nav>

        {/* Collapse toggle */}
        <div className="border-t border-white/10 p-3">
          <button onClick={()=>setCollapsed(c=>!c)} className="w-full flex items-center justify-center gap-2 text-white/40 hover:text-white transition-colors py-2 rounded-lg hover:bg-white/5">
            {collapsed?<PanelLeft size={16}/>:<><PanelLeftClose size={16}/>{!collapsed&&<span className="text-xs">Collapse</span>}</>}
          </button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top header */}
        <header className="flex-shrink-0 bg-white border-b border-slate-200 flex items-center justify-between px-6 h-14">
          <div className="flex items-center gap-3">
            <h1 className="text-base font-semibold text-slate-800">{current.label}</h1>
            <AdminStatusBadge status="super_admin"/>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={()=>setRefreshKey(k=>k+1)} className="flex items-center gap-1.5 px-3 py-1.5 border border-slate-200 rounded-lg text-xs text-slate-600 hover:bg-slate-50 transition-colors">
              <RefreshCw size={12}/> Refresh
            </button>
            <button onClick={onLogout} className="flex items-center gap-1.5 px-3 py-1.5 border border-red-200 rounded-lg text-xs text-red-600 hover:bg-red-50 transition-colors">
              <LogOut size={12}/> Logout
            </button>
          </div>
        </header>

        {/* Scrollable content */}
        <main className="flex-1 overflow-y-auto" key={refreshKey}>
          {section==="dashboard"     && <AdminDashboard onNav={setSection}/>}
          {section==="orders"        && <AdminOrders/>}
          {section==="drivers"       && <AdminDrivers/>}
          {section==="clients"       && <AdminClients/>}
          {section==="regions"       && <AdminRegions/>}
          {section==="tariffs"       && <AdminTariffs/>}
          {section==="disputes"      && <AdminDisputesSection/>}
          {section==="staff"         && <AdminStaffSection/>}
          {section==="notifications" && <AdminNotificationsSection/>}
          {section==="audit"         && <AdminAuditLogSection/>}
          {section==="profile"       && <AdminProfileSection onLogout={onLogout}/>}
        </main>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// ROOT
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// PAGES
// ═══════════════════════════════════════════════════════════════════════════════

// ── Root Layout — shared state across all routes ──────────────────────────────

function RootLayout() {
  const [role,      setRole]      = useState<Role>("driver");
  const [phone,     setPhone]     = useState("");
  const [themeMode, setThemeMode] = useState<ThemeMode>("dark");
  const [lang,      setLang]      = useState<Lang>("uz");

  const systemDark = window.matchMedia?.("(prefers-color-scheme:dark)").matches ?? true;
  const isDark = themeMode === "dark" || (themeMode === "system" && systemDark);

  const tFn = (k: TKey): string => {
    const v = (T[lang] as Record<string, unknown>)[k as string];
    if (Array.isArray(v)) return v as unknown as string;
    return String(v ?? (T.en as Record<string, unknown>)[k as string] ?? k);
  };

  return (
    <AppCtx.Provider value={{ role, setRole, phone, setPhone, themeMode, setThemeMode, lang, setLang, isDark }}>
      <LangCtx.Provider value={{ lang, t: tFn }}>
        <Outlet />
      </LangCtx.Provider>
    </AppCtx.Provider>
  );
}

// ── / — Auth page (splash → onboarding → role-select → phone → otp) ──────────

function AuthPage() {
  const { role, setRole, phone, setPhone, isDark } = useApp();
  const navigate = useNavigate();
  const [authStep, setAuthStep] = useState<Exclude<AuthStep, "app">>("splash");

  function handleVerify() {
    navigate(`/${role}`, { replace: true });
  }

  // Admin: centered card on dark background
  if (role === "admin") {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6" style={{ fontFamily: "Inter, sans-serif" }}>
        <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl overflow-hidden">
          <div className="bg-[#0f172a] px-6 py-5 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#1B4FD8] flex items-center justify-center"><Truck size={16} className="text-white" /></div>
            <div><p className="text-sm font-bold text-white">Elchi Admin</p><p className="text-[10px] text-white/40">Management Panel</p></div>
          </div>
          <div className="h-[480px] overflow-hidden">
            {authStep === "splash"      && <SplashScreen onDone={() => setAuthStep("role-select")} />}
            {authStep === "role-select" && <RoleSelectScreen onSelect={r => { setRole(r); setAuthStep("phone"); }} onBack={() => setAuthStep("splash")} />}
            {authStep === "phone"       && <PhoneScreen role={role} onSubmit={p => { setPhone(p); setAuthStep("otp"); }} onBack={() => setAuthStep("role-select")} />}
            {authStep === "otp"         && <OtpScreen phone={phone} role={role} onVerify={handleVerify} onBack={() => setAuthStep("phone")} />}
          </div>
        </div>
      </div>
    );
  }

  // Client / Driver: phone frame
  return (
    <div className={isDark ? "dark" : ""}>
      <div className="min-h-screen flex items-center justify-center p-4 transition-colors duration-300"
        style={{ fontFamily: "Inter, sans-serif", background: isDark ? "#060a0f" : "#e8edf5" }}>
        <div className="relative w-full max-w-[390px] h-[844px] bg-background rounded-[44px] overflow-hidden flex flex-col transition-colors duration-300"
          style={{ boxShadow: isDark ? "0 40px 80px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,255,255,0.05)" : "0 40px 80px rgba(0,0,0,0.2), 0 0 0 1px rgba(0,0,0,0.06)" }}>
          {/* Status bar */}
          <div className="flex items-center justify-between px-8 pt-4 pb-1 flex-shrink-0">
            <span className="text-[11px] font-semibold text-foreground font-mono">9:41</span>
            <div className="w-28 h-6 rounded-full" style={{ background: isDark ? "#000" : "#111827" }} />
            <div className="flex items-center gap-1">
              <div className="flex gap-0.5 items-end">{[3, 5, 7, 9].map((h, i) => <div key={i} className="w-1 rounded-sm bg-foreground/70" style={{ height: h }} />)}</div>
              <Bell size={10} className="text-foreground/70 ml-1" />
            </div>
          </div>
          <div className="flex-1 overflow-hidden">
            {authStep === "splash"      && <SplashScreen onDone={() => setAuthStep("onboarding")} />}
            {authStep === "onboarding"  && <OnboardingScreen onContinue={() => setAuthStep("role-select")} />}
            {authStep === "role-select" && <RoleSelectScreen onSelect={r => { setRole(r); setAuthStep("phone"); }} onBack={() => setAuthStep("onboarding")} />}
            {authStep === "phone"       && <PhoneScreen role={role} onSubmit={p => { setPhone(p); setAuthStep("otp"); }} onBack={() => setAuthStep("role-select")} />}
            {authStep === "otp"         && <OtpScreen phone={phone} role={role} onVerify={handleVerify} onBack={() => setAuthStep("phone")} />}
          </div>
        </div>
        <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 rounded-full blur-3xl"
            style={{ background: isDark ? "rgba(27,79,216,0.12)" : "rgba(27,79,216,0.08)" }} />
        </div>
      </div>
    </div>
  );
}

// ── /driver ───────────────────────────────────────────────────────────────────

function DriverPage() {
  const { themeMode, setThemeMode, lang, setLang, isDark } = useApp();
  const navigate = useNavigate();
  const tFn = (k: TKey): string => {
    const v = (T[lang] as Record<string, unknown>)[k as string];
    if (Array.isArray(v)) return v as unknown as string;
    return String(v ?? (T.en as Record<string, unknown>)[k as string] ?? k);
  };
  return (
    <LangCtx.Provider value={{ lang, t: tFn }}>
      <div className={isDark ? "dark" : ""}>
        <div className="min-h-screen flex items-center justify-center p-4 transition-colors duration-300"
          style={{ fontFamily: "Inter, sans-serif", background: isDark ? "#060a0f" : "#e8edf5" }}>
          <div className="relative w-full max-w-[390px] h-[844px] bg-background rounded-[44px] overflow-hidden flex flex-col transition-colors duration-300"
            style={{ boxShadow: isDark ? "0 40px 80px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,255,255,0.05)" : "0 40px 80px rgba(0,0,0,0.2), 0 0 0 1px rgba(0,0,0,0.06)" }}>
            {/* Status bar */}
            <div className="flex items-center justify-between px-8 pt-4 pb-1 flex-shrink-0">
              <span className="text-[11px] font-semibold text-foreground font-mono">9:41</span>
              <div className="w-28 h-6 rounded-full" style={{ background: isDark ? "#000" : "#111827" }} />
              <div className="flex items-center gap-1">
                <div className="flex gap-0.5 items-end">{[3, 5, 7, 9].map((h, i) => <div key={i} className="w-1 rounded-sm bg-foreground/70" style={{ height: h }} />)}</div>
                <Bell size={10} className="text-foreground/70 ml-1" />
              </div>
            </div>
            <DriverApp themeMode={themeMode} onThemeChange={setThemeMode} lang={lang} onLangChange={setLang} onLogout={() => navigate("/", { replace: true })} />
          </div>
          <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
            <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 rounded-full blur-3xl"
              style={{ background: isDark ? "rgba(27,79,216,0.12)" : "rgba(27,79,216,0.08)" }} />
          </div>
        </div>
      </div>
    </LangCtx.Provider>
  );
}

// ── /client ───────────────────────────────────────────────────────────────────

function ClientPage() {
  const { phone, themeMode, setThemeMode, lang, setLang, isDark } = useApp();
  const navigate = useNavigate();
  const tFn = (k: TKey): string => {
    const v = (T[lang] as Record<string, unknown>)[k as string];
    if (Array.isArray(v)) return v as unknown as string;
    return String(v ?? (T.en as Record<string, unknown>)[k as string] ?? k);
  };
  return (
    <LangCtx.Provider value={{ lang, t: tFn }}>
      <div className={isDark ? "dark" : ""}>
        <div className="min-h-screen flex items-center justify-center p-4 transition-colors duration-300"
          style={{ fontFamily: "Inter, sans-serif", background: isDark ? "#060a0f" : "#e8edf5" }}>
          <div className="relative w-full max-w-[390px] h-[844px] bg-background rounded-[44px] overflow-hidden flex flex-col transition-colors duration-300"
            style={{ boxShadow: isDark ? "0 40px 80px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,255,255,0.05)" : "0 40px 80px rgba(0,0,0,0.2), 0 0 0 1px rgba(0,0,0,0.06)" }}>
            {/* Status bar */}
            <div className="flex items-center justify-between px-8 pt-4 pb-1 flex-shrink-0">
              <span className="text-[11px] font-semibold text-foreground font-mono">9:41</span>
              <div className="w-28 h-6 rounded-full" style={{ background: isDark ? "#000" : "#111827" }} />
              <div className="flex items-center gap-1">
                <div className="flex gap-0.5 items-end">{[3, 5, 7, 9].map((h, i) => <div key={i} className="w-1 rounded-sm bg-foreground/70" style={{ height: h }} />)}</div>
                <Bell size={10} className="text-foreground/70 ml-1" />
              </div>
            </div>
            <ClientApp phone={phone} themeMode={themeMode} onThemeChange={setThemeMode} lang={lang} onLangChange={setLang} onLogout={() => navigate("/", { replace: true })} />
          </div>
          <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
            <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 rounded-full blur-3xl"
              style={{ background: isDark ? "rgba(27,79,216,0.12)" : "rgba(27,79,216,0.08)" }} />
          </div>
        </div>
      </div>
    </LangCtx.Provider>
  );
}

// ── /admin ────────────────────────────────────────────────────────────────────

function AdminPage() {
  const { lang } = useApp();
  const navigate = useNavigate();
  const tFn = (k: TKey): string => {
    const v = (T[lang] as Record<string, unknown>)[k as string];
    if (Array.isArray(v)) return v as unknown as string;
    return String(v ?? (T.en as Record<string, unknown>)[k as string] ?? k);
  };
  return (
    <LangCtx.Provider value={{ lang, t: tFn }}>
      <AdminApp onLogout={() => navigate("/", { replace: true })} />
    </LangCtx.Provider>
  );
}

// ── Router ────────────────────────────────────────────────────────────────────

const router = createBrowserRouter([
  {
    path: "/",
    Component: RootLayout,
    children: [
      { index: true,       Component: AuthPage   },
      { path: "driver",    Component: DriverPage  },
      { path: "client",    Component: ClientPage  },
      { path: "admin",     Component: AdminPage   },
      { path: "*",         element: <Navigate to="/" replace /> },
    ],
  },
]);

export default function App() {
  return <RouterProvider router={router} />;
}
